#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x28 - 0x28)
// BlueprintGeneratedClass ALK_PrnMonkey.ALK_PrnMonkey_C
class UALK_PrnMonkey_C : public UAnimationDataStoreId
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ALK_PrnMonkey_C"));
		return Clss;
	}

};

}


