#pragma once


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x18 (0x18 - 0x0)
// Function AIShips.AIShipDebugFunctionLibrary.RequestAIShipForCrew
struct UAIShipDebugFunctionLibrary_RequestAIShipForCrew_Params
{
public:
	class UObject*                               WorldContextObject;                                // 0x0(0x8)
	struct FGuid                                 CrewId;                                            // 0x8(0x10)
};

// 0x20 (0x20 - 0x0)
// Function AIShips.AIShipDebugFunctionLibrary.GenerateAIShipBattleDesc
struct UAIShipDebugFunctionLibrary_GenerateAIShipBattleDesc_Params
{
public:
	class UObject*                               WorldContextObject;                                // 0x0(0x8)
	class UAIShipServiceDataAsset*               ServiceParams;                                     // 0x8(0x8)
	struct FAIShipEncounterBattleDesc            ReturnValue;                                       // 0x10(0x10)
};

// 0x20 (0x20 - 0x0)
// Function AIShips.AIShipsBlueprintFunctionLibrary.RequestPassiveAIShipForPlayerShip
struct UAIShipsBlueprintFunctionLibrary_RequestPassiveAIShipForPlayerShip_Params
{
public:
	class UObject*                               WorldContext;                                      // 0x0(0x8)
	class AActor*                                PlayerShip;                                        // 0x8(0x8)
	TSubclassOf<class UShipSize>                 ForcedAIShipSize;                                  // 0x10(0x8)
	bool                                         ReturnValue;                                       // 0x18(0x1)
	uint8                                        Pad_33CF[0x7];                                     // Fixing Size Of Struct
};

// 0x30 (0x30 - 0x0)
// Function AIShips.AIShipsBlueprintFunctionLibrary.RequestPassiveAIShipAtLocation
struct UAIShipsBlueprintFunctionLibrary_RequestPassiveAIShipAtLocation_Params
{
public:
	class UObject*                               WorldContext;                                      // 0x0(0x8)
	struct FVector                               Location;                                          // 0x8(0xC)
	uint8                                        Pad_33D0[0x4];                                     // Fixing Size After Last Property
	class AActor*                                PlayerShip;                                        // 0x18(0x8)
	TSubclassOf<class UShipSize>                 ForcedAIShipSize;                                  // 0x20(0x8)
	bool                                         ReturnValue;                                       // 0x28(0x1)
	uint8                                        Pad_33D1[0x7];                                     // Fixing Size Of Struct
};

// 0x20 (0x20 - 0x0)
// Function AIShips.AIShipsBlueprintFunctionLibrary.RequestAggressiveAIShipForPlayerShip
struct UAIShipsBlueprintFunctionLibrary_RequestAggressiveAIShipForPlayerShip_Params
{
public:
	class UObject*                               WorldContext;                                      // 0x0(0x8)
	class AActor*                                PlayerShip;                                        // 0x8(0x8)
	TSubclassOf<class UShipSize>                 ForcedAIShipSize;                                  // 0x10(0x8)
	bool                                         ReturnValue;                                       // 0x18(0x1)
	uint8                                        Pad_33D2[0x7];                                     // Fixing Size Of Struct
};

// 0x30 (0x30 - 0x0)
// Function AIShips.AIShipsBlueprintFunctionLibrary.RequestAggressiveAIShipAtLocation
struct UAIShipsBlueprintFunctionLibrary_RequestAggressiveAIShipAtLocation_Params
{
public:
	class UObject*                               WorldContext;                                      // 0x0(0x8)
	struct FVector                               Location;                                          // 0x8(0xC)
	uint8                                        Pad_33D3[0x4];                                     // Fixing Size After Last Property
	class AActor*                                PlayerShip;                                        // 0x18(0x8)
	TSubclassOf<class UShipSize>                 ForcedAIShipSize;                                  // 0x20(0x8)
	bool                                         ReturnValue;                                       // 0x28(0x1)
	uint8                                        Pad_33D4[0x7];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIShips.AthenaAIShipController.ApplyControllerParams
struct AAthenaAIShipController_ApplyControllerParams_Params
{
public:
	class UAthenaAIControllerParamsDataAsset*    ParamsAsset;                                       // 0x0(0x8)
	class APawn*                                 InPawn;                                            // 0x8(0x8)
};

// 0x10 (0x10 - 0x0)
// Function AIShips.CursedCrewCustomisationInterface.SetCursedCrewCustomisationProperties
struct UCursedCrewCustomisationInterface_SetCursedCrewCustomisationProperties_Params
{
public:
	struct FAIShipSailData                       SailData;                                          // 0x0(0x10)
};

}
}


