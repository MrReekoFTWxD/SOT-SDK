#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x28 - 0x28)
// BlueprintGeneratedClass ALK_ThirdPerson_Female_Default.ALK_ThirdPerson_Female_Default_C
class UALK_ThirdPerson_Female_Default_C : public UAnimationDataStoreId
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ALK_ThirdPerson_Female_Default_C"));
		return Clss;
	}

};

}


