#pragma once


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x10 (0x10 - 0x0)
// Function AIGoals.WhileBlackboardKeySetAIGoal.GetAllowedBlackboardKeys
struct UWhileBlackboardKeySetAIGoal_GetAllowedBlackboardKeys_Params
{
public:
	TArray<class FString>                        ReturnValue;                                       // 0x0(0x10)
};

}
}


