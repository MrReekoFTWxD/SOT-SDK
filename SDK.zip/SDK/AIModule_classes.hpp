#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x30 (0x58 - 0x28)
// Class AIModule.BTNode
class UBTNode : public UObject
{
public:
	uint8                                        Pad_2BF7[0x8];                                     // Fixing Size After Last Property
	class FString                                NodeName;                                          // 0x30(0x10)
	class UBehaviorTree*                         TreeAsset;                                         // 0x40(0x8)
	class UBTCompositeNode*                      ParentNode;                                        // 0x48(0x8)
	uint8                                        Pad_2BF8[0x8];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTNode"));
		return Clss;
	}

};

// 0x8 (0x60 - 0x58)
// Class AIModule.BTAuxiliaryNode
class UBTAuxiliaryNode : public UBTNode
{
public:
	uint8                                        Pad_2BF9[0x8];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTAuxiliaryNode"));
		return Clss;
	}

};

// 0x10 (0x70 - 0x60)
// Class AIModule.BTService
class UBTService : public UBTAuxiliaryNode
{
public:
	float                                        Interval;                                          // 0x60(0x4)
	float                                        RandomDeviation;                                   // 0x64(0x4)
	uint8                                        bCallTickOnSearchStart : 1;                        // Mask: 0x1, PropSize: 0x10x68(0x1)
	uint8                                        bRestartTimerOnEachActivation : 1;                 // Mask: 0x2, PropSize: 0x10x68(0x1)
	uint8                                        Pad_2BFA[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTService"));
		return Clss;
	}

};

// 0x8 (0x68 - 0x60)
// Class AIModule.BTDecorator
class UBTDecorator : public UBTAuxiliaryNode
{
public:
	uint8                                        BitPad_193 : 7;                                    // Fixing Bit-Field Size
	uint8                                        bInverseCondition : 1;                             // Mask: 0x80, PropSize: 0x10x60(0x1)
	uint8                                        Pad_2BFB[0x3];                                     // Fixing Size After Last Property
	enum class EBTFlowAbortMode                  FlowAbortMode;                                     // 0x64(0x1)
	uint8                                        Pad_2BFC[0x3];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator"));
		return Clss;
	}

};

// 0x28 (0x90 - 0x68)
// Class AIModule.BTDecorator_BlackboardBase
class UBTDecorator_BlackboardBase : public UBTDecorator
{
public:
	struct FBlackboardKeySelector                BlackboardKey;                                     // 0x68(0x28)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator_BlackboardBase"));
		return Clss;
	}

};

// 0x8 (0x60 - 0x58)
// Class AIModule.BTTaskNode
class UBTTaskNode : public UBTNode
{
public:
	uint8                                        Pad_2BFD[0x8];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTaskNode"));
		return Clss;
	}

};

// 0x28 (0x88 - 0x60)
// Class AIModule.BTTask_BlackboardBase
class UBTTask_BlackboardBase : public UBTTaskNode
{
public:
	struct FBlackboardKeySelector                BlackboardKey;                                     // 0x60(0x28)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_BlackboardBase"));
		return Clss;
	}

};

// 0x20 (0xA8 - 0x88)
// Class AIModule.BTTask_RunEQSQuery
class UBTTask_RunEQSQuery : public UBTTask_BlackboardBase
{
public:
	class UEnvQuery*                             QueryTemplate;                                     // 0x88(0x8)
	TArray<struct FEnvNamedValue>                QueryParams;                                       // 0x90(0x10)
	enum class EEnvQueryRunMode                  RunMode;                                           // 0xA0(0x1)
	uint8                                        Pad_2BFE[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_RunEQSQuery"));
		return Clss;
	}

};

// 0x8 (0x90 - 0x88)
// Class AIModule.BTTask_RotateToFaceBBEntry
class UBTTask_RotateToFaceBBEntry : public UBTTask_BlackboardBase
{
public:
	float                                        Precision;                                         // 0x88(0x4)
	uint8                                        Pad_2BFF[0x4];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_RotateToFaceBBEntry"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIModule.EnvQueryContext
class UEnvQueryContext : public UObject
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryContext"));
		return Clss;
	}

};

// 0x8 (0x30 - 0x28)
// Class AIModule.EnvQueryNode
class UEnvQueryNode : public UObject
{
public:
	int32                                        VerNum;                                            // 0x28(0x4)
	uint8                                        Pad_2C00[0x4];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryNode"));
		return Clss;
	}

};

// 0x28 (0x58 - 0x30)
// Class AIModule.EnvQueryGenerator
class UEnvQueryGenerator : public UEnvQueryNode
{
public:
	class FString                                OptionName;                                        // 0x30(0x10)
	bool                                         NonShippingOnly;                                   // 0x40(0x1)
	uint8                                        Pad_2C01[0x3];                                     // Fixing Size After Last Property
	struct FFeatureFlag                          Feature;                                           // 0x44(0xC)
	TSubclassOf<class UEnvQueryItemType>         ItemType;                                          // 0x50(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryGenerator"));
		return Clss;
	}

};

// 0x140 (0x170 - 0x30)
// Class AIModule.EnvQueryTest
class UEnvQueryTest : public UEnvQueryNode
{
public:
	int32                                        TestOrder;                                         // 0x30(0x4)
	enum class EEnvTestPurpose                   TestPurpose;                                       // 0x34(0x1)
	enum class EEnvTestFilterOperator            MultipleContextFilterOp;                           // 0x35(0x1)
	enum class EEnvTestScoreOperator             MultipleContextScoreOp;                            // 0x36(0x1)
	enum class EEnvTestFilterType                FilterType;                                        // 0x37(0x1)
	struct FAIDataProviderBoolValue              BoolValue;                                         // 0x38(0x30)
	struct FAIDataProviderFloatValue             FloatValueMin;                                     // 0x68(0x30)
	struct FAIDataProviderFloatValue             FloatValueMax;                                     // 0x98(0x30)
	uint8                                        Pad_2C02[0x1];                                     // Fixing Size After Last Property
	enum class EEnvTestScoreEquation             ScoringEquation;                                   // 0xC9(0x1)
	enum class EEnvQueryTestClamping             ClampMinType;                                      // 0xCA(0x1)
	enum class EEnvQueryTestClamping             ClampMaxType;                                      // 0xCB(0x1)
	uint8                                        Pad_2C03[0x4];                                     // Fixing Size After Last Property
	struct FAIDataProviderFloatValue             ScoreClampMin;                                     // 0xD0(0x30)
	struct FAIDataProviderFloatValue             ScoreClampMax;                                     // 0x100(0x30)
	struct FAIDataProviderFloatValue             ScoringFactor;                                     // 0x130(0x30)
	uint8                                        Pad_2C04[0x8];                                     // Fixing Size After Last Property
	uint8                                        bWorkOnFloatValues : 1;                            // Mask: 0x1, PropSize: 0x10x168(0x1)
	uint8                                        Pad_2C05[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryTest"));
		return Clss;
	}

};

// 0x90 (0x4B8 - 0x428)
// Class AIModule.AIController
class AAIController : public AController
{
public:
	uint8                                        Pad_2C0D[0x28];                                    // Fixing Size After Last Property
	uint8                                        bLOSflag : 1;                                      // Mask: 0x1, PropSize: 0x10x450(0x1)
	uint8                                        bSkipExtraLOSChecks : 1;                           // Mask: 0x2, PropSize: 0x10x450(0x1)
	uint8                                        bAllowStrafe : 1;                                  // Mask: 0x4, PropSize: 0x10x450(0x1)
	uint8                                        bWantsPlayerState : 1;                             // Mask: 0x8, PropSize: 0x10x450(0x1)
	uint8                                        bDisableControlRotation : 1;                       // Mask: 0x10, PropSize: 0x10x450(0x1)
	uint8                                        BitPad_194 : 3;                                    // Fixing Bit-Field Size
	uint8                                        Pad_2C0E[0x7];                                     // Fixing Size After Last Property
	class UPathFollowingComponent*               PathFollowingComponent;                            // 0x458(0x8)
	class UBrainComponent*                       BrainComponent;                                    // 0x460(0x8)
	class UAIPerceptionComponent*                PerceptionComponent;                               // 0x468(0x8)
	class UPawnActionsComponent*                 ActionsComp;                                       // 0x470(0x8)
	class UBlackboardComponent*                  Blackboard;                                        // 0x478(0x8)
	class UGameplayTasksComponent*               CachedGameplayTasksComponent;                      // 0x480(0x8)
	uint8                                        Pad_2C0F[0x10];                                    // Fixing Size After Last Property
	UMulticastInlineDelegateProperty_            ReceiveMoveCompleted;                              // 0x498(0x10)
	uint8                                        Pad_2C10[0x10];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIController"));
		return Clss;
	}

	bool UseBlackboard(class UBlackboardData* BlackboardAsset, class UBlackboardComponent** BlackboardComponent);
	void SetMoveBlockDetection(bool bEnable);
	bool RunBehaviorTree(class UBehaviorTree* BTAsset);
	void OnUsingBlackBoard(class UBlackboardComponent* BlackboardComp, class UBlackboardData* BlackboardAsset);
	void OnPossess(class APawn* PossessedPawn);
	void OnGameplayTaskResourcesClaimed(const struct FGameplayResourceSet& NewlyClaimed, const struct FGameplayResourceSet& FreshlyReleased);
	enum class EPathFollowingRequestResult MoveToLocation(struct FVector& Dest, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bProjectDestinationToNavigation, bool bCanStrafe, TSubclassOf<class UNavigationQueryFilter> FilterClass, bool bAllowPartialPath);
	enum class EPathFollowingRequestResult MoveToActor(class AActor* Goal, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bCanStrafe, TSubclassOf<class UNavigationQueryFilter> FilterClass, bool bAllowPartialPath);
	void K2_SetFocus(class AActor* NewFocus);
	void K2_SetFocalPoint(const struct FVector& FP);
	void K2_ClearFocus();
	bool HasPartialPath();
	class UPathFollowingComponent* GetPathFollowingComponent();
	enum class EPathFollowingStatus GetMoveStatus();
	struct FVector GetImmediateMoveDestination();
	class AActor* GetFocusActor();
	struct FVector GetFocalPointOnActor(class AActor* Actor);
	struct FVector GetFocalPoint();
	class UAIPerceptionComponent* GetAIPerceptionComponent();
};

// 0x1F0 (0x2B8 - 0xC8)
// Class AIModule.PathFollowingComponent
class UPathFollowingComponent : public UActorComponent
{
public:
	uint8                                        Pad_2C12[0x58];                                    // Fixing Size After Last Property
	class UNavMovementComponent*                 MovementComp;                                      // 0x120(0x8)
	uint8                                        Pad_2C13[0x8];                                     // Fixing Size After Last Property
	class ANavigationData*                       MyNavData;                                         // 0x130(0x8)
	uint8                                        Pad_2C14[0xBC];                                    // Fixing Size After Last Property
	uint8                                        bUseVisibilityTestsSimplification : 1;             // Mask: 0x1, PropSize: 0x10x1F4(0x1)
	uint8                                        Pad_2C15[0xC3];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("PathFollowingComponent"));
		return Clss;
	}

	void OnActorBump(class AActor* SelfActor, class AActor* OtherActor, const struct FVector& NormalImpulse, struct FHitResult& Hit);
	struct FVector GetPathDestination();
	enum class EPathFollowingAction GetPathActionType();
};

// 0x0 (0x28 - 0x28)
// Class AIModule.AIResourceInterface
class UAIResourceInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIResourceInterface"));
		return Clss;
	}

};

// 0x38 (0x60 - 0x28)
// Class AIModule.AIAsyncTaskBlueprintProxy
class UAIAsyncTaskBlueprintProxy : public UObject
{
public:
	UMulticastInlineDelegateProperty_            OnSuccess;                                         // 0x28(0x10)
	UMulticastInlineDelegateProperty_            OnFail;                                            // 0x38(0x10)
	uint8                                        Pad_2C17[0x18];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIAsyncTaskBlueprintProxy"));
		return Clss;
	}

	void OnMoveCompleted(const struct FAIRequestID& RequestID, enum class EPathFollowingResult MovementResult);
};

// 0x0 (0x28 - 0x28)
// Class AIModule.AIBlueprintHelperLibrary
class UAIBlueprintHelperLibrary : public UBlueprintFunctionLibrary
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIBlueprintHelperLibrary"));
		return Clss;
	}

	void UnlockAIResourcesWithAnimation(class UAnimInstance* AnimInstance, bool bUnlockMovement, bool UnlockAILogic);
	class APawn* SpawnAIFromClass(class UObject* WorldContextObject, TSubclassOf<class APawn> PawnClass, class UBehaviorTree* BehaviorTree, const struct FVector& Location, const struct FRotator& Rotation, bool bNoCollisionFail);
	void SendAIMessage(class APawn* Target, class FName Message, class UObject* MessageSource, bool bSuccess);
	void LockAIResourcesWithAnimation(class UAnimInstance* AnimInstance, bool bLockMovement, bool LockAILogic);
	bool IsValidAIRotation(const struct FRotator& Rotation);
	bool IsValidAILocation(const struct FVector& Location);
	bool IsValidAIDirection(const struct FVector& DirectionVector);
	class UBlackboardComponent* GetBlackboard(class AActor* Target);
	class AAIController* GetAIController(class AActor* ControlledActor);
	class UAIAsyncTaskBlueprintProxy* CreateMoveToProxyObject(class UObject* WorldContextObject, class APawn* Pawn, const struct FVector& Destination, class AActor* TargetActor, float AcceptanceRadius, bool bStopOnOverlap);
};

// 0x38 (0x100 - 0xC8)
// Class AIModule.PawnActionsComponent
class UPawnActionsComponent : public UActorComponent
{
public:
	class APawn*                                 ControlledPawn;                                    // 0xC8(0x8)
	TArray<struct FPawnActionStack>              ActionStacks;                                      // 0xD0(0x10)
	TArray<struct FPawnActionEvent>              ActionEvents;                                      // 0xE0(0x10)
	class UPawnAction*                           CurrentAction;                                     // 0xF0(0x8)
	uint8                                        Pad_2C26[0x8];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("PawnActionsComponent"));
		return Clss;
	}

	bool K2_PushAction(class UPawnAction* NewAction, enum class EAIRequestPriority Priority, class UObject* Instigator);
	bool K2_PerformAction(class APawn* Pawn, class UPawnAction* Action, enum class EAIRequestPriority Priority);
	enum class EPawnActionAbortState K2_ForceAbortAction(class UPawnAction* ActionToAbort);
	enum class EPawnActionAbortState K2_AbortAction(class UPawnAction* ActionToAbort);
};

// 0x0 (0x28 - 0x28)
// Class AIModule.AIPerceptionListenerInterface
class UAIPerceptionListenerInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIPerceptionListenerInterface"));
		return Clss;
	}

};

// 0x8 (0x30 - 0x28)
// Class AIModule.BlackboardKeyType
class UBlackboardKeyType : public UObject
{
public:
	uint8                                        Pad_2C27[0x8];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BlackboardKeyType"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIModule.BehaviorTreeTypes
class UBehaviorTreeTypes : public UObject
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BehaviorTreeTypes"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIModule.GenericTeamAgentInterface
class UGenericTeamAgentInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("GenericTeamAgentInterface"));
		return Clss;
	}

};

// 0x0 (0x4B8 - 0x4B8)
// Class AIModule.DetourCrowdAIController
class ADetourCrowdAIController : public AAIController
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("DetourCrowdAIController"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIModule.AIDataProvider
class UAIDataProvider : public UObject
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIDataProvider"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIModule.CustomDataProviderObject
class UCustomDataProviderObject : public UObject
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("CustomDataProviderObject"));
		return Clss;
	}

};

// 0x20 (0x48 - 0x28)
// Class AIModule.AIDataProvider_QueryParamFromCustomObjectProperty
class UAIDataProvider_QueryParamFromCustomObjectProperty : public UAIDataProvider
{
public:
	struct FCustomDataProviderObjectPropertySelector ObjectProperty;                                    // 0x28(0x10)
	float                                        FloatValue;                                        // 0x38(0x4)
	int32                                        IntValue;                                          // 0x3C(0x4)
	bool                                         BoolValue;                                         // 0x40(0x1)
	uint8                                        Pad_2C28[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIDataProvider_QueryParamFromCustomObjectProperty"));
		return Clss;
	}

};

// 0x18 (0x40 - 0x28)
// Class AIModule.AIDataProvider_QueryParams
class UAIDataProvider_QueryParams : public UAIDataProvider
{
public:
	class FName                                  ParamName;                                         // 0x28(0x8)
	float                                        FloatValue;                                        // 0x30(0x4)
	int32                                        IntValue;                                          // 0x34(0x4)
	bool                                         BoolValue;                                         // 0x38(0x1)
	uint8                                        Pad_2C29[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIDataProvider_QueryParams"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIModule.AIHotSpotManager
class UAIHotSpotManager : public UObject
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIHotSpotManager"));
		return Clss;
	}

};

// 0xB0 (0xF0 - 0x40)
// Class AIModule.AISystem
class UAISystem : public UAISystemBase
{
public:
	struct FStringClassReference                 PerceptionSystemClassName;                         // 0x40(0x10)
	struct FStringClassReference                 HotSpotManagerClassName;                           // 0x50(0x10)
	float                                        AcceptanceRadius;                                  // 0x60(0x4)
	bool                                         bFinishMoveOnGoalOverlap;                          // 0x64(0x1)
	bool                                         bAcceptPartialPaths;                               // 0x65(0x1)
	bool                                         bAllowStrafing;                                    // 0x66(0x1)
	bool                                         bEnableBTAITasks;                                  // 0x67(0x1)
	class UBehaviorTreeManager*                  BehaviorTreeManager;                               // 0x68(0x8)
	class UEnvQueryManager*                      EnvironmentQueryManager;                           // 0x70(0x8)
	class UAIPerceptionSystem*                   PerceptionSystem;                                  // 0x78(0x8)
	TArray<class UAIAsyncTaskBlueprintProxy*>    AllProxyObjects;                                   // 0x80(0x10)
	class UAIHotSpotManager*                     HotSpotManager;                                    // 0x90(0x8)
	uint8                                        Pad_2C2A[0x58];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISystem"));
		return Clss;
	}

	void AILoggingVerbose();
	void AIIgnorePlayers();
};

// 0x60 (0x88 - 0x28)
// Class AIModule.AISense
class UAISense : public UObject
{
public:
	struct FColor                                DebugDrawColor;                                    // 0x28(0x4)
	uint8                                        Pad_2C2B[0x4];                                     // Fixing Size After Last Property
	class FString                                DebugName;                                         // 0x30(0x10)
	float                                        DefaultExpirationAge;                              // 0x40(0x4)
	enum class EAISenseNotifyType                NotifyType;                                        // 0x44(0x1)
	uint8                                        Pad_2C2C[0x3];                                     // Fixing Size After Last Property
	uint8                                        bWantsNewPawnNotification : 1;                     // Mask: 0x1, PropSize: 0x10x48(0x1)
	uint8                                        bAutoRegisterAllPawnsAsSources : 1;                // Mask: 0x2, PropSize: 0x10x48(0x1)
	uint8                                        BitPad_195 : 6;                                    // Fixing Bit-Field Size
	uint8                                        Pad_2C2D[0x7];                                     // Fixing Size After Last Property
	class UAIPerceptionSystem*                   PerceptionSystemInstance;                          // 0x50(0x8)
	uint8                                        Pad_2C2E[0x30];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISense"));
		return Clss;
	}

};

// 0x100 (0x128 - 0x28)
// Class AIModule.AIPerceptionSystem
class UAIPerceptionSystem : public UObject
{
public:
	uint8                                        Pad_2C31[0x58];                                    // Fixing Size After Last Property
	TArray<class UAISense*>                      Senses;                                            // 0x80(0x10)
	float                                        PerceptionAgingRate;                               // 0x90(0x4)
	uint8                                        Pad_2C32[0x94];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIPerceptionSystem"));
		return Clss;
	}

	void ReportPerceptionEvent(class UObject* WorldContext, class UAISenseEvent* PerceptionEvent);
	void ReportEvent(class UAISenseEvent* PerceptionEvent);
	bool RegisterPerceptionStimuliSource(class UObject* WorldContext, TSubclassOf<class UAISense> Sense, class AActor* Target);
	void OnPerceptionStimuliSourceEndPlay(enum class EEndPlayReason EndPlayReason);
	TSubclassOf<class UAISense> GetSenseClassForStimulus(class UObject* WorldContext, struct FAIStimulus& Stimulus);
};

// 0x100 (0x1C8 - 0xC8)
// Class AIModule.AIPerceptionComponent
class UAIPerceptionComponent : public UActorComponent
{
public:
	float                                        HearingRange;                                      // 0xC8(0x4)
	float                                        LoSHearingRange;                                   // 0xCC(0x4)
	float                                        SightRadius;                                       // 0xD0(0x4)
	float                                        LoseSightRadius;                                   // 0xD4(0x4)
	float                                        PeripheralVisionAngle;                             // 0xD8(0x4)
	uint8                                        Pad_2C35[0x4];                                     // Fixing Size After Last Property
	TArray<class UAISenseConfig*>                SensesConfig;                                      // 0xE0(0x10)
	TSubclassOf<class UAISense>                  DominantSense;                                     // 0xF0(0x8)
	uint8                                        Pad_2C36[0x10];                                    // Fixing Size After Last Property
	class AAIController*                         AIOwner;                                           // 0x108(0x8)
	uint8                                        Pad_2C37[0x80];                                    // Fixing Size After Last Property
	UMulticastInlineDelegateProperty_            OnPerceptionUpdated;                               // 0x190(0x10)
	UMulticastInlineDelegateProperty_            OnTargetPerceptionUpdated;                         // 0x1A0(0x10)
	uint8                                        Pad_2C38[0x18];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIPerceptionComponent"));
		return Clss;
	}

	void RequestStimuliListenerUpdate();
	void OnOwnerEndPlay(enum class EEndPlayReason EndPlayReason);
	bool IsIgnored(class AActor* Actor);
	void GetPerceivedHostileActors(TArray<class AActor*>* OutActors);
	void GetPerceivedActors(TSubclassOf<class UAISense> SenseToUse, TArray<class AActor*>* OutActors);
	bool GetActorsPerception(class AActor* Actor, struct FActorPerceptionBlueprintInfo* Info);
};

// 0x18 (0xE0 - 0xC8)
// Class AIModule.AIPerceptionStimuliSourceComponent
class UAIPerceptionStimuliSourceComponent : public UActorComponent
{
public:
	uint8                                        bAutoRegisterAsSource : 1;                         // Mask: 0x1, PropSize: 0x10xC8(0x1)
	uint8                                        BitPad_196 : 7;                                    // Fixing Bit-Field Size
	uint8                                        Pad_2C39[0x7];                                     // Fixing Size After Last Property
	TArray<TSubclassOf<class UAISense>>          RegisterAsSourceForSenses;                         // 0xD0(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIPerceptionStimuliSourceComponent"));
		return Clss;
	}

	void UnregisterFromSense(TSubclassOf<class UAISense> SenseClass);
	void UnregisterFromPerceptionSystem();
	void RegisterWithPerceptionSystem();
	void RegisterForSense(TSubclassOf<class UAISense> SenseClass);
};

// 0x0 (0x38 - 0x38)
// Class AIModule.AIResource_Movement
class UAIResource_Movement : public UGameplayTaskResource
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIResource_Movement"));
		return Clss;
	}

};

// 0x0 (0x38 - 0x38)
// Class AIModule.AIResource_Logic
class UAIResource_Logic : public UGameplayTaskResource
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIResource_Logic"));
		return Clss;
	}

};

// 0x28 (0xB0 - 0x88)
// Class AIModule.AISense_Blueprint
class UAISense_Blueprint : public UAISense
{
public:
	TSubclassOf<class UUserDefinedStruct>        ListenerDataType;                                  // 0x88(0x8)
	TArray<class UAIPerceptionComponent*>        ListenerContainer;                                 // 0x90(0x10)
	TArray<class UAISenseEvent*>                 UnprocessedEvents;                                 // 0xA0(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISense_Blueprint"));
		return Clss;
	}

	float OnUpdate(TArray<class UAISenseEvent*>& EventsToProcess);
	void OnListenerUpdated(class AActor* ActorListener, class UAIPerceptionComponent* PerceptionComponent);
	void OnListenerUnregistered(class AActor* ActorListener, class UAIPerceptionComponent* PerceptionComponent);
	void OnListenerRegistered(class AActor* ActorListener, class UAIPerceptionComponent* PerceptionComponent);
	void K2_OnNewPawn(class APawn* NewPawn);
	void GetAllListenerComponents(TArray<class UAIPerceptionComponent*>* ListenerComponents);
	void GetAllListenerActors(TArray<class AActor*>* ListenerActors);
};

// 0x10 (0x98 - 0x88)
// Class AIModule.AISense_Damage
class UAISense_Damage : public UAISense
{
public:
	TArray<struct FAIDamageEvent>                RegisteredEvents;                                  // 0x88(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISense_Damage"));
		return Clss;
	}

	void ReportDamageEvent(class UObject* WorldContext, class AActor* DamagedActor, class AActor* Instigator, float DamageAmount, const struct FVector& EventLocation, const struct FVector& HitLocation);
};

// 0x98 (0x120 - 0x88)
// Class AIModule.AISense_Hearing
class UAISense_Hearing : public UAISense
{
public:
	int32                                        MaxNoisesPerTick;                                  // 0x88(0x4)
	int32                                        MaxNoisesStored;                                   // 0x8C(0x4)
	uint8                                        Pad_2C3D[0x8];                                     // Fixing Size After Last Property
	TArray<struct FAINoiseEvent>                 NoiseEventsArrayA;                                 // 0x98(0x10)
	TArray<struct FAINoiseEvent>                 NoiseEventsArrayB;                                 // 0xA8(0x10)
	uint8                                        Pad_2C3E[0x10];                                    // Fixing Size After Last Property
	float                                        SpeedOfSoundSq;                                    // 0xC8(0x4)
	uint8                                        Pad_2C3F[0x54];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISense_Hearing"));
		return Clss;
	}

	void ReportNoiseEvent(class UObject* WorldContext, const struct FVector& NoiseLocation, float Loudness, class AActor* Instigator, float MaxRange, class FName Tag);
};

// 0x10 (0x98 - 0x88)
// Class AIModule.AISense_Prediction
class UAISense_Prediction : public UAISense
{
public:
	TArray<struct FAIPredictionEvent>            RegisteredEvents;                                  // 0x88(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISense_Prediction"));
		return Clss;
	}

	void RequestPawnPredictionEvent(class APawn* Requestor, class AActor* PredictedActor, float PredictionTime);
	void RequestControllerPredictionEvent(class AAIController* Requestor, class AActor* PredictedActor, float PredictionTime);
};

// 0xC8 (0x150 - 0x88)
// Class AIModule.AISense_Sight
class UAISense_Sight : public UAISense
{
public:
	uint8                                        Pad_2C42[0xB0];                                    // Fixing Size After Last Property
	int32                                        MaxTracesPerTick;                                  // 0x138(0x4)
	float                                        HighImportanceQueryDistanceThreshold;              // 0x13C(0x4)
	uint8                                        Pad_2C43[0x4];                                     // Fixing Size After Last Property
	float                                        MaxQueryImportance;                                // 0x144(0x4)
	float                                        SightLimitQueryImportance;                         // 0x148(0x4)
	uint8                                        Pad_2C44[0x4];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISense_Sight"));
		return Clss;
	}

};

// 0x10 (0x98 - 0x88)
// Class AIModule.AISense_Team
class UAISense_Team : public UAISense
{
public:
	TArray<struct FAITeamStimulusEvent>          RegisteredEvents;                                  // 0x88(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISense_Team"));
		return Clss;
	}

};

// 0x10 (0x98 - 0x88)
// Class AIModule.AISense_Touch
class UAISense_Touch : public UAISense
{
public:
	TArray<struct FAITouchEvent>                 RegisteredEvents;                                  // 0x88(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISense_Touch"));
		return Clss;
	}

};

// 0x0 (0xA8 - 0xA8)
// Class AIModule.AISenseBlueprintListener
class UAISenseBlueprintListener : public UUserDefinedStruct
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISenseBlueprintListener"));
		return Clss;
	}

};

// 0x8 (0x30 - 0x28)
// Class AIModule.AISenseConfig
class UAISenseConfig : public UObject
{
public:
	float                                        MaxAge;                                            // 0x28(0x4)
	uint8                                        bStartsEnabled : 1;                                // Mask: 0x1, PropSize: 0x10x2C(0x1)
	uint8                                        Pad_2C45[0x3];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISenseConfig"));
		return Clss;
	}

};

// 0x8 (0x38 - 0x30)
// Class AIModule.AISenseConfig_Blueprint
class UAISenseConfig_Blueprint : public UAISenseConfig
{
public:
	TSubclassOf<class UAISense_Blueprint>        Implementation;                                    // 0x30(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISenseConfig_Blueprint"));
		return Clss;
	}

};

// 0x8 (0x38 - 0x30)
// Class AIModule.AISenseConfig_Damage
class UAISenseConfig_Damage : public UAISenseConfig
{
public:
	TSubclassOf<class UAISense_Damage>           Implementation;                                    // 0x30(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISenseConfig_Damage"));
		return Clss;
	}

};

// 0x18 (0x48 - 0x30)
// Class AIModule.AISenseConfig_Hearing
class UAISenseConfig_Hearing : public UAISenseConfig
{
public:
	TSubclassOf<class UAISense_Hearing>          Implementation;                                    // 0x30(0x8)
	float                                        HearingRange;                                      // 0x38(0x4)
	float                                        LoSHearingRange;                                   // 0x3C(0x4)
	uint8                                        bUseLoSHearing : 1;                                // Mask: 0x1, PropSize: 0x10x40(0x1)
	uint8                                        BitPad_197 : 7;                                    // Fixing Bit-Field Size
	uint8                                        Pad_2C46[0x3];                                     // Fixing Size After Last Property
	struct FAISenseAffiliationFilter             DetectionByAffiliation;                            // 0x44(0x4)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISenseConfig_Hearing"));
		return Clss;
	}

};

// 0x0 (0x30 - 0x30)
// Class AIModule.AISenseConfig_Prediction
class UAISenseConfig_Prediction : public UAISenseConfig
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISenseConfig_Prediction"));
		return Clss;
	}

};

// 0x20 (0x50 - 0x30)
// Class AIModule.AISenseConfig_Sight
class UAISenseConfig_Sight : public UAISenseConfig
{
public:
	TSubclassOf<class UAISense_Sight>            Implementation;                                    // 0x30(0x8)
	float                                        SightRadius;                                       // 0x38(0x4)
	float                                        LoseSightRadius;                                   // 0x3C(0x4)
	float                                        PeripheralVisionAngleDegrees;                      // 0x40(0x4)
	struct FAISenseAffiliationFilter             DetectionByAffiliation;                            // 0x44(0x4)
	float                                        AutoSuccessRangeFromLastSeenLocation;              // 0x48(0x4)
	uint8                                        Pad_2C47[0x4];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISenseConfig_Sight"));
		return Clss;
	}

};

// 0x0 (0x30 - 0x30)
// Class AIModule.AISenseConfig_Team
class UAISenseConfig_Team : public UAISenseConfig
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISenseConfig_Team"));
		return Clss;
	}

};

// 0x0 (0x30 - 0x30)
// Class AIModule.AISenseConfig_Touch
class UAISenseConfig_Touch : public UAISenseConfig
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISenseConfig_Touch"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIModule.AISenseEvent
class UAISenseEvent : public UObject
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISenseEvent"));
		return Clss;
	}

};

// 0x30 (0x58 - 0x28)
// Class AIModule.AISenseEvent_Damage
class UAISenseEvent_Damage : public UAISenseEvent
{
public:
	struct FAIDamageEvent                        Event;                                             // 0x28(0x30)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISenseEvent_Damage"));
		return Clss;
	}

};

// 0x30 (0x58 - 0x28)
// Class AIModule.AISenseEvent_Hearing
class UAISenseEvent_Hearing : public UAISenseEvent
{
public:
	struct FAINoiseEvent                         Event;                                             // 0x28(0x30)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISenseEvent_Hearing"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIModule.AISightTargetInterface
class UAISightTargetInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AISightTargetInterface"));
		return Clss;
	}

};

// 0x8 (0x60 - 0x58)
// Class AIModule.AITask
class UAITask : public UGameplayTask
{
public:
	class AAIController*                         OwnerController;                                   // 0x58(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AITask"));
		return Clss;
	}

};

// 0x50 (0xB0 - 0x60)
// Class AIModule.AITask_MoveTo
class UAITask_MoveTo : public UAITask
{
public:
	UMulticastInlineDelegateProperty_            OnRequestFailed;                                   // 0x60(0x10)
	UMulticastInlineDelegateProperty_            OnMoveFinished;                                    // 0x70(0x10)
	struct FVector                               MoveGoalLocation;                                  // 0x80(0xC)
	uint8                                        Pad_2C49[0xC];                                     // Fixing Size After Last Property
	class AActor*                                MoveGoalActor;                                     // 0x98(0x8)
	float                                        MoveAcceptanceRadius;                              // 0xA0(0x4)
	bool                                         bShouldStopOnOverlap;                              // 0xA4(0x1)
	bool                                         bShouldAcceptPartialPath;                          // 0xA5(0x1)
	bool                                         bShouldUsePathfinding;                             // 0xA6(0x1)
	uint8                                        Pad_2C4A[0x9];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AITask_MoveTo"));
		return Clss;
	}

	class UAITask_MoveTo* AIMoveTo(class AAIController* Controller, const struct FVector& GoalLocation, class AActor* GoalActor, float AcceptanceRadius, enum class EAIOptionFlag StopOnOverlap, enum class EAIOptionFlag AcceptPartialPath, bool bUsePathfinding, bool bLockAILogic);
};

// 0x60 (0x128 - 0xC8)
// Class AIModule.BrainComponent
class UBrainComponent : public UActorComponent
{
public:
	uint8                                        Pad_2C4B[0x8];                                     // Fixing Size After Last Property
	class UBlackboardComponent*                  BlackboardComp;                                    // 0xD0(0x8)
	class AAIController*                         AIOwner;                                           // 0xD8(0x8)
	uint8                                        Pad_2C4C[0x48];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BrainComponent"));
		return Clss;
	}

	void StopLogic(const class FString& Reason);
	void RestartLogic();
};

// 0x160 (0x288 - 0x128)
// Class AIModule.BehaviorTreeComponent
class UBehaviorTreeComponent : public UBrainComponent
{
public:
	uint8                                        Pad_2C4E[0x20];                                    // Fixing Size After Last Property
	TArray<class UBTNode*>                       NodeInstances;                                     // 0x148(0x10)
	uint8                                        Pad_2C4F[0x130];                                   // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BehaviorTreeComponent"));
		return Clss;
	}

	void SetDynamicSubtree(const struct FGameplayTag& InjectTag, class UBehaviorTree* BehaviorAsset);
	float GetTagCooldownEndTime(const struct FGameplayTag& CooldownTag);
	void AddCooldownTagDuration(const struct FGameplayTag& CooldownTag, float CoolDownDuration, bool bAddToExistingDuration);
};

// 0x30 (0x88 - 0x58)
// Class AIModule.BTCompositeNode
class UBTCompositeNode : public UBTNode
{
public:
	TArray<struct FBTCompositeChild>             Children;                                          // 0x58(0x10)
	TArray<class UBTService*>                    Services;                                          // 0x68(0x10)
	uint8                                        Pad_2C50[0x10];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTCompositeNode"));
		return Clss;
	}

};

// 0x38 (0x60 - 0x28)
// Class AIModule.BehaviorTree
class UBehaviorTree : public UObject
{
public:
	class UBTCompositeNode*                      RootNode;                                          // 0x28(0x8)
	class UBlackboardData*                       BlackboardAsset;                                   // 0x30(0x8)
	TArray<class UBTDecorator*>                  RootDecorators;                                    // 0x38(0x10)
	TArray<struct FBTDecoratorLogic>             RootDecoratorOps;                                  // 0x48(0x10)
	uint8                                        Pad_2C51[0x8];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BehaviorTree"));
		return Clss;
	}

};

// 0x28 (0x50 - 0x28)
// Class AIModule.BehaviorTreeManager
class UBehaviorTreeManager : public UObject
{
public:
	int32                                        MaxDebuggerSteps;                                  // 0x28(0x4)
	uint8                                        Pad_2C52[0x4];                                     // Fixing Size After Last Property
	TArray<struct FBehaviorTreeTemplateInfo>     LoadedTemplates;                                   // 0x30(0x10)
	TArray<class UBehaviorTreeComponent*>        ActiveComponents;                                  // 0x40(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BehaviorTreeManager"));
		return Clss;
	}

};

// 0x20 (0x50 - 0x30)
// Class AIModule.BlackboardKeyType_Enum
class UBlackboardKeyType_Enum : public UBlackboardKeyType
{
public:
	class UEnum*                                 EnumType;                                          // 0x30(0x8)
	class FString                                EnumName;                                          // 0x38(0x10)
	uint8                                        bIsEnumNameValid : 1;                              // Mask: 0x1, PropSize: 0x10x48(0x1)
	uint8                                        Pad_2C53[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BlackboardKeyType_Enum"));
		return Clss;
	}

};

// 0x18 (0x48 - 0x30)
// Class AIModule.BlackboardKeyType_NativeEnum
class UBlackboardKeyType_NativeEnum : public UBlackboardKeyType
{
public:
	class FString                                EnumName;                                          // 0x30(0x10)
	class UEnum*                                 EnumType;                                          // 0x40(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BlackboardKeyType_NativeEnum"));
		return Clss;
	}

};

// 0x20 (0x48 - 0x28)
// Class AIModule.BlackboardData
class UBlackboardData : public UDataAsset
{
public:
	class UBlackboardData*                       Parent;                                            // 0x28(0x8)
	TArray<struct FBlackboardEntry>              Keys;                                              // 0x30(0x10)
	uint8                                        bHasSynchronizedKeys : 1;                          // Mask: 0x1, PropSize: 0x10x40(0x1)
	uint8                                        Pad_2C54[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BlackboardData"));
		return Clss;
	}

};

// 0x148 (0x210 - 0xC8)
// Class AIModule.BlackboardComponent
class UBlackboardComponent : public UActorComponent
{
public:
	class UBrainComponent*                       BrainComp;                                         // 0xC8(0x8)
	class UBlackboardData*                       BlackboardAsset;                                   // 0xD0(0x8)
	uint8                                        Pad_2C5C[0x20];                                    // Fixing Size After Last Property
	TArray<class UBlackboardKeyType*>            KeyInstances;                                      // 0xF8(0x10)
	uint8                                        Pad_2C5D[0x108];                                   // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BlackboardComponent"));
		return Clss;
	}

	void SetValueAsVector(class FName& KeyName, const struct FVector& VectorValue);
	void SetValueAsString(class FName& KeyName, const class FString& StringValue);
	void SetValueAsRotator(class FName& KeyName, const struct FRotator& VectorValue);
	void SetValueAsObject(class FName& KeyName, class UObject* ObjectValue);
	void SetValueAsName(class FName& KeyName, class FName NameValue);
	void SetValueAsInt(class FName& KeyName, int32 IntValue);
	void SetValueAsFloat(class FName& KeyName, float FloatValue);
	void SetValueAsEnum(class FName& KeyName, uint8 EnumValue);
	void SetValueAsClass(class FName& KeyName, class UClass* ClassValue);
	void SetValueAsBool(class FName& KeyName, bool BoolValue);
	bool IsVectorValueSet(class FName& KeyName);
	struct FVector GetValueAsVector(class FName& KeyName);
	class FString GetValueAsString(class FName& KeyName);
	struct FRotator GetValueAsRotator(class FName& KeyName);
	class UObject* GetValueAsObject(class FName& KeyName);
	class FName GetValueAsName(class FName& KeyName);
	int32 GetValueAsInt(class FName& KeyName);
	float GetValueAsFloat(class FName& KeyName);
	uint8 GetValueAsEnum(class FName& KeyName);
	class UClass* GetValueAsClass(class FName& KeyName);
	bool GetValueAsBool(class FName& KeyName);
	bool GetRotationFromEntry(class FName& KeyName, struct FRotator* ResultRotation);
	bool GetLocationFromEntry(class FName& KeyName, struct FVector* ResultLocation);
	void ClearValueAsVector(class FName& KeyName);
	void ClearValueAsRotator(class FName& KeyName);
	void ClearValue(class FName& KeyName);
};

// 0x0 (0x30 - 0x30)
// Class AIModule.BlackboardKeyType_Bool
class UBlackboardKeyType_Bool : public UBlackboardKeyType
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BlackboardKeyType_Bool"));
		return Clss;
	}

};

// 0x8 (0x38 - 0x30)
// Class AIModule.BlackboardKeyType_Class
class UBlackboardKeyType_Class : public UBlackboardKeyType
{
public:
	class UClass*                                BaseClass;                                         // 0x30(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BlackboardKeyType_Class"));
		return Clss;
	}

};

// 0x0 (0x30 - 0x30)
// Class AIModule.BlackboardKeyType_Float
class UBlackboardKeyType_Float : public UBlackboardKeyType
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BlackboardKeyType_Float"));
		return Clss;
	}

};

// 0x0 (0x30 - 0x30)
// Class AIModule.BlackboardKeyType_Int
class UBlackboardKeyType_Int : public UBlackboardKeyType
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BlackboardKeyType_Int"));
		return Clss;
	}

};

// 0x0 (0x30 - 0x30)
// Class AIModule.BlackboardKeyType_Name
class UBlackboardKeyType_Name : public UBlackboardKeyType
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BlackboardKeyType_Name"));
		return Clss;
	}

};

// 0x8 (0x38 - 0x30)
// Class AIModule.BlackboardKeyType_Object
class UBlackboardKeyType_Object : public UBlackboardKeyType
{
public:
	class UClass*                                BaseClass;                                         // 0x30(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BlackboardKeyType_Object"));
		return Clss;
	}

};

// 0x0 (0x30 - 0x30)
// Class AIModule.BlackboardKeyType_Rotator
class UBlackboardKeyType_Rotator : public UBlackboardKeyType
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BlackboardKeyType_Rotator"));
		return Clss;
	}

};

// 0x10 (0x40 - 0x30)
// Class AIModule.BlackboardKeyType_String
class UBlackboardKeyType_String : public UBlackboardKeyType
{
public:
	class FString                                StringValue;                                       // 0x30(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BlackboardKeyType_String"));
		return Clss;
	}

};

// 0x0 (0x30 - 0x30)
// Class AIModule.BlackboardKeyType_Vector
class UBlackboardKeyType_Vector : public UBlackboardKeyType
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BlackboardKeyType_Vector"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIModule.BTFunctionLibrary
class UBTFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTFunctionLibrary"));
		return Clss;
	}

	void StopUsingExternalEvent(class UBTNode* NodeOwner);
	void StartUsingExternalEvent(class UBTNode* NodeOwner, class AActor* OwningActor);
	void SetBlackboardValueAsVector(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, const struct FVector& Value);
	void SetBlackboardValueAsString(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, const class FString& Value);
	void SetBlackboardValueAsRotator(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, const struct FRotator& Value);
	void SetBlackboardValueAsObject(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, class UObject* Value);
	void SetBlackboardValueAsName(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, class FName Value);
	void SetBlackboardValueAsInt(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, int32 Value);
	void SetBlackboardValueAsFloat(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, float Value);
	void SetBlackboardValueAsEnum(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, uint8 Value);
	void SetBlackboardValueAsClass(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, class UClass* Value);
	void SetBlackboardValueAsBool(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, bool Value);
	class UBlackboardComponent* GetOwnersBlackboard(class UBTNode* NodeOwner);
	class UBehaviorTreeComponent* GetOwnerComponent(class UBTNode* NodeOwner);
	struct FVector GetBlackboardValueAsVector(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	class FString GetBlackboardValueAsString(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	struct FRotator GetBlackboardValueAsRotator(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	class UObject* GetBlackboardValueAsObject(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	class FName GetBlackboardValueAsName(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	int32 GetBlackboardValueAsInt(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	float GetBlackboardValueAsFloat(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	uint8 GetBlackboardValueAsEnum(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	class UClass* GetBlackboardValueAsClass(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	bool GetBlackboardValueAsBool(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	class AActor* GetBlackboardValueAsActor(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	void ClearBlackboardValueAsVector(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	void ClearBlackboardValue(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
};

// 0x30 (0xC0 - 0x90)
// Class AIModule.BTDecorator_Blackboard
class UBTDecorator_Blackboard : public UBTDecorator_BlackboardBase
{
public:
	int32                                        IntValue;                                          // 0x90(0x4)
	float                                        FloatValue;                                        // 0x94(0x4)
	class FString                                StringValue;                                       // 0x98(0x10)
	class FString                                CachedDescription;                                 // 0xA8(0x10)
	uint8                                        OperationType;                                     // 0xB8(0x1)
	enum class EBTBlackboardRestart              NotifyObserver;                                    // 0xB9(0x1)
	uint8                                        Pad_2C6A[0x6];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator_Blackboard"));
		return Clss;
	}

};

// 0x0 (0xC0 - 0xC0)
// Class AIModule.BTDecorator_ConditionalLoop
class UBTDecorator_ConditionalLoop : public UBTDecorator_Blackboard
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator_ConditionalLoop"));
		return Clss;
	}

};

// 0x8 (0x98 - 0x90)
// Class AIModule.BTDecorator_IsAtLocation
class UBTDecorator_IsAtLocation : public UBTDecorator_BlackboardBase
{
public:
	float                                        AcceptableRadius;                                  // 0x90(0x4)
	bool                                         bUseNavAgentGoalLocation;                          // 0x94(0x1)
	uint8                                        Pad_2C6B[0x3];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator_IsAtLocation"));
		return Clss;
	}

};

// 0x8 (0x98 - 0x90)
// Class AIModule.BTDecorator_IsBBEntryOfClass
class UBTDecorator_IsBBEntryOfClass : public UBTDecorator_BlackboardBase
{
public:
	TSubclassOf<class UObject>                   TestClass;                                         // 0x90(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator_IsBBEntryOfClass"));
		return Clss;
	}

};

// 0x38 (0xA0 - 0x68)
// Class AIModule.BTDecorator_BlueprintBase
class UBTDecorator_BlueprintBase : public UBTDecorator
{
public:
	class AAIController*                         AIOwner;                                           // 0x68(0x8)
	class AActor*                                ActorOwner;                                        // 0x70(0x8)
	TArray<class FName>                          ObservedKeyNames;                                  // 0x78(0x10)
	uint8                                        Pad_2C72[0x10];                                    // Fixing Size After Last Property
	uint8                                        bShowPropertyDetails : 1;                          // Mask: 0x1, PropSize: 0x10x98(0x1)
	uint8                                        bCheckConditionOnlyBlackBoardChanges : 1;          // Mask: 0x2, PropSize: 0x10x98(0x1)
	uint8                                        bIsObservingBB : 1;                                // Mask: 0x4, PropSize: 0x10x98(0x1)
	uint8                                        Pad_2C73[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator_BlueprintBase"));
		return Clss;
	}

	void ReceiveTickAI(class AAIController* OwnerController, class APawn* ControlledPawn, float DeltaSeconds);
	void ReceiveTick(class AActor* OwnerActor, float DeltaSeconds);
	void ReceiveObserverDeactivatedAI(class AAIController* OwnerController, class APawn* ControlledPawn);
	void ReceiveObserverDeactivated(class AActor* OwnerActor);
	void ReceiveObserverActivatedAI(class AAIController* OwnerController, class APawn* ControlledPawn);
	void ReceiveObserverActivated(class AActor* OwnerActor);
	void ReceiveExecutionStartAI(class AAIController* OwnerController, class APawn* ControlledPawn);
	void ReceiveExecutionStart(class AActor* OwnerActor);
	void ReceiveExecutionFinishAI(class AAIController* OwnerController, class APawn* ControlledPawn, enum class EBTNodeResult NodeResult);
	void ReceiveExecutionFinish(class AActor* OwnerActor, enum class EBTNodeResult NodeResult);
	void ReceiveConditionCheck(class AActor* OwnerActor);
	bool PerformConditionCheckAI(class AAIController* OwnerController, class APawn* ControlledPawn);
	bool PerformConditionCheck(class AActor* OwnerActor);
	bool IsDecoratorObserverActive();
	bool IsDecoratorExecutionActive();
	void FinishConditionCheck(bool bAllowExecution);
};

// 0x68 (0xD0 - 0x68)
// Class AIModule.BTDecorator_CheckGameplayTagsOnActor
class UBTDecorator_CheckGameplayTagsOnActor : public UBTDecorator
{
public:
	struct FBlackboardKeySelector                ActorToCheck;                                      // 0x68(0x28)
	enum class EGameplayContainerMatchType       TagsToMatch;                                       // 0x90(0x1)
	uint8                                        Pad_2C74[0x7];                                     // Fixing Size After Last Property
	struct FGameplayTagContainer                 GameplayTags;                                      // 0x98(0x28)
	class FString                                CachedDescription;                                 // 0xC0(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator_CheckGameplayTagsOnActor"));
		return Clss;
	}

};

// 0x58 (0xC0 - 0x68)
// Class AIModule.BTDecorator_CompareBBEntries
class UBTDecorator_CompareBBEntries : public UBTDecorator
{
public:
	enum class EBlackBoardEntryComparison        Operator;                                          // 0x68(0x1)
	uint8                                        Pad_2C75[0x7];                                     // Fixing Size After Last Property
	struct FBlackboardKeySelector                BlackboardKeyA;                                    // 0x70(0x28)
	struct FBlackboardKeySelector                BlackboardKeyB;                                    // 0x98(0x28)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator_CompareBBEntries"));
		return Clss;
	}

};

// 0x88 (0xF0 - 0x68)
// Class AIModule.BTDecorator_ConeCheck
class UBTDecorator_ConeCheck : public UBTDecorator
{
public:
	float                                        ConeHalfAngle;                                     // 0x68(0x4)
	uint8                                        Pad_2C76[0x4];                                     // Fixing Size After Last Property
	struct FBlackboardKeySelector                ConeOrigin;                                        // 0x70(0x28)
	struct FBlackboardKeySelector                ConeDirection;                                     // 0x98(0x28)
	struct FBlackboardKeySelector                Observed;                                          // 0xC0(0x28)
	uint8                                        Pad_2C77[0x8];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator_ConeCheck"));
		return Clss;
	}

};

// 0x8 (0x70 - 0x68)
// Class AIModule.BTDecorator_Cooldown
class UBTDecorator_Cooldown : public UBTDecorator
{
public:
	float                                        CoolDownTime;                                      // 0x68(0x4)
	uint8                                        Pad_2C78[0x4];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator_Cooldown"));
		return Clss;
	}

};

// 0x60 (0xC8 - 0x68)
// Class AIModule.BTDecorator_DoesPathExist
class UBTDecorator_DoesPathExist : public UBTDecorator
{
public:
	struct FBlackboardKeySelector                BlackboardKeyA;                                    // 0x68(0x28)
	struct FBlackboardKeySelector                BlackboardKeyB;                                    // 0x90(0x28)
	uint8                                        bUseSelf : 1;                                      // Mask: 0x1, PropSize: 0x10xB8(0x1)
	uint8                                        BitPad_198 : 7;                                    // Fixing Bit-Field Size
	uint8                                        Pad_2C79[0x3];                                     // Fixing Size After Last Property
	enum class EPathExistanceQueryType           PathQueryType;                                     // 0xBC(0x1)
	uint8                                        Pad_2C7A[0x3];                                     // Fixing Size After Last Property
	TSubclassOf<class UNavigationQueryFilter>    FilterClass;                                       // 0xC0(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator_DoesPathExist"));
		return Clss;
	}

};

// 0x0 (0x68 - 0x68)
// Class AIModule.BTDecorator_ForceSuccess
class UBTDecorator_ForceSuccess : public UBTDecorator
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator_ForceSuccess"));
		return Clss;
	}

};

// 0x60 (0xC8 - 0x68)
// Class AIModule.BTDecorator_KeepInCone
class UBTDecorator_KeepInCone : public UBTDecorator
{
public:
	float                                        ConeHalfAngle;                                     // 0x68(0x4)
	uint8                                        Pad_2C7B[0x4];                                     // Fixing Size After Last Property
	struct FBlackboardKeySelector                ConeOrigin;                                        // 0x70(0x28)
	struct FBlackboardKeySelector                Observed;                                          // 0x98(0x28)
	uint8                                        bUseSelfAsOrigin : 1;                              // Mask: 0x1, PropSize: 0x10xC0(0x1)
	uint8                                        bUseSelfAsObserved : 1;                            // Mask: 0x2, PropSize: 0x10xC0(0x1)
	uint8                                        Pad_2C7C[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator_KeepInCone"));
		return Clss;
	}

};

// 0x8 (0x70 - 0x68)
// Class AIModule.BTDecorator_Loop
class UBTDecorator_Loop : public UBTDecorator
{
public:
	int32                                        NumLoops;                                          // 0x68(0x4)
	bool                                         bInfiniteLoop;                                     // 0x6C(0x1)
	uint8                                        Pad_2C7D[0x3];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator_Loop"));
		return Clss;
	}

};

// 0x0 (0x68 - 0x68)
// Class AIModule.BTDecorator_ReachedMoveGoal
class UBTDecorator_ReachedMoveGoal : public UBTDecorator
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator_ReachedMoveGoal"));
		return Clss;
	}

};

// 0x10 (0x78 - 0x68)
// Class AIModule.BTDecorator_SetTagCooldown
class UBTDecorator_SetTagCooldown : public UBTDecorator
{
public:
	struct FGameplayTag                          CooldownTag;                                       // 0x68(0x8)
	float                                        CoolDownDuration;                                  // 0x70(0x4)
	bool                                         bAddToExistingDuration;                            // 0x74(0x1)
	uint8                                        Pad_2C7E[0x3];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator_SetTagCooldown"));
		return Clss;
	}

};

// 0x10 (0x78 - 0x68)
// Class AIModule.BTDecorator_TagCooldown
class UBTDecorator_TagCooldown : public UBTDecorator
{
public:
	struct FGameplayTag                          CooldownTag;                                       // 0x68(0x8)
	float                                        CoolDownDuration;                                  // 0x70(0x4)
	bool                                         bAddToExistingDuration;                            // 0x74(0x1)
	bool                                         bActivatesCooldown;                                // 0x75(0x1)
	uint8                                        Pad_2C7F[0x2];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator_TagCooldown"));
		return Clss;
	}

};

// 0x8 (0x70 - 0x68)
// Class AIModule.BTDecorator_TimeLimit
class UBTDecorator_TimeLimit : public UBTDecorator
{
public:
	float                                        TimeLimit;                                         // 0x68(0x4)
	uint8                                        Pad_2C80[0x4];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTDecorator_TimeLimit"));
		return Clss;
	}

};

// 0x28 (0x98 - 0x70)
// Class AIModule.BTService_BlackboardBase
class UBTService_BlackboardBase : public UBTService
{
public:
	struct FBlackboardKeySelector                BlackboardKey;                                     // 0x70(0x28)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTService_BlackboardBase"));
		return Clss;
	}

};

// 0x8 (0xA0 - 0x98)
// Class AIModule.BTService_DefaultFocus
class UBTService_DefaultFocus : public UBTService_BlackboardBase
{
public:
	uint8                                        FocusPriority;                                     // 0x98(0x1)
	uint8                                        Pad_2C81[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTService_DefaultFocus"));
		return Clss;
	}

};

// 0x28 (0x98 - 0x70)
// Class AIModule.BTService_BlueprintBase
class UBTService_BlueprintBase : public UBTService
{
public:
	class AAIController*                         AIOwner;                                           // 0x70(0x8)
	class AActor*                                ActorOwner;                                        // 0x78(0x8)
	uint8                                        Pad_2C84[0x10];                                    // Fixing Size After Last Property
	uint8                                        bShowPropertyDetails : 1;                          // Mask: 0x1, PropSize: 0x10x90(0x1)
	uint8                                        bShowEventDetails : 1;                             // Mask: 0x2, PropSize: 0x10x90(0x1)
	uint8                                        Pad_2C85[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTService_BlueprintBase"));
		return Clss;
	}

	void ReceiveTickAI(class AAIController* OwnerController, class APawn* ControlledPawn, float DeltaSeconds);
	void ReceiveTick(class AActor* OwnerActor, float DeltaSeconds);
	void ReceiveSearchStartAI(class AAIController* OwnerController, class APawn* ControlledPawn);
	void ReceiveSearchStart(class AActor* OwnerActor);
	void ReceiveDeactivationAI(class AAIController* OwnerController, class APawn* ControlledPawn);
	void ReceiveDeactivation(class AActor* OwnerActor);
	void ReceiveActivationAI(class AAIController* OwnerController, class APawn* ControlledPawn);
	void ReceiveActivation(class AActor* OwnerActor);
	bool IsServiceActive();
};

// 0x0 (0x88 - 0x88)
// Class AIModule.BTComposite_Selector
class UBTComposite_Selector : public UBTCompositeNode
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTComposite_Selector"));
		return Clss;
	}

};

// 0x0 (0x88 - 0x88)
// Class AIModule.BTComposite_Sequence
class UBTComposite_Sequence : public UBTCompositeNode
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTComposite_Sequence"));
		return Clss;
	}

};

// 0x8 (0x90 - 0x88)
// Class AIModule.BTComposite_SimpleParallel
class UBTComposite_SimpleParallel : public UBTCompositeNode
{
public:
	enum class EBTParallelMode                   FinishMode;                                        // 0x88(0x1)
	uint8                                        Pad_2C86[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTComposite_SimpleParallel"));
		return Clss;
	}

};

// 0x8 (0x90 - 0x88)
// Class AIModule.BTTask_MoveDirectlyToward
class UBTTask_MoveDirectlyToward : public UBTTask_BlackboardBase
{
public:
	float                                        AcceptableRadius;                                  // 0x88(0x4)
	uint8                                        bDisablePathUpdateOnGoalLocationChange : 1;        // Mask: 0x1, PropSize: 0x10x8C(0x1)
	uint8                                        bProjectVectorGoalToNavigation : 1;                // Mask: 0x2, PropSize: 0x10x8C(0x1)
	uint8                                        bAllowStrafe : 1;                                  // Mask: 0x4, PropSize: 0x10x8C(0x1)
	uint8                                        bStopOnOverlap : 1;                                // Mask: 0x8, PropSize: 0x10x8C(0x1)
	uint8                                        Pad_2C87[0x3];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_MoveDirectlyToward"));
		return Clss;
	}

};

// 0x18 (0xA0 - 0x88)
// Class AIModule.BTTask_MoveTo
class UBTTask_MoveTo : public UBTTask_BlackboardBase
{
public:
	float                                        AcceptableRadius;                                  // 0x88(0x4)
	uint8                                        Pad_2C88[0x4];                                     // Fixing Size After Last Property
	TSubclassOf<class UNavigationQueryFilter>    FilterClass;                                       // 0x90(0x8)
	uint8                                        bAllowStrafe : 1;                                  // Mask: 0x1, PropSize: 0x10x98(0x1)
	uint8                                        bAllowPartialPath : 1;                             // Mask: 0x2, PropSize: 0x10x98(0x1)
	uint8                                        bStopOnOverlap : 1;                                // Mask: 0x4, PropSize: 0x10x98(0x1)
	uint8                                        Pad_2C89[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_MoveTo"));
		return Clss;
	}

};

// 0x8 (0x30 - 0x28)
// Class AIModule.EnvQueryItemType
class UEnvQueryItemType : public UObject
{
public:
	uint8                                        Pad_2C8A[0x8];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryItemType"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIModule.EnvQueryTypes
class UEnvQueryTypes : public UObject
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryTypes"));
		return Clss;
	}

};

// 0x30 (0x90 - 0x60)
// Class AIModule.BTTask_BlueprintBase
class UBTTask_BlueprintBase : public UBTTaskNode
{
public:
	class AAIController*                         AIOwner;                                           // 0x60(0x8)
	class AActor*                                ActorOwner;                                        // 0x68(0x8)
	uint8                                        Pad_2C8D[0x18];                                    // Fixing Size After Last Property
	uint8                                        bShowPropertyDetails : 1;                          // Mask: 0x1, PropSize: 0x10x88(0x1)
	uint8                                        Pad_2C8E[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_BlueprintBase"));
		return Clss;
	}

	void SetFinishOnMessageWithId(class FName MessageName, int32 RequestID);
	void SetFinishOnMessage(class FName MessageName);
	void ReceiveTickAI(class AAIController* OwnerController, class APawn* ControlledPawn, float DeltaSeconds);
	void ReceiveTick(class AActor* OwnerActor, float DeltaSeconds);
	void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
	void ReceiveExecute(class AActor* OwnerActor);
	void ReceiveAbortAI(class AAIController* OwnerController, class APawn* ControlledPawn);
	void ReceiveAbort(class AActor* OwnerActor);
	bool IsTaskExecuting();
	bool IsTaskAborting();
	void FinishExecute(bool bSuccess);
	void FinishAbort();
};

// 0x8 (0x68 - 0x60)
// Class AIModule.BTTask_MakeNoise
class UBTTask_MakeNoise : public UBTTaskNode
{
public:
	float                                        Loudnes;                                           // 0x60(0x4)
	uint8                                        Pad_2C8F[0x4];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_MakeNoise"));
		return Clss;
	}

};

// 0x68 (0x90 - 0x28)
// Class AIModule.PawnAction
class UPawnAction : public UObject
{
public:
	class UPawnAction*                           ChildAction;                                       // 0x28(0x8)
	class UPawnAction*                           ParentAction;                                      // 0x30(0x8)
	class UPawnActionsComponent*                 OwnerComponent;                                    // 0x38(0x8)
	class UObject*                               Instigator;                                        // 0x40(0x8)
	class UBrainComponent*                       BrainComp;                                         // 0x48(0x8)
	uint8                                        Pad_2C90[0x28];                                    // Fixing Size After Last Property
	uint8                                        bAllowNewSameClassInstance : 1;                    // Mask: 0x1, PropSize: 0x10x78(0x1)
	uint8                                        bReplaceActiveSameClassInstance : 1;               // Mask: 0x2, PropSize: 0x10x78(0x1)
	uint8                                        bShouldPauseMovement : 1;                          // Mask: 0x4, PropSize: 0x10x78(0x1)
	uint8                                        Pad_2C91[0x17];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("PawnAction"));
		return Clss;
	}

	enum class EAIRequestPriority GetActionPriority();
	void Finish(enum class EPawnActionResult WithResult);
	class UPawnAction* CreateActionInstance(class UObject* WorldContextObject, TSubclassOf<class UPawnAction> ActionClass);
};

// 0x0 (0x60 - 0x60)
// Class AIModule.BTTask_PawnActionBase
class UBTTask_PawnActionBase : public UBTTaskNode
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_PawnActionBase"));
		return Clss;
	}

};

// 0x8 (0x68 - 0x60)
// Class AIModule.BTTask_PushPawnAction
class UBTTask_PushPawnAction : public UBTTask_PawnActionBase
{
public:
	class UPawnAction*                           Action;                                            // 0x60(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_PushPawnAction"));
		return Clss;
	}

};

// 0x38 (0x98 - 0x60)
// Class AIModule.BTTask_PlayAnimation
class UBTTask_PlayAnimation : public UBTTaskNode
{
public:
	class UAnimationAsset*                       AnimationToPlay;                                   // 0x60(0x8)
	uint8                                        bLooping : 1;                                      // Mask: 0x1, PropSize: 0x10x68(0x1)
	uint8                                        bNonBlocking : 1;                                  // Mask: 0x2, PropSize: 0x10x68(0x1)
	uint8                                        BitPad_199 : 6;                                    // Fixing Bit-Field Size
	uint8                                        Pad_2C92[0x7];                                     // Fixing Size After Last Property
	class UBehaviorTreeComponent*                MyOwnerComp;                                       // 0x70(0x8)
	class USkeletalMeshComponent*                CachedSkelMesh;                                    // 0x78(0x8)
	uint8                                        Pad_2C93[0x18];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_PlayAnimation"));
		return Clss;
	}

};

// 0x8 (0x68 - 0x60)
// Class AIModule.BTTask_PlaySound
class UBTTask_PlaySound : public UBTTaskNode
{
public:
	class USoundCue*                             SoundToPlay;                                       // 0x60(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_PlaySound"));
		return Clss;
	}

};

// 0x8 (0x68 - 0x60)
// Class AIModule.BTTask_RunBehavior
class UBTTask_RunBehavior : public UBTTaskNode
{
public:
	class UBehaviorTree*                         BehaviorAsset;                                     // 0x60(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_RunBehavior"));
		return Clss;
	}

};

// 0x18 (0x78 - 0x60)
// Class AIModule.BTTask_RunBehaviorDynamic
class UBTTask_RunBehaviorDynamic : public UBTTaskNode
{
public:
	struct FGameplayTag                          InjectionTag;                                      // 0x60(0x8)
	class UBehaviorTree*                         DefaultBehaviorAsset;                              // 0x68(0x8)
	class UBehaviorTree*                         BehaviorAsset;                                     // 0x70(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_RunBehaviorDynamic"));
		return Clss;
	}

};

// 0x10 (0x70 - 0x60)
// Class AIModule.BTTask_SetTagCooldown
class UBTTask_SetTagCooldown : public UBTTaskNode
{
public:
	struct FGameplayTag                          CooldownTag;                                       // 0x60(0x8)
	bool                                         bAddToExistingDuration;                            // 0x68(0x1)
	uint8                                        Pad_2C94[0x3];                                     // Fixing Size After Last Property
	float                                        CoolDownDuration;                                  // 0x6C(0x4)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_SetTagCooldown"));
		return Clss;
	}

};

// 0x8 (0x68 - 0x60)
// Class AIModule.BTTask_Wait
class UBTTask_Wait : public UBTTaskNode
{
public:
	float                                        WaitTime;                                          // 0x60(0x4)
	float                                        RandomDeviation;                                   // 0x64(0x4)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_Wait"));
		return Clss;
	}

};

// 0x28 (0x90 - 0x68)
// Class AIModule.BTTask_WaitBlackboardTime
class UBTTask_WaitBlackboardTime : public UBTTask_Wait
{
public:
	struct FBlackboardKeySelector                BlackboardKey;                                     // 0x68(0x28)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_WaitBlackboardTime"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIModule.CrowdAgentInterface
class UCrowdAgentInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("CrowdAgentInterface"));
		return Clss;
	}

};

// 0xB8 (0xE0 - 0x28)
// Class AIModule.CrowdManager
class UCrowdManager : public UObject
{
public:
	class ANavigationData*                       MyNavData;                                         // 0x28(0x8)
	TArray<struct FCrowdAvoidanceConfig>         AvoidanceConfig;                                   // 0x30(0x10)
	TArray<struct FCrowdAvoidanceSamplingPattern> SamplingPatterns;                                  // 0x40(0x10)
	int32                                        MaxAgents;                                         // 0x50(0x4)
	float                                        MaxAgentRadius;                                    // 0x54(0x4)
	int32                                        MaxAvoidedAgents;                                  // 0x58(0x4)
	int32                                        MaxAvoidedWalls;                                   // 0x5C(0x4)
	float                                        NavmeshCheckInterval;                              // 0x60(0x4)
	float                                        PathOptimizationInterval;                          // 0x64(0x4)
	uint8                                        BitPad_19A : 3;                                    // Fixing Bit-Field Size
	uint8                                        bResolveCollisions : 1;                            // Mask: 0x8, PropSize: 0x10x68(0x1)
	uint8                                        Pad_2C95[0x77];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("CrowdManager"));
		return Clss;
	}

};

// 0x10 (0x38 - 0x28)
// Class AIModule.EnvQuery
class UEnvQuery : public UObject
{
public:
	TArray<class UEnvQueryOption*>               Options;                                           // 0x28(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQuery"));
		return Clss;
	}

};

// 0x8 (0x30 - 0x28)
// Class AIModule.EnvQueryContext_BlueprintBase
class UEnvQueryContext_BlueprintBase : public UEnvQueryContext
{
public:
	uint8                                        Pad_2C97[0x8];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryContext_BlueprintBase"));
		return Clss;
	}

	void ProvideSingleLocation(class AActor* QuerierActor, struct FVector* ResultingLocation);
	void ProvideSingleActor(class AActor* QuerierActor, class AActor** ResultingActor);
	void ProvideLocationsSet(class AActor* QuerierActor, TArray<struct FVector>* ResultingLocationSet);
	void ProvideActorsSet(class AActor* QuerierActor, TArray<class AActor*>* ResultingActorsSet);
};

// 0x0 (0x28 - 0x28)
// Class AIModule.EnvQueryContext_Item
class UEnvQueryContext_Item : public UEnvQueryContext
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryContext_Item"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIModule.EnvQueryContext_Querier
class UEnvQueryContext_Querier : public UEnvQueryContext
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryContext_Querier"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIModule.VisualLoggerExtension
class UVisualLoggerExtension : public UObject
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("VisualLoggerExtension"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIModule.EnvQueryDebugHelpers
class UEnvQueryDebugHelpers : public UObject
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryDebugHelpers"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIModule.EQSQueryResultSourceInterface
class UEQSQueryResultSourceInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EQSQueryResultSourceInterface"));
		return Clss;
	}

};

// 0x48 (0x70 - 0x28)
// Class AIModule.EnvQueryInstanceBlueprintWrapper
class UEnvQueryInstanceBlueprintWrapper : public UObject
{
public:
	uint8                                        Pad_2C99[0x8];                                     // Fixing Size After Last Property
	int32                                        QueryID;                                           // 0x30(0x4)
	uint8                                        Pad_2C9A[0x1C];                                    // Fixing Size After Last Property
	TSubclassOf<class UEnvQueryItemType>         ItemType;                                          // 0x50(0x8)
	int32                                        OptionIndex;                                       // 0x58(0x4)
	uint8                                        Pad_2C9B[0x4];                                     // Fixing Size After Last Property
	UMulticastInlineDelegateProperty_            OnQueryFinishedEvent;                              // 0x60(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryInstanceBlueprintWrapper"));
		return Clss;
	}

	TArray<struct FVector> GetResultsAsLocations();
	TArray<class AActor*> GetResultsAsActors();
	float GetItemScore(int32 ItemIndex);
	void EQSQueryDoneSignature__DelegateSignature(class UEnvQueryInstanceBlueprintWrapper* QueryInstance, enum class EEnvQueryStatus QueryStatus);
};

// 0x0 (0x30 - 0x30)
// Class AIModule.EnvQueryItemType_VectorBase
class UEnvQueryItemType_VectorBase : public UEnvQueryItemType
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryItemType_VectorBase"));
		return Clss;
	}

};

// 0x0 (0x30 - 0x30)
// Class AIModule.EnvQueryItemType_ActorBase
class UEnvQueryItemType_ActorBase : public UEnvQueryItemType_VectorBase
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryItemType_ActorBase"));
		return Clss;
	}

};

// 0x0 (0x30 - 0x30)
// Class AIModule.EnvQueryItemType_Actor
class UEnvQueryItemType_Actor : public UEnvQueryItemType_ActorBase
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryItemType_Actor"));
		return Clss;
	}

};

// 0x0 (0x30 - 0x30)
// Class AIModule.EnvQueryItemType_Direction
class UEnvQueryItemType_Direction : public UEnvQueryItemType_VectorBase
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryItemType_Direction"));
		return Clss;
	}

};

// 0x0 (0x30 - 0x30)
// Class AIModule.EnvQueryItemType_Point
class UEnvQueryItemType_Point : public UEnvQueryItemType_VectorBase
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryItemType_Point"));
		return Clss;
	}

};

// 0xE8 (0x110 - 0x28)
// Class AIModule.EnvQueryManager
class UEnvQueryManager : public UObject
{
public:
	uint8                                        Pad_2C9D[0x70];                                    // Fixing Size After Last Property
	TArray<struct FEnvQueryInstanceCache>        InstanceCache;                                     // 0x98(0x10)
	TArray<class UEnvQueryContext*>              LocalContexts;                                     // 0xA8(0x10)
	uint8                                        Pad_2C9E[0x58];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryManager"));
		return Clss;
	}

	class UEnvQueryInstanceBlueprintWrapper* RunEQSQuery(class UObject* WorldContext, class UEnvQuery* QueryTemplate, class UObject* Querier, enum class EEnvQueryRunMode RunMode, TSubclassOf<class UEnvQueryInstanceBlueprintWrapper> WrapperClass);
};

// 0x40 (0x98 - 0x58)
// Class AIModule.EnvQueryGenerator_ActorsOfClass
class UEnvQueryGenerator_ActorsOfClass : public UEnvQueryGenerator
{
public:
	struct FAIDataProviderFloatValue             SearchRadius;                                      // 0x58(0x30)
	TSubclassOf<class AActor>                    SearchedActorClass;                                // 0x88(0x8)
	TSubclassOf<class UEnvQueryContext>          SearchCenter;                                      // 0x90(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryGenerator_ActorsOfClass"));
		return Clss;
	}

};

// 0x50 (0xA8 - 0x58)
// Class AIModule.EnvQueryGenerator_BlueprintBase
class UEnvQueryGenerator_BlueprintBase : public UEnvQueryGenerator
{
public:
	class FText                                  GeneratorsActionDescription;                       // 0x58(0x38)
	TSubclassOf<class UEnvQueryContext>          Context;                                           // 0x90(0x8)
	TSubclassOf<class UEnvQueryItemType>         GeneratedItemType;                                 // 0x98(0x8)
	uint8                                        Pad_2C9F[0x8];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryGenerator_BlueprintBase"));
		return Clss;
	}

	class UObject* GetQuerier();
	void DoItemGeneration(TArray<struct FVector>& ContextLocations);
	void AddGeneratedVector(const struct FVector& GeneratedVector);
	void AddGeneratedActor(class AActor* GeneratedActor);
};

// 0x18 (0x70 - 0x58)
// Class AIModule.EnvQueryGenerator_Composite
class UEnvQueryGenerator_Composite : public UEnvQueryGenerator
{
public:
	TArray<class UEnvQueryGenerator*>            Generators;                                        // 0x58(0x10)
	bool                                         bHasMatchingItemType;                              // 0x68(0x1)
	uint8                                        Pad_2CA0[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryGenerator_Composite"));
		return Clss;
	}

};

// 0x40 (0x98 - 0x58)
// Class AIModule.EnvQueryGenerator_ProjectedPoints
class UEnvQueryGenerator_ProjectedPoints : public UEnvQueryGenerator
{
public:
	struct FEnvTraceData                         ProjectionData;                                    // 0x58(0x40)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryGenerator_ProjectedPoints"));
		return Clss;
	}

};

// 0x128 (0x1C0 - 0x98)
// Class AIModule.EnvQueryGenerator_Donut
class UEnvQueryGenerator_Donut : public UEnvQueryGenerator_ProjectedPoints
{
public:
	struct FAIDataProviderFloatValue             InnerRadius;                                       // 0x98(0x30)
	struct FAIDataProviderFloatValue             OuterRadius;                                       // 0xC8(0x30)
	struct FAIDataProviderIntValue               NumberOfRings;                                     // 0xF8(0x30)
	struct FAIDataProviderIntValue               PointsPerRing;                                     // 0x128(0x30)
	struct FEnvDirection                         ArcDirection;                                      // 0x158(0x20)
	struct FAIDataProviderFloatValue             ArcAngle;                                          // 0x178(0x30)
	bool                                         RandomiseRadius;                                   // 0x1A8(0x1)
	uint8                                        Pad_2CA1[0x7];                                     // Fixing Size After Last Property
	TSubclassOf<class UEnvQueryContext>          Center;                                            // 0x1B0(0x8)
	uint8                                        bDefineArc : 1;                                    // Mask: 0x1, PropSize: 0x10x1B8(0x1)
	uint8                                        Pad_2CA2[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryGenerator_Donut"));
		return Clss;
	}

};

// 0x108 (0x1A0 - 0x98)
// Class AIModule.EnvQueryGenerator_OnCircle
class UEnvQueryGenerator_OnCircle : public UEnvQueryGenerator_ProjectedPoints
{
public:
	struct FAIDataProviderFloatValue             CircleRadius;                                      // 0x98(0x30)
	struct FAIDataProviderFloatValue             SpaceBetween;                                      // 0xC8(0x30)
	struct FEnvDirection                         ArcDirection;                                      // 0xF8(0x20)
	struct FAIDataProviderFloatValue             ArcAngle;                                          // 0x118(0x30)
	float                                        AngleRadians;                                      // 0x148(0x4)
	uint8                                        Pad_2CA3[0x4];                                     // Fixing Size After Last Property
	TSubclassOf<class UEnvQueryContext>          CircleCenter;                                      // 0x150(0x8)
	struct FEnvTraceData                         TraceData;                                         // 0x158(0x40)
	uint8                                        bDefineArc : 1;                                    // Mask: 0x1, PropSize: 0x10x198(0x1)
	uint8                                        Pad_2CA4[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryGenerator_OnCircle"));
		return Clss;
	}

};

// 0x68 (0x100 - 0x98)
// Class AIModule.EnvQueryGenerator_SimpleGrid
class UEnvQueryGenerator_SimpleGrid : public UEnvQueryGenerator_ProjectedPoints
{
public:
	struct FAIDataProviderFloatValue             GridSize;                                          // 0x98(0x30)
	struct FAIDataProviderFloatValue             SpaceBetween;                                      // 0xC8(0x30)
	TSubclassOf<class UEnvQueryContext>          GenerateAround;                                    // 0xF8(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryGenerator_SimpleGrid"));
		return Clss;
	}

};

// 0x68 (0x168 - 0x100)
// Class AIModule.EnvQueryGenerator_PathingGrid
class UEnvQueryGenerator_PathingGrid : public UEnvQueryGenerator_SimpleGrid
{
public:
	struct FAIDataProviderBoolValue              PathToItem;                                        // 0x100(0x30)
	TSubclassOf<class UNavigationQueryFilter>    NavigationFilter;                                  // 0x130(0x8)
	struct FAIDataProviderFloatValue             ScanRangeMultiplier;                               // 0x138(0x30)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryGenerator_PathingGrid"));
		return Clss;
	}

};

// 0x10 (0x180 - 0x170)
// Class AIModule.EnvQueryTest_Distance
class UEnvQueryTest_Distance : public UEnvQueryTest
{
public:
	enum class EEnvTestDistance                  TestMode;                                          // 0x170(0x1)
	uint8                                        Pad_2CA5[0x7];                                     // Fixing Size After Last Property
	TSubclassOf<class UEnvQueryContext>          DistanceTo;                                        // 0x178(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryTest_Distance"));
		return Clss;
	}

};

// 0x48 (0x1B8 - 0x170)
// Class AIModule.EnvQueryTest_Dot
class UEnvQueryTest_Dot : public UEnvQueryTest
{
public:
	struct FEnvDirection                         LineA;                                             // 0x170(0x20)
	struct FEnvDirection                         LineB;                                             // 0x190(0x20)
	enum class EEnvTestDot                       TestMode;                                          // 0x1B0(0x1)
	bool                                         bAbsoluteValue;                                    // 0x1B1(0x1)
	uint8                                        Pad_2CA6[0x6];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryTest_Dot"));
		return Clss;
	}

};

// 0x30 (0x1A0 - 0x170)
// Class AIModule.EnvQueryTest_GameplayTags
class UEnvQueryTest_GameplayTags : public UEnvQueryTest
{
public:
	enum class EGameplayContainerMatchType       TagsToMatch;                                       // 0x170(0x1)
	uint8                                        Pad_2CA7[0x7];                                     // Fixing Size After Last Property
	struct FGameplayTagContainer                 GameplayTags;                                      // 0x178(0x28)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryTest_GameplayTags"));
		return Clss;
	}

};

// 0xD8 (0x248 - 0x170)
// Class AIModule.EnvQueryTest_Pathfinding
class UEnvQueryTest_Pathfinding : public UEnvQueryTest
{
public:
	enum class EEnvTestPathfinding               TestMode;                                          // 0x170(0x1)
	uint8                                        Pad_2CA8[0x7];                                     // Fixing Size After Last Property
	TSubclassOf<class UEnvQueryContext>          Context;                                           // 0x178(0x8)
	struct FAIDataProviderBoolValue              PathFromContext;                                   // 0x180(0x30)
	struct FAIDataProviderBoolValue              SkipUnreachable;                                   // 0x1B0(0x30)
	struct FAIDataProviderIntValue               MaxNumPathSegments;                                // 0x1E0(0x30)
	struct FAIDataProviderBoolValue              PassThroughUnreachable;                            // 0x210(0x30)
	TSubclassOf<class UNavigationQueryFilter>    FilterClass;                                       // 0x240(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryTest_Pathfinding"));
		return Clss;
	}

};

// 0x30 (0x278 - 0x248)
// Class AIModule.EnvQueryTest_PathfindingBatch
class UEnvQueryTest_PathfindingBatch : public UEnvQueryTest_Pathfinding
{
public:
	struct FAIDataProviderFloatValue             ScanRangeMultiplier;                               // 0x248(0x30)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryTest_PathfindingBatch"));
		return Clss;
	}

};

// 0x0 (0x170 - 0x170)
// Class AIModule.EnvQueryTest_Random
class UEnvQueryTest_Random : public UEnvQueryTest
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryTest_Random"));
		return Clss;
	}

};

// 0xD8 (0x248 - 0x170)
// Class AIModule.EnvQueryTest_Trace
class UEnvQueryTest_Trace : public UEnvQueryTest
{
public:
	struct FEnvTraceData                         TraceData;                                         // 0x170(0x40)
	struct FAIDataProviderBoolValue              TraceFromContext;                                  // 0x1B0(0x30)
	struct FAIDataProviderFloatValue             ItemHeightOffset;                                  // 0x1E0(0x30)
	struct FAIDataProviderFloatValue             ContextHeightOffset;                               // 0x210(0x30)
	TSubclassOf<class UEnvQueryContext>          Context;                                           // 0x240(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryTest_Trace"));
		return Clss;
	}

};

// 0x18 (0x40 - 0x28)
// Class AIModule.EnvQueryOption
class UEnvQueryOption : public UObject
{
public:
	class UEnvQueryGenerator*                    Generator;                                         // 0x28(0x8)
	TArray<class UEnvQueryTest*>                 Tests;                                             // 0x30(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EnvQueryOption"));
		return Clss;
	}

};

// 0x18 (0x5D0 - 0x5B8)
// Class AIModule.EQSRenderingComponent
class UEQSRenderingComponent : public UPrimitiveComponent
{
public:
	uint8                                        Pad_2CA9[0x18];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EQSRenderingComponent"));
		return Clss;
	}

};

// 0x68 (0x640 - 0x5D8)
// Class AIModule.EQSTestingPawn
class AEQSTestingPawn : public ACharacter
{
public:
	uint8                                        Pad_2CAA[0x8];                                     // Fixing Size After Last Property
	class UEnvQuery*                             QueryTemplate;                                     // 0x5E0(0x8)
	TArray<struct FEnvNamedValue>                QueryParams;                                       // 0x5E8(0x10)
	TSubclassOf<class UEnvQueryContext>          ContextToLinkWithThis;                             // 0x5F8(0x8)
	float                                        TimeLimitPerStep;                                  // 0x600(0x4)
	int32                                        StepToDebugDraw;                                   // 0x604(0x4)
	enum class EEnvQueryHightlightMode           HighlightMode;                                     // 0x608(0x1)
	uint8                                        Pad_2CAB[0x3];                                     // Fixing Size After Last Property
	uint8                                        bDrawLabels : 1;                                   // Mask: 0x1, PropSize: 0x10x60C(0x1)
	uint8                                        bDrawFailedItems : 1;                              // Mask: 0x2, PropSize: 0x10x60C(0x1)
	uint8                                        bReRunQueryOnlyOnFinishedMove : 1;                 // Mask: 0x4, PropSize: 0x10x60C(0x1)
	uint8                                        bShouldBeVisibleInGame : 1;                        // Mask: 0x8, PropSize: 0x10x60C(0x1)
	uint8                                        BitPad_19B : 4;                                    // Fixing Bit-Field Size
	uint8                                        Pad_2CAC[0x3];                                     // Fixing Size After Last Property
	enum class EEnvQueryRunMode                  QueryingMode;                                      // 0x610(0x1)
	uint8                                        Pad_2CAD[0x2F];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("EQSTestingPawn"));
		return Clss;
	}

};

// 0x50 (0x308 - 0x2B8)
// Class AIModule.CrowdFollowingComponent
class UCrowdFollowingComponent : public UPathFollowingComponent
{
public:
	uint8                                        Pad_2CAE[0x8];                                     // Fixing Size After Last Property
	struct FVector                               CrowdAgentMoveDirection;                           // 0x2C0(0xC)
	uint8                                        Pad_2CAF[0x4];                                     // Fixing Size After Last Property
	class UCharacterMovementComponent*           CharacterMovement;                                 // 0x2D0(0x8)
	struct FNavAvoidanceMask                     AvoidanceGroup;                                    // 0x2D8(0x4)
	struct FNavAvoidanceMask                     GroupsToAvoid;                                     // 0x2DC(0x4)
	struct FNavAvoidanceMask                     GroupsToIgnore;                                    // 0x2E0(0x4)
	uint8                                        Pad_2CB0[0x24];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("CrowdFollowingComponent"));
		return Clss;
	}

	void SuspendCrowdSteering(bool bSuspend);
};

// 0x0 (0x90 - 0x90)
// Class AIModule.PawnAction_BlueprintBase
class UPawnAction_BlueprintBase : public UPawnAction
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("PawnAction_BlueprintBase"));
		return Clss;
	}

	void ActionTick(class APawn* ControlledPawn, float DeltaSeconds);
	void ActionStart(class APawn* ControlledPawn);
	void ActionResume(class APawn* ControlledPawn);
	void ActionPause(class APawn* ControlledPawn);
	void ActionFinished(class APawn* ControlledPawn, enum class EPawnActionResult WithResult);
};

// 0x50 (0xE0 - 0x90)
// Class AIModule.PawnAction_Move
class UPawnAction_Move : public UPawnAction
{
public:
	class AActor*                                GoalActor;                                         // 0x90(0x8)
	struct FVector                               GoalLocation;                                      // 0x98(0xC)
	float                                        AcceptableRadius;                                  // 0xA4(0x4)
	TSubclassOf<class UNavigationQueryFilter>    FilterClass;                                       // 0xA8(0x8)
	uint8                                        bAllowStrafe : 1;                                  // Mask: 0x1, PropSize: 0x10xB0(0x1)
	uint8                                        bFinishOnOverlap : 1;                              // Mask: 0x2, PropSize: 0x10xB0(0x1)
	uint8                                        bUsePathfinding : 1;                               // Mask: 0x4, PropSize: 0x10xB0(0x1)
	uint8                                        bAllowPartialPath : 1;                             // Mask: 0x8, PropSize: 0x10xB0(0x1)
	uint8                                        bProjectGoalToNavigation : 1;                      // Mask: 0x10, PropSize: 0x10xB0(0x1)
	uint8                                        bUpdatePathToGoal : 1;                             // Mask: 0x20, PropSize: 0x10xB0(0x1)
	uint8                                        bAbortChildActionOnPathChange : 1;                 // Mask: 0x40, PropSize: 0x10xB0(0x1)
	uint8                                        Pad_2CB3[0x2F];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("PawnAction_Move"));
		return Clss;
	}

};

// 0x20 (0xB0 - 0x90)
// Class AIModule.PawnAction_Repeat
class UPawnAction_Repeat : public UPawnAction
{
public:
	class UPawnAction*                           ActionToRepeat;                                    // 0x90(0x8)
	class UPawnAction*                           RecentActionCopy;                                  // 0x98(0x8)
	enum class EPawnActionFailHandling           ChildFailureHandlingMode;                          // 0xA0(0x1)
	uint8                                        Pad_2CB4[0xF];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("PawnAction_Repeat"));
		return Clss;
	}

};

// 0x28 (0xB8 - 0x90)
// Class AIModule.PawnAction_Sequence
class UPawnAction_Sequence : public UPawnAction
{
public:
	TArray<class UPawnAction*>                   ActionSequence;                                    // 0x90(0x10)
	enum class EPawnActionFailHandling           ChildFailureHandlingMode;                          // 0xA0(0x1)
	uint8                                        Pad_2CB5[0x7];                                     // Fixing Size After Last Property
	class UPawnAction*                           RecentActionCopy;                                  // 0xA8(0x8)
	uint8                                        Pad_2CB6[0x8];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("PawnAction_Sequence"));
		return Clss;
	}

};

// 0x10 (0xA0 - 0x90)
// Class AIModule.PawnAction_Wait
class UPawnAction_Wait : public UPawnAction
{
public:
	float                                        TimeToWait;                                        // 0x90(0x4)
	uint8                                        Pad_2CB7[0xC];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("PawnAction_Wait"));
		return Clss;
	}

};

// 0x48 (0x110 - 0xC8)
// Class AIModule.PawnSensingComponent
class UPawnSensingComponent : public UActorComponent
{
public:
	float                                        HearingThreshold;                                  // 0xC8(0x4)
	float                                        LOSHearingThreshold;                               // 0xCC(0x4)
	float                                        SightRadius;                                       // 0xD0(0x4)
	float                                        SensingInterval;                                   // 0xD4(0x4)
	float                                        HearingMaxSoundAge;                                // 0xD8(0x4)
	uint8                                        bEnableSensingUpdates : 1;                         // Mask: 0x1, PropSize: 0x10xDC(0x1)
	uint8                                        bOnlySensePlayers : 1;                             // Mask: 0x2, PropSize: 0x10xDC(0x1)
	uint8                                        bSeePawns : 1;                                     // Mask: 0x4, PropSize: 0x10xDC(0x1)
	uint8                                        bHearNoises : 1;                                   // Mask: 0x8, PropSize: 0x10xDC(0x1)
	uint8                                        BitPad_19C : 4;                                    // Fixing Bit-Field Size
	uint8                                        Pad_2CB8[0xB];                                     // Fixing Size After Last Property
	UMulticastInlineDelegateProperty_            OnSeePawn;                                         // 0xE8(0x10)
	UMulticastInlineDelegateProperty_            OnHearNoise;                                       // 0xF8(0x10)
	float                                        PeripheralVisionAngle;                             // 0x108(0x4)
	float                                        PeripheralVisionCosine;                            // 0x10C(0x4)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("PawnSensingComponent"));
		return Clss;
	}

	void SetSensingUpdatesEnabled(bool bEnabled);
	void SetSensingInterval(float NewSensingInterval);
	void SetPeripheralVisionAngle(float NewPeripheralVisionAngle);
	void SeePawnDelegate__DelegateSignature(class APawn* Pawn);
	void HearNoiseDelegate__DelegateSignature(class APawn* Instigator, struct FVector& Location, float Volume);
	float GetPeripheralVisionCosine();
	float GetPeripheralVisionAngle();
};

}


