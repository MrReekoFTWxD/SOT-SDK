#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x28 - 0x28)
// Class AIActionFramework.AIActionActivity
class UAIActionActivity : public UObject
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIActionActivity"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIActionFramework.AIActionActivity_Follow
class UAIActionActivity_Follow : public UAIActionActivity
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIActionActivity_Follow"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIActionFramework.AIActionActivity_Idle
class UAIActionActivity_Idle : public UAIActionActivity
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIActionActivity_Idle"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIActionFramework.AIActionActivity_Quest
class UAIActionActivity_Quest : public UAIActionActivity
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIActionActivity_Quest"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIActionFramework.AIActionContextTag
class UAIActionContextTag : public UObject
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIActionContextTag"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIActionFramework.AIActionInstigatorInterface
class UAIActionInstigatorInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIActionInstigatorInterface"));
		return Clss;
	}

};

// 0x28 (0xF0 - 0xC8)
// Class AIActionFramework.AIActionInstigatorComponent
class UAIActionInstigatorComponent : public UActorComponent
{
public:
	uint8                                        Pad_2BA4[0x8];                                     // Fixing Size After Last Property
	TArray<TSubclassOf<class UAIActionRole>>     CurrentRoles;                                      // 0xD0(0x10)
	TSubclassOf<class UAIActionActivity>         InitialActivity;                                   // 0xE0(0x8)
	TSubclassOf<class UAIActionActivity>         CurrentActivity;                                   // 0xE8(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIActionInstigatorComponent"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIActionFramework.AIActionRole
class UAIActionRole : public UObject
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIActionRole"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIActionFramework.AIActionSpotInterface
class UAIActionSpotInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIActionSpotInterface"));
		return Clss;
	}

};

// 0x58 (0x120 - 0xC8)
// Class AIActionFramework.AIActionSpotComponent
class UAIActionSpotComponent : public UActorComponent
{
public:
	uint8                                        Pad_2BA5[0x8];                                     // Fixing Size After Last Property
	TArray<TSubclassOf<class UAIActionRole>>     SupportedRoles;                                    // 0xD0(0x10)
	TArray<TSubclassOf<class UAIActionActivity>> SupportedActivities;                               // 0xE0(0x10)
	TArray<TSubclassOf<class UAIActionContextTag>> ContextTags;                                       // 0xF0(0x10)
	TSubclassOf<class UAnimInstance>             CustomAnimInstance;                                // 0x100(0x8)
	uint8                                        Pad_2BA6[0x18];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIActionSpotComponent"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIActionFramework.AIActionSpotServiceInterface
class UAIActionSpotServiceInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIActionSpotServiceInterface"));
		return Clss;
	}

};

// 0x68 (0x90 - 0x28)
// Class AIActionFramework.AIActionSpotService
class UAIActionSpotService : public UObject
{
public:
	uint8                                        Pad_2BA7[0x68];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIActionSpotService"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIActionFramework.DockableRotationOverrideInterface
class UDockableRotationOverrideInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("DockableRotationOverrideInterface"));
		return Clss;
	}

};

// 0x10 (0xD8 - 0xC8)
// Class AIActionFramework.DockableRotationOverrideComponent
class UDockableRotationOverrideComponent : public UActorComponent
{
public:
	uint8                                        Pad_2BA8[0x8];                                     // Fixing Size After Last Property
	bool                                         KeepOwnerRotationWhileDocked;                      // 0xD0(0x1)
	uint8                                        Pad_2BA9[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("DockableRotationOverrideComponent"));
		return Clss;
	}

};

}


