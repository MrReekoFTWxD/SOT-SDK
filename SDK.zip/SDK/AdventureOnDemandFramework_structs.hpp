#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// ENUMS
//---------------------------------------------------------------------------------------------------------------------

enum class EAdventureOnDemandVoyageCategoryType : uint8
{
	Default                        = 0,
	LimitedVoyages                 = 1,
	EAdventureOnDemandVoyageCategoryType_MAX = 2,
};

enum class EAdventureOnDemandDiveToQuestAvailability : uint8
{
	Available                      = 0,
	Blocked_Tutorial               = 1,
	Blocked_Cooldown               = 2,
	EAdventureOnDemandDiveToQuestAvailability_MAX = 3,
};

enum class EAdventureOnDemandSailToQuestAvailability : uint8
{
	Available                      = 0,
	Blocked_WorldEvent             = 1,
	EAdventureOnDemandSailToQuestAvailability_MAX = 2,
};

enum class EOnDemandQuestResumeConditionMetReason : uint8
{
	ArrivalTunnelComplete          = 0,
	DiveCancelled                  = 1,
	CrewNotDiving                  = 2,
	TunnelFailed                   = 3,
	None                           = 4,
	EOnDemandQuestResumeConditionMetReason_MAX = 5,
};


//---------------------------------------------------------------------------------------------------------------------
// STRUCTS
//---------------------------------------------------------------------------------------------------------------------

// 0x18 (0x18 - 0x0)
// ScriptStruct AdventureOnDemandFramework.TradingCompanyPopUpBackgroundEntry
struct FTradingCompanyPopUpBackgroundEntry
{
public:
	TSubclassOf<class UCompany>                  TradingCompany;                                    // 0x0(0x8)
	TArray<struct FStringAssetReference>         BackgroundImages;                                  // 0x8(0x10)
};

// 0x28 (0x28 - 0x0)
// ScriptStruct AdventureOnDemandFramework.AdventureOnDemandVoyageDiscoveryPageMysteryProposal
struct FAdventureOnDemandVoyageDiscoveryPageMysteryProposal
{
public:
	class FName                                  MysteryName;                                       // 0x0(0x8)
	TArray<class UInteractionPrerequisiteBase*>  Prerequisites;                                     // 0x8(0x10)
	TSubclassOf<class UVoyageProposalDesc>       MysteryProposalTemplate;                           // 0x18(0x8)
	bool                                         SelectTallTales;                                   // 0x20(0x1)
	uint8                                        Pad_37E1[0x7];                                     // Fixing Size Of Struct
};

// 0x18 (0x18 - 0x0)
// ScriptStruct AdventureOnDemandFramework.AdventureOnDemandTallTaleCheckpointProposal
struct FAdventureOnDemandTallTaleCheckpointProposal
{
public:
	TArray<class UInteractionPrerequisiteBase*>  Prerequisites;                                     // 0x0(0x10)
	TSubclassOf<class UVoyageProposalDesc>       Proposal;                                          // 0x10(0x8)
};

// 0x10 (0x10 - 0x0)
// ScriptStruct AdventureOnDemandFramework.AdventureOnDemandTallTaleCheckpoint
struct FAdventureOnDemandTallTaleCheckpoint
{
public:
	TArray<struct FAdventureOnDemandTallTaleCheckpointProposal> Proposals;                                         // 0x0(0x10)
};

// 0x70 (0x70 - 0x0)
// ScriptStruct AdventureOnDemandFramework.AdventureOnDemandTallTaleProposalGroup
struct FAdventureOnDemandTallTaleProposalGroup
{
public:
	struct FStringAssetReference                 BackgroundImageUrl;                                // 0x0(0x10)
	struct FStringAssetReference                 SmallBackgroundImageUrl;                           // 0x10(0x10)
	TArray<struct FQuestTableTallTaleReward>     Rewards;                                           // 0x20(0x10)
	TArray<class FText>                          LockedDescriptions;                                // 0x30(0x10)
	TArray<class UInteractionPrerequisiteBase*>  Prerequisites;                                     // 0x40(0x10)
	struct FPlayerStat                           StatForNewTag;                                     // 0x50(0x4)
	enum class EAdventureOnDemandSailToQuestAvailability SailToQuestAvailability;                           // 0x54(0x1)
	enum class EAdventureOnDemandDiveToQuestAvailability DiveToQuestAvailability;                           // 0x55(0x1)
	uint8                                        Pad_37E2[0x2];                                     // Fixing Size After Last Property
	TSubclassOf<class UVoyageProposalDesc>       InitialProposal;                                   // 0x58(0x8)
	TArray<struct FAdventureOnDemandTallTaleCheckpoint> Checkpoints;                                       // 0x60(0x10)
};

// 0x30 (0x30 - 0x0)
// ScriptStruct AdventureOnDemandFramework.AdventureOnDemandVoyageSelectionVoyageProposal
struct FAdventureOnDemandVoyageSelectionVoyageProposal
{
public:
	struct FFeatureFlag                          Feature;                                           // 0x0(0xC)
	uint8                                        Pad_37E3[0x4];                                     // Fixing Size After Last Property
	TArray<class UInteractionPrerequisiteBase*>  Prerequisites;                                     // 0x10(0x10)
	struct FPlayerStat                           StatForNewTag;                                     // 0x20(0x4)
	enum class EAdventureOnDemandSailToQuestAvailability SailToQuestAvailability;                           // 0x24(0x1)
	enum class EAdventureOnDemandDiveToQuestAvailability DiveToQuestAvailability;                           // 0x25(0x1)
	enum class EQuestTableVoyageType             VoyageType;                                        // 0x26(0x1)
	uint8                                        Pad_37E4[0x1];                                     // Fixing Size After Last Property
	TSubclassOf<class UVoyageProposalDesc>       Proposal;                                          // 0x28(0x8)
};

// 0x48 (0x48 - 0x0)
// ScriptStruct AdventureOnDemandFramework.AdventureOnDemandVoyageSelectionVoyageProposalGroup
struct FAdventureOnDemandVoyageSelectionVoyageProposalGroup
{
public:
	class FName                                  GroupName;                                         // 0x0(0x8)
	TSubclassOf<class UCompanyVoyageCategoryId>  CategoryId;                                        // 0x8(0x8)
	TSubclassOf<class UCompany>                  Company;                                           // 0x10(0x8)
	struct FFeatureFlag                          Feature;                                           // 0x18(0xC)
	enum class EAdventureOnDemandVoyageCategoryType CategoryType;                                      // 0x24(0x1)
	uint8                                        Pad_37E5[0x3];                                     // Fixing Size After Last Property
	TArray<class UInteractionPrerequisiteBase*>  Prerequisites;                                     // 0x28(0x10)
	TArray<struct FAdventureOnDemandVoyageSelectionVoyageProposal> Proposals;                                         // 0x38(0x10)
};

// 0x10 (0x10 - 0x0)
// ScriptStruct AdventureOnDemandFramework.VoyageHintPopupDescEntry
struct FVoyageHintPopupDescEntry
{
public:
	enum class EQuestType                        QuestType;                                         // 0x0(0x1)
	uint8                                        Pad_37E6[0x7];                                     // Fixing Size After Last Property
	class UPopUpMessageDesc*                     HintPopUpMessageDesc;                              // 0x8(0x8)
};

// 0x8 (0x8 - 0x0)
// ScriptStruct AdventureOnDemandFramework.ExtraSpawnDistanceByIslandType
struct FExtraSpawnDistanceByIslandType
{
public:
	enum class EIslandType                       IslandType;                                        // 0x0(0x1)
	uint8                                        Pad_37E7[0x3];                                     // Fixing Size After Last Property
	float                                        ExtraSpawnDistance;                                // 0x4(0x4)
};

// 0x18 (0x18 - 0x0)
// ScriptStruct AdventureOnDemandFramework.ExtraSpawnDistanceFromIsland
struct FExtraSpawnDistanceFromIsland
{
public:
	TSubclassOf<class UShipSize>                 ShipSize;                                          // 0x0(0x8)
	TArray<struct FExtraSpawnDistanceByIslandType> DistanceByIslandType;                              // 0x8(0x10)
};

// 0x0 (0x30 - 0x30)
// ScriptStruct AdventureOnDemandFramework.OnDemandQuestResumeConditionMetReasonQuestVariable
struct FOnDemandQuestResumeConditionMetReasonQuestVariable : public FQuestVariable
{
public:
};

// 0xF0 (0xF0 - 0x0)
// ScriptStruct AdventureOnDemandFramework.GameEventOnDemandBannerTextData
struct FGameEventOnDemandBannerTextData
{
public:
	TArray<TSubclassOf<class UGameEventType>>    GameEventTypes;                                    // 0x0(0x10)
	class FText                                  OnShipSunkBannerText;                              // 0x10(0x38)
	class FText                                  OnVoyageCancelledBannerText;                       // 0x48(0x38)
	class FText                                  OnGameEventCompletedBannerHeaderText;              // 0x80(0x38)
	class FText                                  OnGameEventCompletedBannerMessageText;             // 0xB8(0x38)
};

// 0x10 (0x10 - 0x0)
// ScriptStruct AdventureOnDemandFramework.GameEventOnDemandCompanyStatData
struct FGameEventOnDemandCompanyStatData
{
public:
	TSubclassOf<class UCompany>                  Company;                                           // 0x0(0x8)
	struct FPlayerStat                           Stat;                                              // 0x8(0x4)
	uint8                                        Pad_37E8[0x4];                                     // Fixing Size Of Struct
};

// 0x18 (0x18 - 0x0)
// ScriptStruct AdventureOnDemandFramework.QuestTableCompanyTutorialPrerequisites
struct FQuestTableCompanyTutorialPrerequisites
{
public:
	TSubclassOf<class UCompany>                  Company;                                           // 0x0(0x8)
	TArray<class UInteractionPrerequisiteBase*>  Prerequisites;                                     // 0x8(0x10)
};

// 0x138 (0x138 - 0x0)
// ScriptStruct AdventureOnDemandFramework.QuestTableBakedDiscoverTile
struct FQuestTableBakedDiscoverTile
{
public:
	struct FGuid                                 TileId;                                            // 0x0(0x10)
	class FText                                  CondensedTitle;                                    // 0x10(0x38)
	class FText                                  Title;                                             // 0x48(0x38)
	class FText                                  Subtitle;                                          // 0x80(0x38)
	class FText                                  Description;                                       // 0xB8(0x38)
	bool                                         HighSeasOnly;                                      // 0xF0(0x1)
	uint8                                        Pad_37E9[0x7];                                     // Fixing Size After Last Property
	struct FStringAssetReference                 BackgroundImageUrl;                                // 0xF8(0x10)
	struct FStringAssetReference                 PreviewTileIconImageUrl;                           // 0x108(0x10)
	struct FStringAssetReference                 BladeFrameImageURL;                                // 0x118(0x10)
	struct FStringAssetReference                 WatermarkImageUrl;                                 // 0x128(0x10)
};

// 0x10 (0x148 - 0x138)
// ScriptStruct AdventureOnDemandFramework.QuestTableBakedInfoDiscoverTile
struct FQuestTableBakedInfoDiscoverTile : public FQuestTableBakedDiscoverTile
{
public:
	class FString                                InfoTipIdClientConfigName;                         // 0x138(0x10)
};

// 0x8 (0x140 - 0x138)
// ScriptStruct AdventureOnDemandFramework.QuestTableBakedQuestDiscoverTile
struct FQuestTableBakedQuestDiscoverTile : public FQuestTableBakedDiscoverTile
{
public:
	TSubclassOf<class UVoyageProposalDesc>       Proposal;                                          // 0x138(0x8)
};

// 0x10 (0x10 - 0x0)
// ScriptStruct AdventureOnDemandFramework.AdventureOnDemandCrewReachedSurfaceEvent
struct FAdventureOnDemandCrewReachedSurfaceEvent
{
public:
	struct FGuid                                 CrewId;                                            // 0x0(0x10)
};

// 0x10 (0x10 - 0x0)
// ScriptStruct AdventureOnDemandFramework.AdventureOnDemandCrewReadyToResurfaceEvent
struct FAdventureOnDemandCrewReadyToResurfaceEvent
{
public:
	struct FGuid                                 CrewId;                                            // 0x0(0x10)
};

// 0x10 (0x10 - 0x0)
// ScriptStruct AdventureOnDemandFramework.AdventureOnDemandDiveCrewAlreadyAtDestinationEvent
struct FAdventureOnDemandDiveCrewAlreadyAtDestinationEvent
{
public:
	struct FGuid                                 CrewId;                                            // 0x0(0x10)
};

// 0x1 (0x1 - 0x0)
// ScriptStruct AdventureOnDemandFramework.AdventureOnDemandVoyageSurfaceTaleFinished
struct FAdventureOnDemandVoyageSurfaceTaleFinished
{
public:
	uint8                                        Pad_37EA[0x1];                                     // Fixing Size Of Struct
};

// 0x38 (0x38 - 0x0)
// ScriptStruct AdventureOnDemandFramework.ContendedResourceGameEventOnDemandArrivalTunnelWorkerFailedTelemetryEvent
struct FContendedResourceGameEventOnDemandArrivalTunnelWorkerFailedTelemetryEvent
{
public:
	struct FGuid                                 TunnelInstanceId;                                  // 0x0(0x10)
	class FString                                GameEventType;                                     // 0x10(0x10)
	TArray<class FString>                        InvalidReasons;                                    // 0x20(0x10)
	int32                                        NumLockedEvents;                                   // 0x30(0x4)
	int32                                        NumAvailableEvents;                                // 0x34(0x4)
};

// 0x18 (0x18 - 0x0)
// ScriptStruct AdventureOnDemandFramework.GameEventOnDemandArrivalTunnelWorkerCompletedTelemetryEvent
struct FGameEventOnDemandArrivalTunnelWorkerCompletedTelemetryEvent
{
public:
	struct FGuid                                 TunnelInstanceId;                                  // 0x0(0x10)
	double                                       ArrivalTunnelWorkerLifetimeSeconds;                // 0x10(0x8)
};

}


