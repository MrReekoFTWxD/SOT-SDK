#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x138 - 0x138)
// BlueprintGeneratedClass AIShipBattleGameEventOnDemand_OOS_Proposal.AIShipBattleGameEventOnDemand_OOS_Proposal_C
class UAIShipBattleGameEventOnDemand_OOS_Proposal_C : public UGameEventOnDemandVoyageProposalDesc
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipBattleGameEventOnDemand_OOS_Proposal_C"));
		return Clss;
	}

};

}


