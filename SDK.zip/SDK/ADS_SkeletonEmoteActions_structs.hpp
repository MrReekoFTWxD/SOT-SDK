#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// ENUMS
//---------------------------------------------------------------------------------------------------------------------


//---------------------------------------------------------------------------------------------------------------------
// STRUCTS
//---------------------------------------------------------------------------------------------------------------------

// 0x10 (0x10 - 0x0)
// AnimDataEntryStruct ADS_SkeletonEmoteActions.ADS_SkeletonEmoteActions
struct FADS_SkeletonEmoteActions
{
public:
	TArray<struct FAthenaAnimationSkeletonEmoteActionAnimations> SkeletonEmoteActions_11_C3B3D3934CED931AA0DDF4BFE901E9B0; // 0x0(0x10)
};

}


