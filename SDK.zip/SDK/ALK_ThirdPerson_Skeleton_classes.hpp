#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x28 - 0x28)
// BlueprintGeneratedClass ALK_ThirdPerson_Skeleton.ALK_ThirdPerson_Skeleton_C
class UALK_ThirdPerson_Skeleton_C : public UAnimationDataStoreId
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ALK_ThirdPerson_Skeleton_C"));
		return Clss;
	}

};

}


