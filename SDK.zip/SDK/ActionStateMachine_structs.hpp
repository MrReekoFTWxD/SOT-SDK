#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// ENUMS
//---------------------------------------------------------------------------------------------------------------------

enum class EActionStateMachineTrackId : uint8
{
	Locomotion                     = 0,
	Overlay                        = 1,
	ItemUse                        = 2,
	ForcedMovement                 = 3,
	Migration                      = 4,
	Count                          = 5,
	Invalid                        = 6,
	EActionStateMachineTrackId_MAX = 7,
};

enum class EActionPredictionType : uint8
{
	Predicted                      = 0,
	NotPredicted                   = 1,
	EActionPredictionType_MAX      = 2,
};

enum class EActionStatePriority : uint8
{
	Overrides                      = 0,
	Overriden                      = 1,
	EActionStatePriority_MAX       = 2,
};


//---------------------------------------------------------------------------------------------------------------------
// STRUCTS
//---------------------------------------------------------------------------------------------------------------------

// 0x28 (0x28 - 0x0)
// ScriptStruct ActionStateMachine.ActionStateConstructionInfo
struct FActionStateConstructionInfo
{
public:
	TSubclassOf<class UActionStateId>            Id;                                                // 0x0(0x8)
	class UScriptStruct*                         Type;                                              // 0x8(0x8)
	uint8                                        Pad_2928[0x18];                                    // Fixing Size Of Struct
};

// 0x8 (0x30 - 0x28)
// ScriptStruct ActionStateMachine.ActorActionStateConstructionInfo
struct FActorActionStateConstructionInfo : public FActionStateConstructionInfo
{
public:
	TWeakObjectPtr<class AActor>                 ActorOwner;                                        // 0x28(0x8)
};

// 0x30 (0x30 - 0x0)
// ScriptStruct ActionStateMachine.ActionStateSerialisableData
struct FActionStateSerialisableData
{
public:
	uint8                                        Pad_2929[0x8];                                     // Fixing Size After Last Property
	TSubclassOf<class UActionStateId>            Id;                                                // 0x8(0x8)
	class UScriptStruct*                         Type;                                              // 0x10(0x8)
	uint8                                        Pad_292A[0x18];                                    // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// ScriptStruct ActionStateMachine.ActionStateMessage
struct FActionStateMessage
{
public:
	uint8                                        Pad_292B[0x8];                                     // Fixing Size After Last Property
	class UScriptStruct*                         Type;                                              // 0x8(0x8)
};

// 0x1 (0x1 - 0x0)
// ScriptStruct ActionStateMachine.ActionStateChangeRequestId
struct FActionStateChangeRequestId
{
public:
	uint8                                        Raw;                                               // 0x0(0x1)
};

// 0x40 (0x40 - 0x0)
// ScriptStruct ActionStateMachine.SerialisedActionStateInfo
struct FSerialisedActionStateInfo
{
public:
	uint8                                        Pad_292C[0x40];                                    // Fixing Size Of Struct
};

// 0x18 (0x18 - 0x0)
// ScriptStruct ActionStateMachine.SerialisedActionStateMessage
struct FSerialisedActionStateMessage
{
public:
	uint8                                        Pad_292D[0x18];                                    // Fixing Size Of Struct
};

// 0x140 (0x140 - 0x0)
// ScriptStruct ActionStateMachine.SerialisedConstructionInfoStore
struct FSerialisedConstructionInfoStore
{
public:
	struct FSerialisedActionStateInfo            SerialisedConstructionInfo;                        // 0x0(0x40)
	uint8                                        Pad_292E[0x100];                                   // Fixing Size Of Struct
};

// 0x150 (0x150 - 0x0)
// ScriptStruct ActionStateMachine.ResetStateMachineRpc
struct FResetStateMachineRpc
{
public:
	struct FActionStateChangeRequestId           LatestEpochIds;                                    // 0x0(0x1)
	uint8                                        Pad_292F[0x4];                                     // Fixing Size After Last Property
	struct FActionStateChangeRequestId           LatestRequestIds;                                  // 0x5(0x1)
	uint8                                        Pad_2930[0xA];                                     // Fixing Size After Last Property
	struct FSerialisedConstructionInfoStore      PerTrackConstructionInfoStore;                     // 0x10(0x140)
};

// 0x8 (0x38 - 0x30)
// ScriptStruct ActionStateMachine.TestActionStateSerialisableData
struct FTestActionStateSerialisableData : public FActionStateSerialisableData
{
public:
	int32                                        IntProp;                                           // 0x30(0x4)
	uint8                                        Pad_2931[0x4];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// ScriptStruct ActionStateMachine.ActionStatePriorityRelationship
struct FActionStatePriorityRelationship
{
public:
	TSubclassOf<class UActionStateId>            State;                                             // 0x0(0x8)
	enum class EActionStatePriority              Priority;                                          // 0x8(0x1)
	uint8                                        Pad_2932[0x7];                                     // Fixing Size Of Struct
};

// 0x18 (0x18 - 0x0)
// ScriptStruct ActionStateMachine.ActionStatePriorityList
struct FActionStatePriorityList
{
public:
	TSubclassOf<class UActionStateId>            State;                                             // 0x0(0x8)
	TArray<struct FActionStatePriorityRelationship> Entries;                                           // 0x8(0x10)
};

// 0xA0 (0xA0 - 0x0)
// ScriptStruct ActionStateMachine.ActionStatePriorityTable
struct FActionStatePriorityTable
{
public:
	uint8                                        Pad_2933[0xA0];                                    // Fixing Size Of Struct
};

// 0x8 (0x8 - 0x0)
// ScriptStruct ActionStateMachine.InnerWithObjTestStruct
struct FInnerWithObjTestStruct
{
public:
	class UObject*                               ObjPointer;                                        // 0x0(0x8)
};

// 0x20 (0x48 - 0x28)
// ScriptStruct ActionStateMachine.TestActionStateConstructionInfoWithObjPointers
struct FTestActionStateConstructionInfoWithObjPointers : public FActionStateConstructionInfo
{
public:
	class UObject*                               ObjPointer;                                        // 0x28(0x8)
	struct FInnerWithObjTestStruct               Inner;                                             // 0x30(0x8)
	TArray<class UObject*>                       Array;                                             // 0x38(0x10)
};

// 0x18 (0x18 - 0x0)
// ScriptStruct ActionStateMachine.InnerTestStruct
struct FInnerTestStruct
{
public:
	bool                                         BoolProp;                                          // 0x0(0x1)
	uint8                                        Pad_2934[0x7];                                     // Fixing Size After Last Property
	class FString                                StringProp;                                        // 0x8(0x10)
};

// 0x20 (0x48 - 0x28)
// ScriptStruct ActionStateMachine.TestActionStateConstructionInfoWithInner
struct FTestActionStateConstructionInfoWithInner : public FActionStateConstructionInfo
{
public:
	float                                        FloatProp;                                         // 0x28(0x4)
	uint8                                        Pad_2935[0x4];                                     // Fixing Size After Last Property
	struct FInnerTestStruct                      InnerStruct;                                       // 0x30(0x18)
};

// 0x8 (0x30 - 0x28)
// ScriptStruct ActionStateMachine.TestActionStateConstructionInfo
struct FTestActionStateConstructionInfo : public FActionStateConstructionInfo
{
public:
	int32                                        IntProp;                                           // 0x28(0x4)
	uint8                                        Pad_2936[0x4];                                     // Fixing Size Of Struct
};

// 0x1 (0x1 - 0x0)
// ScriptStruct ActionStateMachine.EventWaitingToSpawnActionStateEndedClient
struct FEventWaitingToSpawnActionStateEndedClient
{
public:
	uint8                                        Pad_2937[0x1];                                     // Fixing Size Of Struct
};

// 0x1 (0x1 - 0x0)
// ScriptStruct ActionStateMachine.EventWaitingToSpawnActionStateStartedClient
struct FEventWaitingToSpawnActionStateStartedClient
{
public:
	uint8                                        Pad_2938[0x1];                                     // Fixing Size Of Struct
};

// 0x1 (0x1 - 0x0)
// ScriptStruct ActionStateMachine.EventFirstPersonAnimaticActionStateEndedClient
struct FEventFirstPersonAnimaticActionStateEndedClient
{
public:
	uint8                                        Pad_2939[0x1];                                     // Fixing Size Of Struct
};

// 0x0 (0x30 - 0x30)
// ScriptStruct ActionStateMachine.NullActionStateConstructionInfo
struct FNullActionStateConstructionInfo : public FActorActionStateConstructionInfo
{
public:
};

// 0x0 (0x10 - 0x10)
// ScriptStruct ActionStateMachine.TestActionStateMessage2
struct FTestActionStateMessage2 : public FActionStateMessage
{
public:
};

// 0x8 (0x18 - 0x10)
// ScriptStruct ActionStateMachine.TestActionStateMessage
struct FTestActionStateMessage : public FActionStateMessage
{
public:
	int32                                        TestProperty;                                      // 0x10(0x4)
	uint8                                        Pad_293A[0x4];                                     // Fixing Size Of Struct
};

// 0x8 (0x38 - 0x30)
// ScriptStruct ActionStateMachine.TestActorActionStateConstructionInfo
struct FTestActorActionStateConstructionInfo : public FActorActionStateConstructionInfo
{
public:
	int32                                        IntProp;                                           // 0x30(0x4)
	uint8                                        Pad_293B[0x4];                                     // Fixing Size Of Struct
};

}


