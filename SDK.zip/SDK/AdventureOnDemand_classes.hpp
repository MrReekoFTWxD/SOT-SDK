#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x310 (0x6D8 - 0x3C8)
// Class AdventureOnDemand.AdventureOnDemandService
class AAdventureOnDemandService : public AActor
{
public:
	uint8                                        Pad_37C5[0x10];                                    // Fixing Size After Last Property
	class UAdventureOnDemandServiceParams*       Params;                                            // 0x3D8(0x8)
	class UAdventureOnDemandVoyageSelectionDataAsset* VoyageSelectionDataAsset;                          // 0x3E0(0x8)
	class UQuestTableAdventureOnDemandParams*    QuestTableAdventureOnDemandParams;                 // 0x3E8(0x8)
	class UTradingCompanyPopUpBackgroundCollectionDataAsset* TradingCompanyPopUpBackgroundCollection;           // 0x3F0(0x8)
	uint8                                        Pad_37C6[0xA0];                                    // Fixing Size After Last Property
	TArray<struct FAdventureOnDemandServiceCrewEntry> DiveToTunnelEntries;                               // 0x498(0x10)
	TArray<struct FAdventureOnDemandServiceCrewEntry> LeaveTunnelEntries;                                // 0x4A8(0x10)
	TArray<struct FGuid>                         CrewsDivingToTunnel;                               // 0x4B8(0x10)
	TArray<struct FGuid>                         CrewsInArrivalTunnel;                              // 0x4C8(0x10)
	TArray<struct FGuid>                         CrewsOnCooldown;                                   // 0x4D8(0x10)
	uint8                                        Pad_37C7[0x1F0];                                   // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandService"));
		return Clss;
	}

};

// 0x128 (0x158 - 0x30)
// Class AdventureOnDemand.GameEventOnDemandArrivalTunnelWorkerBase
class UGameEventOnDemandArrivalTunnelWorkerBase : public UAdventureOnDemandArrivalTunnelWorkerBase
{
public:
	float                                        TriggerTunnelFailureTimeout;                       // 0x30(0x4)
	float                                        MinRangeFromTarget;                                // 0x34(0x4)
	float                                        MaxRangeFromTarget;                                // 0x38(0x4)
	float                                        SubsequentCrewJoinRadiusModifier;                  // 0x3C(0x4)
	TSubclassOf<class UGameEventType>            GameEventType;                                     // 0x40(0x8)
	uint8                                        Pad_37C8[0xE0];                                    // Fixing Size After Last Property
	class UVoyageDescDataAsset*                  LeaveTunnelVoyageDesc;                             // 0x128(0x8)
	uint8                                        Pad_37C9[0x14];                                    // Fixing Size After Last Property
	float                                        RetryRequestEventFrequency;                        // 0x144(0x4)
	uint8                                        Pad_37CA[0x10];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("GameEventOnDemandArrivalTunnelWorkerBase"));
		return Clss;
	}

};

// 0x10 (0x168 - 0x158)
// Class AdventureOnDemand.AIShipBattleGameEventOnDemandArrivalTunnelWorker
class UAIShipBattleGameEventOnDemandArrivalTunnelWorker : public UGameEventOnDemandArrivalTunnelWorkerBase
{
public:
	uint8                                        Pad_37CB[0x10];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipBattleGameEventOnDemandArrivalTunnelWorker"));
		return Clss;
	}

};

// 0x30 (0x188 - 0x158)
// Class AdventureOnDemand.IslandBasedGameEventOnDemandArrivalTunnelWorker
class UIslandBasedGameEventOnDemandArrivalTunnelWorker : public UGameEventOnDemandArrivalTunnelWorkerBase
{
public:
	bool                                         UseSpawnDistanceFromIslandForResurfaceRadius;      // 0x158(0x1)
	uint8                                        Pad_37CC[0x17];                                    // Fixing Size After Last Property
	float                                        ResurfaceMaxRadiusModifier;                        // 0x170(0x4)
	uint8                                        Pad_37CD[0x14];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("IslandBasedGameEventOnDemandArrivalTunnelWorker"));
		return Clss;
	}

};

// 0x10 (0x198 - 0x188)
// Class AdventureOnDemand.AggressiveGhostShipsEncounterOnDemandArrivalTunnelWorker
class UAggressiveGhostShipsEncounterOnDemandArrivalTunnelWorker : public UIslandBasedGameEventOnDemandArrivalTunnelWorker
{
public:
	uint8                                        Pad_37CE[0x10];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AggressiveGhostShipsEncounterOnDemandArrivalTunnelWorker"));
		return Clss;
	}

};

// 0x10 (0x198 - 0x188)
// Class AdventureOnDemand.AshenLordEventOnDemandArrivalTunnelWorker
class UAshenLordEventOnDemandArrivalTunnelWorker : public UIslandBasedGameEventOnDemandArrivalTunnelWorker
{
public:
	uint8                                        Pad_37CF[0x10];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AshenLordEventOnDemandArrivalTunnelWorker"));
		return Clss;
	}

};

// 0x18 (0x1A0 - 0x188)
// Class AdventureOnDemand.ContendedResourceGameEventOnDemandArrivalTunnelWorker
class UContendedResourceGameEventOnDemandArrivalTunnelWorker : public UIslandBasedGameEventOnDemandArrivalTunnelWorker
{
public:
	uint8                                        Pad_37D0[0x18];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ContendedResourceGameEventOnDemandArrivalTunnelWorker"));
		return Clss;
	}

};

// 0x0 (0x1A0 - 0x1A0)
// Class AdventureOnDemand.SeaFortGameEventOnDemandArrivalTunnelWorker
class USeaFortGameEventOnDemandArrivalTunnelWorker : public UContendedResourceGameEventOnDemandArrivalTunnelWorker
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("SeaFortGameEventOnDemandArrivalTunnelWorker"));
		return Clss;
	}

};

// 0x0 (0x1A0 - 0x1A0)
// Class AdventureOnDemand.SunkenKingdomShrineGameEventOnDemandArrivalTunnelWorker
class USunkenKingdomShrineGameEventOnDemandArrivalTunnelWorker : public UContendedResourceGameEventOnDemandArrivalTunnelWorker
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("SunkenKingdomShrineGameEventOnDemandArrivalTunnelWorker"));
		return Clss;
	}

};

// 0x0 (0x1A0 - 0x1A0)
// Class AdventureOnDemand.SunkenKingdomTreasuryGameEventOnDemandArrivalTunnelWorker
class USunkenKingdomTreasuryGameEventOnDemandArrivalTunnelWorker : public UContendedResourceGameEventOnDemandArrivalTunnelWorker
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("SunkenKingdomTreasuryGameEventOnDemandArrivalTunnelWorker"));
		return Clss;
	}

};

// 0x10 (0x198 - 0x188)
// Class AdventureOnDemand.SkellyFortEventOnDemandArrivalTunnelWorker
class USkellyFortEventOnDemandArrivalTunnelWorker : public UIslandBasedGameEventOnDemandArrivalTunnelWorker
{
public:
	uint8                                        Pad_37D1[0x10];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("SkellyFortEventOnDemandArrivalTunnelWorker"));
		return Clss;
	}

};

}


