#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x28 - 0x28)
// BlueprintGeneratedClass ALK_PincherMonkey.ALK_PincherMonkey_C
class UALK_PincherMonkey_C : public UAnimationDataStoreId
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ALK_PincherMonkey_C"));
		return Clss;
	}

};

}


