#pragma once


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x3 (0x3 - 0x0)
// Function AdventureOnDemandFramework.AdventureOnDemandTaleFunctionLibrary.CompareOnDemandQuestResumeConditionMetReason
struct UAdventureOnDemandTaleFunctionLibrary_CompareOnDemandQuestResumeConditionMetReason_Params
{
public:
	enum class EOnDemandQuestResumeConditionMetReason Left;                                              // 0x0(0x1)
	enum class EOnDemandQuestResumeConditionMetReason Right;                                             // 0x1(0x1)
	bool                                         ReturnValue;                                       // 0x2(0x1)
};

}
}


