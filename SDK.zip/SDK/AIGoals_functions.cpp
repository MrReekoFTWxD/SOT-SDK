#include "pch.h"

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// FUNCTIONS
//---------------------------------------------------------------------------------------------------------------------


// Function AIGoals.WhileBlackboardKeySetAIGoal.GetAllowedBlackboardKeys
// (Final, Native, Private, Const)
// Parameters:
// TArray<class FString>              ReturnValue                                                      

TArray<class FString> UWhileBlackboardKeySetAIGoal::GetAllowedBlackboardKeys()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIGoals.WhileBlackboardKeySetAIGoal.GetAllowedBlackboardKeys"));

	Params::UWhileBlackboardKeySetAIGoal_GetAllowedBlackboardKeys_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}

}


