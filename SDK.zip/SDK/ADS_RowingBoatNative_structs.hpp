#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// ENUMS
//---------------------------------------------------------------------------------------------------------------------


//---------------------------------------------------------------------------------------------------------------------
// STRUCTS
//---------------------------------------------------------------------------------------------------------------------

// 0x98 (0x98 - 0x0)
// AnimDataEntryStruct ADS_RowingBoatNative.ADS_RowingBoatNative
struct FADS_RowingBoatNative
{
public:
	struct FAthenaAnimationRowboatAnimationsFirstPerson RowingBoatFirstPerson_11_1FEBDCAD4D0B1B9EC2D68CA56E8F9158; // 0x0(0x30)
	struct FAthenaAnimationRowboatAnimationsThirdPerson RowingBoatThirdPerson_12_5C16F0F64D75210187251B9DFAA12B1F; // 0x30(0x50)
	struct FAthenaAnimationRowboatAnimationsPassenger RowingBoatPassengers_13_9AC770BB4DB0506105B8B18F3ED44355; // 0x80(0x18)
};

}


