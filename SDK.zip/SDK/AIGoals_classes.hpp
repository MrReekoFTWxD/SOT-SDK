#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x10 (0xD8 - 0xC8)
// Class AIGoals.AIHomeComponent
class UAIHomeComponent : public UActorComponent
{
public:
	uint8                                        Pad_2BEC[0x8];                                     // Fixing Size After Last Property
	class AActor*                                HomeActor;                                         // 0xD0(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIHomeComponent"));
		return Clss;
	}

};

// 0x0 (0x40 - 0x40)
// Class AIGoals.AlwaysEvaluatesTrueAIGoal
class UAlwaysEvaluatesTrueAIGoal : public UAIGoal
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AlwaysEvaluatesTrueAIGoal"));
		return Clss;
	}

};

// 0xA0 (0x110 - 0x70)
// Class AIGoals.BTService_SetBestActionSpotNearTarget
class UBTService_SetBestActionSpotNearTarget : public UBTService
{
public:
	struct FBlackboardKeySelector                TargetKey;                                         // 0x70(0x28)
	struct FBlackboardKeySelector                BestActionSpotKey;                                 // 0x98(0x28)
	struct FBestActionSpotSelectionCriteria      BestActionSpotSelectionCriteria;                   // 0xC0(0x34)
	uint8                                        Pad_2BED[0x1C];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTService_SetBestActionSpotNearTarget"));
		return Clss;
	}

};

// 0x38 (0x78 - 0x40)
// Class AIGoals.WhileActionSpotAvailableForPatrolAIGoal
class UWhileActionSpotAvailableForPatrolAIGoal : public UAIGoal
{
public:
	float                                        MinTimeToChangePatrolSpot;                         // 0x40(0x4)
	float                                        MaxTimeToChangePatrolSpot;                         // 0x44(0x4)
	UInterfaceProperty_                          TargetActionSpotInterface;                         // 0x48(0x10)
	uint8                                        Pad_2BEE[0x20];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("WhileActionSpotAvailableForPatrolAIGoal"));
		return Clss;
	}

};

// 0x8 (0x48 - 0x40)
// Class AIGoals.WhileBlackboardKeySetAIGoal
class UWhileBlackboardKeySetAIGoal : public UAIGoal
{
public:
	class FName                                  BlackboardKey;                                     // 0x40(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("WhileBlackboardKeySetAIGoal"));
		return Clss;
	}

	TArray<class FString> GetAllowedBlackboardKeys();
};

// 0x38 (0x78 - 0x40)
// Class AIGoals.WhileCanBeInteractedWithAndPlayerIsNearbyAIGoal
class UWhileCanBeInteractedWithAndPlayerIsNearbyAIGoal : public UAIGoal
{
public:
	float                                        InnerRadius;                                       // 0x40(0x4)
	float                                        OuterRadius;                                       // 0x44(0x4)
	struct FAIGoalMovementModeFilter             MovementModeFilter;                                // 0x48(0x20)
	bool                                         ShouldOnlyActivateWhileDocked;                     // 0x68(0x1)
	uint8                                        Pad_2BEF[0x7];                                     // Fixing Size After Last Property
	class APawn*                                 TargetPlayerPawn;                                  // 0x70(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("WhileCanBeInteractedWithAndPlayerIsNearbyAIGoal"));
		return Clss;
	}

};

// 0x0 (0x40 - 0x40)
// Class AIGoals.WhileHomeSetAIGoal
class UWhileHomeSetAIGoal : public UAIGoal
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("WhileHomeSetAIGoal"));
		return Clss;
	}

};

// 0xB0 (0xF0 - 0x40)
// Class AIGoals.WhilePlayerWithinAreaAIGoal
class UWhilePlayerWithinAreaAIGoal : public UAIGoal
{
public:
	float                                        EnterAreaTriggerDistance;                          // 0x40(0x4)
	float                                        ExitAreaTriggerDistance;                           // 0x44(0x4)
	struct FAIGoalMovementModeFilter             MovementModeFilter;                                // 0x48(0x20)
	class APawn*                                 TargetPlayerPawn;                                  // 0x68(0x8)
	uint8                                        Pad_2BF0[0x80];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("WhilePlayerWithinAreaAIGoal"));
		return Clss;
	}

};

}


