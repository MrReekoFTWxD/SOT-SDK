#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x28 (0x2D0 - 0x2A8)
// Class ActorSequence.ActorSequence
class UActorSequence : public UMovieSceneSequence
{
public:
	class UMovieScene*                           MovieScene;                                        // 0x2A8(0x8)
	struct FActorSequenceObjectReferenceMap      ObjectReferences;                                  // 0x2B0(0x20)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ActorSequence"));
		return Clss;
	}

};

// 0x40 (0x108 - 0xC8)
// Class ActorSequence.ActorSequenceComponent
class UActorSequenceComponent : public UActorComponent
{
public:
	struct FMovieSceneSequencePlaybackSettings   PlaybackSettings;                                  // 0xC8(0x28)
	class UActorSequence*                        Sequence;                                          // 0xF0(0x8)
	class UActorSequencePlayer*                  SequencePlayer;                                    // 0xF8(0x8)
	bool                                         bAutoPlay;                                         // 0x100(0x1)
	uint8                                        Pad_309F[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ActorSequenceComponent"));
		return Clss;
	}

};

// 0x0 (0x608 - 0x608)
// Class ActorSequence.ActorSequencePlayer
class UActorSequencePlayer : public UMovieSceneSequencePlayer
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ActorSequencePlayer"));
		return Clss;
	}

};

}


