#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x28 - 0x28)
// Class ActorOfInterestFramework.ActorOfInterestBlueprintFunctionLibrary
class UActorOfInterestBlueprintFunctionLibrary : public UObject
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ActorOfInterestBlueprintFunctionLibrary"));
		return Clss;
	}

	void GetActorsOfInterestFromIds(class UObject* WorldContextObject, TArray<TSubclassOf<class UActorOfInterestId>>& ActorOfInterestIds, TArray<class AActor*>* Actors);
	class AActor* GetActorOfInterestFromId(class UObject* WorldContextObject, TSubclassOf<class UActorOfInterestId> ActorOfInterestId);
};

// 0x20 (0xE8 - 0xC8)
// Class ActorOfInterestFramework.ActorOfInterestComponent
class UActorOfInterestComponent : public UActorComponent
{
public:
	TSubclassOf<class UActorOfInterestId>        ActorOfInterestId;                                 // 0xC8(0x8)
	uint8                                        Pad_334B[0x18];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ActorOfInterestComponent"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class ActorOfInterestFramework.ActorOfInterestId
class UActorOfInterestId : public UObject
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ActorOfInterestId"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class ActorOfInterestFramework.ActorOfInterestServiceInterface
class UActorOfInterestServiceInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ActorOfInterestServiceInterface"));
		return Clss;
	}

};

// 0x100 (0x4C8 - 0x3C8)
// Class ActorOfInterestFramework.ActorOfInterestService
class AActorOfInterestService : public AActor
{
public:
	uint8                                        Pad_334C[0x10];                                    // Fixing Size After Last Property
	TMap<class UClass*, struct FActorsOfInterestList> ActorsOfInterest;                                  // 0x3D8(0x50)
	struct FObjectMessagingDispatcher            EventDispatcher;                                   // 0x428(0xA0)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ActorOfInterestService"));
		return Clss;
	}

};

}


