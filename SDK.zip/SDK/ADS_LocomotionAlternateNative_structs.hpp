#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// ENUMS
//---------------------------------------------------------------------------------------------------------------------


//---------------------------------------------------------------------------------------------------------------------
// STRUCTS
//---------------------------------------------------------------------------------------------------------------------

// 0x140 (0x140 - 0x0)
// AnimDataEntryStruct ADS_LocomotionAlternateNative.ADS_LocomotionAlternateNative
struct FADS_LocomotionAlternateNative
{
public:
	struct FAthenaAnimationLocomotionAlternateAnimData Drunk_48_A586B449410EBBDE851BBD991F7C6A63;         // 0x0(0x50)
	struct FAthenaAnimationLocomotionAlternateAnimData Limp_49_5DAB2AC340B980B8EF92528FE62C5895;          // 0x50(0x50)
	struct FAthenaAnimationLocomotionAlternateAnimData PegLeg_50_D8C2B28B4975F5BD98B483A8911DF23B;        // 0xA0(0x50)
	struct FAthenaAnimationLocomotionAlternateAnimData HotCoals_53_63626D244758D873648CF0ADFBDF3480;      // 0xF0(0x50)
};

}


