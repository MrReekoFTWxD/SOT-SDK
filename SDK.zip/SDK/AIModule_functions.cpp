#include "pch.h"

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// FUNCTIONS
//---------------------------------------------------------------------------------------------------------------------


// Function AIModule.AIController.UseBlackboard
// (Final, Native, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class UBlackboardData*             BlackboardAsset                                                  
// class UBlackboardComponent*        BlackboardComponent                                              
// bool                               ReturnValue                                                      

bool AAIController::UseBlackboard(class UBlackboardData* BlackboardAsset, class UBlackboardComponent** BlackboardComponent)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.UseBlackboard"));

	Params::AAIController_UseBlackboard_Params Parms;
	Parms.BlackboardAsset = BlackboardAsset;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	if (BlackboardComponent != nullptr)
		*BlackboardComponent = Parms.BlackboardComponent;

	return Parms.ReturnValue;

}


// Function AIModule.AIController.SetMoveBlockDetection
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                               bEnable                                                          

void AAIController::SetMoveBlockDetection(bool bEnable)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.SetMoveBlockDetection"));

	Params::AAIController_SetMoveBlockDetection_Params Parms;
	Parms.bEnable = bEnable;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AIController.RunBehaviorTree
// (Native, Public, BlueprintCallable)
// Parameters:
// class UBehaviorTree*               BTAsset                                                          
// bool                               ReturnValue                                                      

bool AAIController::RunBehaviorTree(class UBehaviorTree* BTAsset)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.RunBehaviorTree"));

	Params::AAIController_RunBehaviorTree_Params Parms;
	Parms.BTAsset = BTAsset;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIController.OnUsingBlackBoard
// (Event, Protected, BlueprintEvent)
// Parameters:
// class UBlackboardComponent*        BlackboardComp                                                   
// class UBlackboardData*             BlackboardAsset                                                  

void AAIController::OnUsingBlackBoard(class UBlackboardComponent* BlackboardComp, class UBlackboardData* BlackboardAsset)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.OnUsingBlackBoard"));

	Params::AAIController_OnUsingBlackBoard_Params Parms;
	Parms.BlackboardComp = BlackboardComp;
	Parms.BlackboardAsset = BlackboardAsset;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.AIController.OnPossess
// (Event, Public, BlueprintEvent)
// Parameters:
// class APawn*                       PossessedPawn                                                    

void AAIController::OnPossess(class APawn* PossessedPawn)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.OnPossess"));

	Params::AAIController_OnPossess_Params Parms;
	Parms.PossessedPawn = PossessedPawn;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.AIController.OnGameplayTaskResourcesClaimed
// (Native, Public)
// Parameters:
// struct FGameplayResourceSet        NewlyClaimed                                                     
// struct FGameplayResourceSet        FreshlyReleased                                                  

void AAIController::OnGameplayTaskResourcesClaimed(const struct FGameplayResourceSet& NewlyClaimed, const struct FGameplayResourceSet& FreshlyReleased)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.OnGameplayTaskResourcesClaimed"));

	Params::AAIController_OnGameplayTaskResourcesClaimed_Params Parms;
	Parms.NewlyClaimed = NewlyClaimed;
	Parms.FreshlyReleased = FreshlyReleased;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AIController.MoveToLocation
// (Final, Native, Public, HasOutParams, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector                     Dest                                                             
// float                              AcceptanceRadius                                                 
// bool                               bStopOnOverlap                                                   
// bool                               bUsePathfinding                                                  
// bool                               bProjectDestinationToNavigation                                  
// bool                               bCanStrafe                                                       
// TSubclassOf<class UNavigationQueryFilter>FilterClass                                                      
// bool                               bAllowPartialPath                                                
// enum class EPathFollowingRequestResultReturnValue                                                      

enum class EPathFollowingRequestResult AAIController::MoveToLocation(struct FVector& Dest, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bProjectDestinationToNavigation, bool bCanStrafe, TSubclassOf<class UNavigationQueryFilter> FilterClass, bool bAllowPartialPath)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.MoveToLocation"));

	Params::AAIController_MoveToLocation_Params Parms;
	Parms.Dest = Dest;
	Parms.AcceptanceRadius = AcceptanceRadius;
	Parms.bStopOnOverlap = bStopOnOverlap;
	Parms.bUsePathfinding = bUsePathfinding;
	Parms.bProjectDestinationToNavigation = bProjectDestinationToNavigation;
	Parms.bCanStrafe = bCanStrafe;
	Parms.FilterClass = FilterClass;
	Parms.bAllowPartialPath = bAllowPartialPath;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIController.MoveToActor
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class AActor*                      Goal                                                             
// float                              AcceptanceRadius                                                 
// bool                               bStopOnOverlap                                                   
// bool                               bUsePathfinding                                                  
// bool                               bCanStrafe                                                       
// TSubclassOf<class UNavigationQueryFilter>FilterClass                                                      
// bool                               bAllowPartialPath                                                
// enum class EPathFollowingRequestResultReturnValue                                                      

enum class EPathFollowingRequestResult AAIController::MoveToActor(class AActor* Goal, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bCanStrafe, TSubclassOf<class UNavigationQueryFilter> FilterClass, bool bAllowPartialPath)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.MoveToActor"));

	Params::AAIController_MoveToActor_Params Parms;
	Parms.Goal = Goal;
	Parms.AcceptanceRadius = AcceptanceRadius;
	Parms.bStopOnOverlap = bStopOnOverlap;
	Parms.bUsePathfinding = bUsePathfinding;
	Parms.bCanStrafe = bCanStrafe;
	Parms.FilterClass = FilterClass;
	Parms.bAllowPartialPath = bAllowPartialPath;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIController.K2_SetFocus
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class AActor*                      NewFocus                                                         

void AAIController::K2_SetFocus(class AActor* NewFocus)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.K2_SetFocus"));

	Params::AAIController_K2_SetFocus_Params Parms;
	Parms.NewFocus = NewFocus;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AIController.K2_SetFocalPoint
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector                     FP                                                               

void AAIController::K2_SetFocalPoint(const struct FVector& FP)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.K2_SetFocalPoint"));

	Params::AAIController_K2_SetFocalPoint_Params Parms;
	Parms.FP = FP;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AIController.K2_ClearFocus
// (Final, Native, Public, BlueprintCallable)
// Parameters:

void AAIController::K2_ClearFocus()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.K2_ClearFocus"));

	Params::AAIController_K2_ClearFocus_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AIController.HasPartialPath
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                               ReturnValue                                                      

bool AAIController::HasPartialPath()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.HasPartialPath"));

	Params::AAIController_HasPartialPath_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIController.GetPathFollowingComponent
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class UPathFollowingComponent*     ReturnValue                                                      

class UPathFollowingComponent* AAIController::GetPathFollowingComponent()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.GetPathFollowingComponent"));

	Params::AAIController_GetPathFollowingComponent_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIController.GetMoveStatus
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// enum class EPathFollowingStatus    ReturnValue                                                      

enum class EPathFollowingStatus AAIController::GetMoveStatus()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.GetMoveStatus"));

	Params::AAIController_GetMoveStatus_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIController.GetImmediateMoveDestination
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector                     ReturnValue                                                      

struct FVector AAIController::GetImmediateMoveDestination()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.GetImmediateMoveDestination"));

	Params::AAIController_GetImmediateMoveDestination_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIController.GetFocusActor
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class AActor*                      ReturnValue                                                      

class AActor* AAIController::GetFocusActor()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.GetFocusActor"));

	Params::AAIController_GetFocusActor_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIController.GetFocalPointOnActor
// (Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class AActor*                      Actor                                                            
// struct FVector                     ReturnValue                                                      

struct FVector AAIController::GetFocalPointOnActor(class AActor* Actor)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.GetFocalPointOnActor"));

	Params::AAIController_GetFocalPointOnActor_Params Parms;
	Parms.Actor = Actor;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIController.GetFocalPoint
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector                     ReturnValue                                                      

struct FVector AAIController::GetFocalPoint()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.GetFocalPoint"));

	Params::AAIController_GetFocalPoint_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIController.GetAIPerceptionComponent
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class UAIPerceptionComponent*      ReturnValue                                                      

class UAIPerceptionComponent* AAIController::GetAIPerceptionComponent()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIController.GetAIPerceptionComponent"));

	Params::AAIController_GetAIPerceptionComponent_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.PathFollowingComponent.OnActorBump
// (Native, Public, HasOutParams, HasDefaults)
// Parameters:
// class AActor*                      SelfActor                                                        
// class AActor*                      OtherActor                                                       
// struct FVector                     NormalImpulse                                                    
// struct FHitResult                  Hit                                                              

void UPathFollowingComponent::OnActorBump(class AActor* SelfActor, class AActor* OtherActor, const struct FVector& NormalImpulse, struct FHitResult& Hit)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PathFollowingComponent.OnActorBump"));

	Params::UPathFollowingComponent_OnActorBump_Params Parms;
	Parms.SelfActor = SelfActor;
	Parms.OtherActor = OtherActor;
	Parms.NormalImpulse = NormalImpulse;
	Parms.Hit = Hit;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.PathFollowingComponent.GetPathDestination
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector                     ReturnValue                                                      

struct FVector UPathFollowingComponent::GetPathDestination()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PathFollowingComponent.GetPathDestination"));

	Params::UPathFollowingComponent_GetPathDestination_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.PathFollowingComponent.GetPathActionType
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// enum class EPathFollowingAction    ReturnValue                                                      

enum class EPathFollowingAction UPathFollowingComponent::GetPathActionType()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PathFollowingComponent.GetPathActionType"));

	Params::UPathFollowingComponent_GetPathActionType_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIAsyncTaskBlueprintProxy.OnMoveCompleted
// (Final, Native, Public)
// Parameters:
// struct FAIRequestID                RequestID                                                        
// enum class EPathFollowingResult    MovementResult                                                   

void UAIAsyncTaskBlueprintProxy::OnMoveCompleted(const struct FAIRequestID& RequestID, enum class EPathFollowingResult MovementResult)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIAsyncTaskBlueprintProxy.OnMoveCompleted"));

	Params::UAIAsyncTaskBlueprintProxy_OnMoveCompleted_Params Parms;
	Parms.RequestID = RequestID;
	Parms.MovementResult = MovementResult;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AIBlueprintHelperLibrary.UnlockAIResourcesWithAnimation
// (Final, BlueprintAuthorityOnly, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UAnimInstance*               AnimInstance                                                     
// bool                               bUnlockMovement                                                  
// bool                               UnlockAILogic                                                    

void UAIBlueprintHelperLibrary::UnlockAIResourcesWithAnimation(class UAnimInstance* AnimInstance, bool bUnlockMovement, bool UnlockAILogic)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIBlueprintHelperLibrary.UnlockAIResourcesWithAnimation"));

	Params::UAIBlueprintHelperLibrary_UnlockAIResourcesWithAnimation_Params Parms;
	Parms.AnimInstance = AnimInstance;
	Parms.bUnlockMovement = bUnlockMovement;
	Parms.UnlockAILogic = UnlockAILogic;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AIBlueprintHelperLibrary.SpawnAIFromClass
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class UObject*                     WorldContextObject                                               
// TSubclassOf<class APawn>           PawnClass                                                        
// class UBehaviorTree*               BehaviorTree                                                     
// struct FVector                     Location                                                         
// struct FRotator                    Rotation                                                         
// bool                               bNoCollisionFail                                                 
// class APawn*                       ReturnValue                                                      

class APawn* UAIBlueprintHelperLibrary::SpawnAIFromClass(class UObject* WorldContextObject, TSubclassOf<class APawn> PawnClass, class UBehaviorTree* BehaviorTree, const struct FVector& Location, const struct FRotator& Rotation, bool bNoCollisionFail)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIBlueprintHelperLibrary.SpawnAIFromClass"));

	Params::UAIBlueprintHelperLibrary_SpawnAIFromClass_Params Parms;
	Parms.WorldContextObject = WorldContextObject;
	Parms.PawnClass = PawnClass;
	Parms.BehaviorTree = BehaviorTree;
	Parms.Location = Location;
	Parms.Rotation = Rotation;
	Parms.bNoCollisionFail = bNoCollisionFail;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIBlueprintHelperLibrary.SendAIMessage
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class APawn*                       Target                                                           
// class FName                        Message                                                          
// class UObject*                     MessageSource                                                    
// bool                               bSuccess                                                         

void UAIBlueprintHelperLibrary::SendAIMessage(class APawn* Target, class FName Message, class UObject* MessageSource, bool bSuccess)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIBlueprintHelperLibrary.SendAIMessage"));

	Params::UAIBlueprintHelperLibrary_SendAIMessage_Params Parms;
	Parms.Target = Target;
	Parms.Message = Message;
	Parms.MessageSource = MessageSource;
	Parms.bSuccess = bSuccess;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AIBlueprintHelperLibrary.LockAIResourcesWithAnimation
// (Final, BlueprintAuthorityOnly, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UAnimInstance*               AnimInstance                                                     
// bool                               bLockMovement                                                    
// bool                               LockAILogic                                                      

void UAIBlueprintHelperLibrary::LockAIResourcesWithAnimation(class UAnimInstance* AnimInstance, bool bLockMovement, bool LockAILogic)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIBlueprintHelperLibrary.LockAIResourcesWithAnimation"));

	Params::UAIBlueprintHelperLibrary_LockAIResourcesWithAnimation_Params Parms;
	Parms.AnimInstance = AnimInstance;
	Parms.bLockMovement = bLockMovement;
	Parms.LockAILogic = LockAILogic;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AIBlueprintHelperLibrary.IsValidAIRotation
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FRotator                    Rotation                                                         
// bool                               ReturnValue                                                      

bool UAIBlueprintHelperLibrary::IsValidAIRotation(const struct FRotator& Rotation)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIBlueprintHelperLibrary.IsValidAIRotation"));

	Params::UAIBlueprintHelperLibrary_IsValidAIRotation_Params Parms;
	Parms.Rotation = Rotation;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIBlueprintHelperLibrary.IsValidAILocation
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FVector                     Location                                                         
// bool                               ReturnValue                                                      

bool UAIBlueprintHelperLibrary::IsValidAILocation(const struct FVector& Location)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIBlueprintHelperLibrary.IsValidAILocation"));

	Params::UAIBlueprintHelperLibrary_IsValidAILocation_Params Parms;
	Parms.Location = Location;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIBlueprintHelperLibrary.IsValidAIDirection
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FVector                     DirectionVector                                                  
// bool                               ReturnValue                                                      

bool UAIBlueprintHelperLibrary::IsValidAIDirection(const struct FVector& DirectionVector)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIBlueprintHelperLibrary.IsValidAIDirection"));

	Params::UAIBlueprintHelperLibrary_IsValidAIDirection_Params Parms;
	Parms.DirectionVector = DirectionVector;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIBlueprintHelperLibrary.GetBlackboard
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class AActor*                      Target                                                           
// class UBlackboardComponent*        ReturnValue                                                      

class UBlackboardComponent* UAIBlueprintHelperLibrary::GetBlackboard(class AActor* Target)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIBlueprintHelperLibrary.GetBlackboard"));

	Params::UAIBlueprintHelperLibrary_GetBlackboard_Params Parms;
	Parms.Target = Target;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIBlueprintHelperLibrary.GetAIController
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class AActor*                      ControlledActor                                                  
// class AAIController*               ReturnValue                                                      

class AAIController* UAIBlueprintHelperLibrary::GetAIController(class AActor* ControlledActor)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIBlueprintHelperLibrary.GetAIController"));

	Params::UAIBlueprintHelperLibrary_GetAIController_Params Parms;
	Parms.ControlledActor = ControlledActor;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIBlueprintHelperLibrary.CreateMoveToProxyObject
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class UObject*                     WorldContextObject                                               
// class APawn*                       Pawn                                                             
// struct FVector                     Destination                                                      
// class AActor*                      TargetActor                                                      
// float                              AcceptanceRadius                                                 
// bool                               bStopOnOverlap                                                   
// class UAIAsyncTaskBlueprintProxy*  ReturnValue                                                      

class UAIAsyncTaskBlueprintProxy* UAIBlueprintHelperLibrary::CreateMoveToProxyObject(class UObject* WorldContextObject, class APawn* Pawn, const struct FVector& Destination, class AActor* TargetActor, float AcceptanceRadius, bool bStopOnOverlap)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIBlueprintHelperLibrary.CreateMoveToProxyObject"));

	Params::UAIBlueprintHelperLibrary_CreateMoveToProxyObject_Params Parms;
	Parms.WorldContextObject = WorldContextObject;
	Parms.Pawn = Pawn;
	Parms.Destination = Destination;
	Parms.TargetActor = TargetActor;
	Parms.AcceptanceRadius = AcceptanceRadius;
	Parms.bStopOnOverlap = bStopOnOverlap;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.PawnActionsComponent.K2_PushAction
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class UPawnAction*                 NewAction                                                        
// enum class EAIRequestPriority      Priority                                                         
// class UObject*                     Instigator                                                       
// bool                               ReturnValue                                                      

bool UPawnActionsComponent::K2_PushAction(class UPawnAction* NewAction, enum class EAIRequestPriority Priority, class UObject* Instigator)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PawnActionsComponent.K2_PushAction"));

	Params::UPawnActionsComponent_K2_PushAction_Params Parms;
	Parms.NewAction = NewAction;
	Parms.Priority = Priority;
	Parms.Instigator = Instigator;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.PawnActionsComponent.K2_PerformAction
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class APawn*                       Pawn                                                             
// class UPawnAction*                 Action                                                           
// enum class EAIRequestPriority      Priority                                                         
// bool                               ReturnValue                                                      

bool UPawnActionsComponent::K2_PerformAction(class APawn* Pawn, class UPawnAction* Action, enum class EAIRequestPriority Priority)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PawnActionsComponent.K2_PerformAction"));

	Params::UPawnActionsComponent_K2_PerformAction_Params Parms;
	Parms.Pawn = Pawn;
	Parms.Action = Action;
	Parms.Priority = Priority;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.PawnActionsComponent.K2_ForceAbortAction
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class UPawnAction*                 ActionToAbort                                                    
// enum class EPawnActionAbortState   ReturnValue                                                      

enum class EPawnActionAbortState UPawnActionsComponent::K2_ForceAbortAction(class UPawnAction* ActionToAbort)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PawnActionsComponent.K2_ForceAbortAction"));

	Params::UPawnActionsComponent_K2_ForceAbortAction_Params Parms;
	Parms.ActionToAbort = ActionToAbort;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.PawnActionsComponent.K2_AbortAction
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class UPawnAction*                 ActionToAbort                                                    
// enum class EPawnActionAbortState   ReturnValue                                                      

enum class EPawnActionAbortState UPawnActionsComponent::K2_AbortAction(class UPawnAction* ActionToAbort)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PawnActionsComponent.K2_AbortAction"));

	Params::UPawnActionsComponent_K2_AbortAction_Params Parms;
	Parms.ActionToAbort = ActionToAbort;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AISystem.AILoggingVerbose
// (Exec, Native, Public)
// Parameters:

void UAISystem::AILoggingVerbose()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AISystem.AILoggingVerbose"));

	Params::UAISystem_AILoggingVerbose_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AISystem.AIIgnorePlayers
// (Exec, Native, Public)
// Parameters:

void UAISystem::AIIgnorePlayers()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AISystem.AIIgnorePlayers"));

	Params::UAISystem_AIIgnorePlayers_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AIPerceptionSystem.ReportPerceptionEvent
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UObject*                     WorldContext                                                     
// class UAISenseEvent*               PerceptionEvent                                                  

void UAIPerceptionSystem::ReportPerceptionEvent(class UObject* WorldContext, class UAISenseEvent* PerceptionEvent)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIPerceptionSystem.ReportPerceptionEvent"));

	Params::UAIPerceptionSystem_ReportPerceptionEvent_Params Parms;
	Parms.WorldContext = WorldContext;
	Parms.PerceptionEvent = PerceptionEvent;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AIPerceptionSystem.ReportEvent
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class UAISenseEvent*               PerceptionEvent                                                  

void UAIPerceptionSystem::ReportEvent(class UAISenseEvent* PerceptionEvent)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIPerceptionSystem.ReportEvent"));

	Params::UAIPerceptionSystem_ReportEvent_Params Parms;
	Parms.PerceptionEvent = PerceptionEvent;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AIPerceptionSystem.RegisterPerceptionStimuliSource
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UObject*                     WorldContext                                                     
// TSubclassOf<class UAISense>        Sense                                                            
// class AActor*                      Target                                                           
// bool                               ReturnValue                                                      

bool UAIPerceptionSystem::RegisterPerceptionStimuliSource(class UObject* WorldContext, TSubclassOf<class UAISense> Sense, class AActor* Target)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIPerceptionSystem.RegisterPerceptionStimuliSource"));

	Params::UAIPerceptionSystem_RegisterPerceptionStimuliSource_Params Parms;
	Parms.WorldContext = WorldContext;
	Parms.Sense = Sense;
	Parms.Target = Target;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIPerceptionSystem.OnPerceptionStimuliSourceEndPlay
// (Final, Native, Protected)
// Parameters:
// enum class EEndPlayReason          EndPlayReason                                                    

void UAIPerceptionSystem::OnPerceptionStimuliSourceEndPlay(enum class EEndPlayReason EndPlayReason)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIPerceptionSystem.OnPerceptionStimuliSourceEndPlay"));

	Params::UAIPerceptionSystem_OnPerceptionStimuliSourceEndPlay_Params Parms;
	Parms.EndPlayReason = EndPlayReason;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AIPerceptionSystem.GetSenseClassForStimulus
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class UObject*                     WorldContext                                                     
// struct FAIStimulus                 Stimulus                                                         
// TSubclassOf<class UAISense>        ReturnValue                                                      

TSubclassOf<class UAISense> UAIPerceptionSystem::GetSenseClassForStimulus(class UObject* WorldContext, struct FAIStimulus& Stimulus)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIPerceptionSystem.GetSenseClassForStimulus"));

	Params::UAIPerceptionSystem_GetSenseClassForStimulus_Params Parms;
	Parms.WorldContext = WorldContext;
	Parms.Stimulus = Stimulus;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIPerceptionComponent.RequestStimuliListenerUpdate
// (Final, Native, Public, BlueprintCallable)
// Parameters:

void UAIPerceptionComponent::RequestStimuliListenerUpdate()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIPerceptionComponent.RequestStimuliListenerUpdate"));

	Params::UAIPerceptionComponent_RequestStimuliListenerUpdate_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AIPerceptionComponent.OnOwnerEndPlay
// (Final, Native, Public)
// Parameters:
// enum class EEndPlayReason          EndPlayReason                                                    

void UAIPerceptionComponent::OnOwnerEndPlay(enum class EEndPlayReason EndPlayReason)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIPerceptionComponent.OnOwnerEndPlay"));

	Params::UAIPerceptionComponent_OnOwnerEndPlay_Params Parms;
	Parms.EndPlayReason = EndPlayReason;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AIPerceptionComponent.IsIgnored
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class AActor*                      Actor                                                            
// bool                               ReturnValue                                                      

bool UAIPerceptionComponent::IsIgnored(class AActor* Actor)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIPerceptionComponent.IsIgnored"));

	Params::UAIPerceptionComponent_IsIgnored_Params Parms;
	Parms.Actor = Actor;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.AIPerceptionComponent.GetPerceivedHostileActors
// (Final, Native, Public, HasOutParams, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<class AActor*>              OutActors                                                        

void UAIPerceptionComponent::GetPerceivedHostileActors(TArray<class AActor*>* OutActors)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIPerceptionComponent.GetPerceivedHostileActors"));

	Params::UAIPerceptionComponent_GetPerceivedHostileActors_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	if (OutActors != nullptr)
		*OutActors = Parms.OutActors;

}


// Function AIModule.AIPerceptionComponent.GetPerceivedActors
// (Final, Native, Public, HasOutParams, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TSubclassOf<class UAISense>        SenseToUse                                                       
// TArray<class AActor*>              OutActors                                                        

void UAIPerceptionComponent::GetPerceivedActors(TSubclassOf<class UAISense> SenseToUse, TArray<class AActor*>* OutActors)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIPerceptionComponent.GetPerceivedActors"));

	Params::UAIPerceptionComponent_GetPerceivedActors_Params Parms;
	Parms.SenseToUse = SenseToUse;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	if (OutActors != nullptr)
		*OutActors = Parms.OutActors;

}


// Function AIModule.AIPerceptionComponent.GetActorsPerception
// (Final, Native, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class AActor*                      Actor                                                            
// struct FActorPerceptionBlueprintInfoInfo                                                             
// bool                               ReturnValue                                                      

bool UAIPerceptionComponent::GetActorsPerception(class AActor* Actor, struct FActorPerceptionBlueprintInfo* Info)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIPerceptionComponent.GetActorsPerception"));

	Params::UAIPerceptionComponent_GetActorsPerception_Params Parms;
	Parms.Actor = Actor;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	if (Info != nullptr)
		*Info = Parms.Info;

	return Parms.ReturnValue;

}


// Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromSense
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TSubclassOf<class UAISense>        SenseClass                                                       

void UAIPerceptionStimuliSourceComponent::UnregisterFromSense(TSubclassOf<class UAISense> SenseClass)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromSense"));

	Params::UAIPerceptionStimuliSourceComponent_UnregisterFromSense_Params Parms;
	Parms.SenseClass = SenseClass;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromPerceptionSystem
// (Final, Native, Public, BlueprintCallable)
// Parameters:

void UAIPerceptionStimuliSourceComponent::UnregisterFromPerceptionSystem()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromPerceptionSystem"));

	Params::UAIPerceptionStimuliSourceComponent_UnregisterFromPerceptionSystem_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AIPerceptionStimuliSourceComponent.RegisterWithPerceptionSystem
// (Final, Native, Public, BlueprintCallable)
// Parameters:

void UAIPerceptionStimuliSourceComponent::RegisterWithPerceptionSystem()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIPerceptionStimuliSourceComponent.RegisterWithPerceptionSystem"));

	Params::UAIPerceptionStimuliSourceComponent_RegisterWithPerceptionSystem_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AIPerceptionStimuliSourceComponent.RegisterForSense
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TSubclassOf<class UAISense>        SenseClass                                                       

void UAIPerceptionStimuliSourceComponent::RegisterForSense(TSubclassOf<class UAISense> SenseClass)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AIPerceptionStimuliSourceComponent.RegisterForSense"));

	Params::UAIPerceptionStimuliSourceComponent_RegisterForSense_Params Parms;
	Parms.SenseClass = SenseClass;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AISense_Blueprint.OnUpdate
// (Event, Public, HasOutParams, BlueprintEvent)
// Parameters:
// TArray<class UAISenseEvent*>       EventsToProcess                                                  
// float                              ReturnValue                                                      

float UAISense_Blueprint::OnUpdate(TArray<class UAISenseEvent*>& EventsToProcess)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AISense_Blueprint.OnUpdate"));

	Params::UAISense_Blueprint_OnUpdate_Params Parms;
	Parms.EventsToProcess = EventsToProcess;

	UObject::ProcessEvent(Func, &Parms);

	return Parms.ReturnValue;

}


// Function AIModule.AISense_Blueprint.OnListenerUpdated
// (Event, Public, BlueprintEvent)
// Parameters:
// class AActor*                      ActorListener                                                    
// class UAIPerceptionComponent*      PerceptionComponent                                              

void UAISense_Blueprint::OnListenerUpdated(class AActor* ActorListener, class UAIPerceptionComponent* PerceptionComponent)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AISense_Blueprint.OnListenerUpdated"));

	Params::UAISense_Blueprint_OnListenerUpdated_Params Parms;
	Parms.ActorListener = ActorListener;
	Parms.PerceptionComponent = PerceptionComponent;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.AISense_Blueprint.OnListenerUnregistered
// (Event, Public, BlueprintEvent)
// Parameters:
// class AActor*                      ActorListener                                                    
// class UAIPerceptionComponent*      PerceptionComponent                                              

void UAISense_Blueprint::OnListenerUnregistered(class AActor* ActorListener, class UAIPerceptionComponent* PerceptionComponent)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AISense_Blueprint.OnListenerUnregistered"));

	Params::UAISense_Blueprint_OnListenerUnregistered_Params Parms;
	Parms.ActorListener = ActorListener;
	Parms.PerceptionComponent = PerceptionComponent;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.AISense_Blueprint.OnListenerRegistered
// (Event, Public, BlueprintEvent)
// Parameters:
// class AActor*                      ActorListener                                                    
// class UAIPerceptionComponent*      PerceptionComponent                                              

void UAISense_Blueprint::OnListenerRegistered(class AActor* ActorListener, class UAIPerceptionComponent* PerceptionComponent)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AISense_Blueprint.OnListenerRegistered"));

	Params::UAISense_Blueprint_OnListenerRegistered_Params Parms;
	Parms.ActorListener = ActorListener;
	Parms.PerceptionComponent = PerceptionComponent;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.AISense_Blueprint.K2_OnNewPawn
// (Event, Public, BlueprintEvent)
// Parameters:
// class APawn*                       NewPawn                                                          

void UAISense_Blueprint::K2_OnNewPawn(class APawn* NewPawn)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AISense_Blueprint.K2_OnNewPawn"));

	Params::UAISense_Blueprint_K2_OnNewPawn_Params Parms;
	Parms.NewPawn = NewPawn;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.AISense_Blueprint.GetAllListenerComponents
// (Final, Native, Public, HasOutParams, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<class UAIPerceptionComponent*>ListenerComponents                                               

void UAISense_Blueprint::GetAllListenerComponents(TArray<class UAIPerceptionComponent*>* ListenerComponents)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AISense_Blueprint.GetAllListenerComponents"));

	Params::UAISense_Blueprint_GetAllListenerComponents_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	if (ListenerComponents != nullptr)
		*ListenerComponents = Parms.ListenerComponents;

}


// Function AIModule.AISense_Blueprint.GetAllListenerActors
// (Final, Native, Public, HasOutParams, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<class AActor*>              ListenerActors                                                   

void UAISense_Blueprint::GetAllListenerActors(TArray<class AActor*>* ListenerActors)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AISense_Blueprint.GetAllListenerActors"));

	Params::UAISense_Blueprint_GetAllListenerActors_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	if (ListenerActors != nullptr)
		*ListenerActors = Parms.ListenerActors;

}


// Function AIModule.AISense_Damage.ReportDamageEvent
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class UObject*                     WorldContext                                                     
// class AActor*                      DamagedActor                                                     
// class AActor*                      Instigator                                                       
// float                              DamageAmount                                                     
// struct FVector                     EventLocation                                                    
// struct FVector                     HitLocation                                                      

void UAISense_Damage::ReportDamageEvent(class UObject* WorldContext, class AActor* DamagedActor, class AActor* Instigator, float DamageAmount, const struct FVector& EventLocation, const struct FVector& HitLocation)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AISense_Damage.ReportDamageEvent"));

	Params::UAISense_Damage_ReportDamageEvent_Params Parms;
	Parms.WorldContext = WorldContext;
	Parms.DamagedActor = DamagedActor;
	Parms.Instigator = Instigator;
	Parms.DamageAmount = DamageAmount;
	Parms.EventLocation = EventLocation;
	Parms.HitLocation = HitLocation;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AISense_Hearing.ReportNoiseEvent
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class UObject*                     WorldContext                                                     
// struct FVector                     NoiseLocation                                                    
// float                              Loudness                                                         
// class AActor*                      Instigator                                                       
// float                              MaxRange                                                         
// class FName                        Tag                                                              

void UAISense_Hearing::ReportNoiseEvent(class UObject* WorldContext, const struct FVector& NoiseLocation, float Loudness, class AActor* Instigator, float MaxRange, class FName Tag)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AISense_Hearing.ReportNoiseEvent"));

	Params::UAISense_Hearing_ReportNoiseEvent_Params Parms;
	Parms.WorldContext = WorldContext;
	Parms.NoiseLocation = NoiseLocation;
	Parms.Loudness = Loudness;
	Parms.Instigator = Instigator;
	Parms.MaxRange = MaxRange;
	Parms.Tag = Tag;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AISense_Prediction.RequestPawnPredictionEvent
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class APawn*                       Requestor                                                        
// class AActor*                      PredictedActor                                                   
// float                              PredictionTime                                                   

void UAISense_Prediction::RequestPawnPredictionEvent(class APawn* Requestor, class AActor* PredictedActor, float PredictionTime)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AISense_Prediction.RequestPawnPredictionEvent"));

	Params::UAISense_Prediction_RequestPawnPredictionEvent_Params Parms;
	Parms.Requestor = Requestor;
	Parms.PredictedActor = PredictedActor;
	Parms.PredictionTime = PredictionTime;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AISense_Prediction.RequestControllerPredictionEvent
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class AAIController*               Requestor                                                        
// class AActor*                      PredictedActor                                                   
// float                              PredictionTime                                                   

void UAISense_Prediction::RequestControllerPredictionEvent(class AAIController* Requestor, class AActor* PredictedActor, float PredictionTime)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AISense_Prediction.RequestControllerPredictionEvent"));

	Params::UAISense_Prediction_RequestControllerPredictionEvent_Params Parms;
	Parms.Requestor = Requestor;
	Parms.PredictedActor = PredictedActor;
	Parms.PredictionTime = PredictionTime;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.AITask_MoveTo.AIMoveTo
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class AAIController*               Controller                                                       
// struct FVector                     GoalLocation                                                     
// class AActor*                      GoalActor                                                        
// float                              AcceptanceRadius                                                 
// enum class EAIOptionFlag           StopOnOverlap                                                    
// enum class EAIOptionFlag           AcceptPartialPath                                                
// bool                               bUsePathfinding                                                  
// bool                               bLockAILogic                                                     
// class UAITask_MoveTo*              ReturnValue                                                      

class UAITask_MoveTo* UAITask_MoveTo::AIMoveTo(class AAIController* Controller, const struct FVector& GoalLocation, class AActor* GoalActor, float AcceptanceRadius, enum class EAIOptionFlag StopOnOverlap, enum class EAIOptionFlag AcceptPartialPath, bool bUsePathfinding, bool bLockAILogic)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.AITask_MoveTo.AIMoveTo"));

	Params::UAITask_MoveTo_AIMoveTo_Params Parms;
	Parms.Controller = Controller;
	Parms.GoalLocation = GoalLocation;
	Parms.GoalActor = GoalActor;
	Parms.AcceptanceRadius = AcceptanceRadius;
	Parms.StopOnOverlap = StopOnOverlap;
	Parms.AcceptPartialPath = AcceptPartialPath;
	Parms.bUsePathfinding = bUsePathfinding;
	Parms.bLockAILogic = bLockAILogic;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BrainComponent.StopLogic
// (Native, Public, BlueprintCallable)
// Parameters:
// class FString                      Reason                                                           

void UBrainComponent::StopLogic(const class FString& Reason)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BrainComponent.StopLogic"));

	Params::UBrainComponent_StopLogic_Params Parms;
	Parms.Reason = Reason;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BrainComponent.RestartLogic
// (Native, Public, BlueprintCallable)
// Parameters:

void UBrainComponent::RestartLogic()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BrainComponent.RestartLogic"));

	Params::UBrainComponent_RestartLogic_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BehaviorTreeComponent.SetDynamicSubtree
// (Native, Public, BlueprintCallable)
// Parameters:
// struct FGameplayTag                InjectTag                                                        
// class UBehaviorTree*               BehaviorAsset                                                    

void UBehaviorTreeComponent::SetDynamicSubtree(const struct FGameplayTag& InjectTag, class UBehaviorTree* BehaviorAsset)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BehaviorTreeComponent.SetDynamicSubtree"));

	Params::UBehaviorTreeComponent_SetDynamicSubtree_Params Parms;
	Parms.InjectTag = InjectTag;
	Parms.BehaviorAsset = BehaviorAsset;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BehaviorTreeComponent.GetTagCooldownEndTime
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FGameplayTag                CooldownTag                                                      
// float                              ReturnValue                                                      

float UBehaviorTreeComponent::GetTagCooldownEndTime(const struct FGameplayTag& CooldownTag)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BehaviorTreeComponent.GetTagCooldownEndTime"));

	Params::UBehaviorTreeComponent_GetTagCooldownEndTime_Params Parms;
	Parms.CooldownTag = CooldownTag;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BehaviorTreeComponent.AddCooldownTagDuration
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FGameplayTag                CooldownTag                                                      
// float                              CoolDownDuration                                                 
// bool                               bAddToExistingDuration                                           

void UBehaviorTreeComponent::AddCooldownTagDuration(const struct FGameplayTag& CooldownTag, float CoolDownDuration, bool bAddToExistingDuration)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BehaviorTreeComponent.AddCooldownTagDuration"));

	Params::UBehaviorTreeComponent_AddCooldownTagDuration_Params Parms;
	Parms.CooldownTag = CooldownTag;
	Parms.CoolDownDuration = CoolDownDuration;
	Parms.bAddToExistingDuration = bAddToExistingDuration;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BlackboardComponent.SetValueAsVector
// (Final, Native, Public, HasOutParams, HasDefaults, BlueprintCallable)
// Parameters:
// class FName                        KeyName                                                          
// struct FVector                     VectorValue                                                      

void UBlackboardComponent::SetValueAsVector(class FName& KeyName, const struct FVector& VectorValue)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.SetValueAsVector"));

	Params::UBlackboardComponent_SetValueAsVector_Params Parms;
	Parms.KeyName = KeyName;
	Parms.VectorValue = VectorValue;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BlackboardComponent.SetValueAsString
// (Final, Native, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class FName                        KeyName                                                          
// class FString                      StringValue                                                      

void UBlackboardComponent::SetValueAsString(class FName& KeyName, const class FString& StringValue)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.SetValueAsString"));

	Params::UBlackboardComponent_SetValueAsString_Params Parms;
	Parms.KeyName = KeyName;
	Parms.StringValue = StringValue;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BlackboardComponent.SetValueAsRotator
// (Final, Native, Public, HasOutParams, HasDefaults, BlueprintCallable)
// Parameters:
// class FName                        KeyName                                                          
// struct FRotator                    VectorValue                                                      

void UBlackboardComponent::SetValueAsRotator(class FName& KeyName, const struct FRotator& VectorValue)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.SetValueAsRotator"));

	Params::UBlackboardComponent_SetValueAsRotator_Params Parms;
	Parms.KeyName = KeyName;
	Parms.VectorValue = VectorValue;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BlackboardComponent.SetValueAsObject
// (Final, Native, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class FName                        KeyName                                                          
// class UObject*                     ObjectValue                                                      

void UBlackboardComponent::SetValueAsObject(class FName& KeyName, class UObject* ObjectValue)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.SetValueAsObject"));

	Params::UBlackboardComponent_SetValueAsObject_Params Parms;
	Parms.KeyName = KeyName;
	Parms.ObjectValue = ObjectValue;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BlackboardComponent.SetValueAsName
// (Final, Native, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class FName                        KeyName                                                          
// class FName                        NameValue                                                        

void UBlackboardComponent::SetValueAsName(class FName& KeyName, class FName NameValue)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.SetValueAsName"));

	Params::UBlackboardComponent_SetValueAsName_Params Parms;
	Parms.KeyName = KeyName;
	Parms.NameValue = NameValue;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BlackboardComponent.SetValueAsInt
// (Final, Native, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class FName                        KeyName                                                          
// int32                              IntValue                                                         

void UBlackboardComponent::SetValueAsInt(class FName& KeyName, int32 IntValue)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.SetValueAsInt"));

	Params::UBlackboardComponent_SetValueAsInt_Params Parms;
	Parms.KeyName = KeyName;
	Parms.IntValue = IntValue;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BlackboardComponent.SetValueAsFloat
// (Final, Native, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class FName                        KeyName                                                          
// float                              FloatValue                                                       

void UBlackboardComponent::SetValueAsFloat(class FName& KeyName, float FloatValue)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.SetValueAsFloat"));

	Params::UBlackboardComponent_SetValueAsFloat_Params Parms;
	Parms.KeyName = KeyName;
	Parms.FloatValue = FloatValue;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BlackboardComponent.SetValueAsEnum
// (Final, Native, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class FName                        KeyName                                                          
// uint8                              EnumValue                                                        

void UBlackboardComponent::SetValueAsEnum(class FName& KeyName, uint8 EnumValue)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.SetValueAsEnum"));

	Params::UBlackboardComponent_SetValueAsEnum_Params Parms;
	Parms.KeyName = KeyName;
	Parms.EnumValue = EnumValue;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BlackboardComponent.SetValueAsClass
// (Final, Native, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class FName                        KeyName                                                          
// class UClass*                      ClassValue                                                       

void UBlackboardComponent::SetValueAsClass(class FName& KeyName, class UClass* ClassValue)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.SetValueAsClass"));

	Params::UBlackboardComponent_SetValueAsClass_Params Parms;
	Parms.KeyName = KeyName;
	Parms.ClassValue = ClassValue;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BlackboardComponent.SetValueAsBool
// (Final, Native, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class FName                        KeyName                                                          
// bool                               BoolValue                                                        

void UBlackboardComponent::SetValueAsBool(class FName& KeyName, bool BoolValue)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.SetValueAsBool"));

	Params::UBlackboardComponent_SetValueAsBool_Params Parms;
	Parms.KeyName = KeyName;
	Parms.BoolValue = BoolValue;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BlackboardComponent.IsVectorValueSet
// (Final, Native, Public, HasOutParams, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FName                        KeyName                                                          
// bool                               ReturnValue                                                      

bool UBlackboardComponent::IsVectorValueSet(class FName& KeyName)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.IsVectorValueSet"));

	Params::UBlackboardComponent_IsVectorValueSet_Params Parms;
	Parms.KeyName = KeyName;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BlackboardComponent.GetValueAsVector
// (Final, Native, Public, HasOutParams, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FName                        KeyName                                                          
// struct FVector                     ReturnValue                                                      

struct FVector UBlackboardComponent::GetValueAsVector(class FName& KeyName)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.GetValueAsVector"));

	Params::UBlackboardComponent_GetValueAsVector_Params Parms;
	Parms.KeyName = KeyName;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BlackboardComponent.GetValueAsString
// (Final, Native, Public, HasOutParams, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FName                        KeyName                                                          
// class FString                      ReturnValue                                                      

class FString UBlackboardComponent::GetValueAsString(class FName& KeyName)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.GetValueAsString"));

	Params::UBlackboardComponent_GetValueAsString_Params Parms;
	Parms.KeyName = KeyName;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BlackboardComponent.GetValueAsRotator
// (Final, Native, Public, HasOutParams, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FName                        KeyName                                                          
// struct FRotator                    ReturnValue                                                      

struct FRotator UBlackboardComponent::GetValueAsRotator(class FName& KeyName)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.GetValueAsRotator"));

	Params::UBlackboardComponent_GetValueAsRotator_Params Parms;
	Parms.KeyName = KeyName;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BlackboardComponent.GetValueAsObject
// (Final, Native, Public, HasOutParams, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FName                        KeyName                                                          
// class UObject*                     ReturnValue                                                      

class UObject* UBlackboardComponent::GetValueAsObject(class FName& KeyName)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.GetValueAsObject"));

	Params::UBlackboardComponent_GetValueAsObject_Params Parms;
	Parms.KeyName = KeyName;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BlackboardComponent.GetValueAsName
// (Final, Native, Public, HasOutParams, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FName                        KeyName                                                          
// class FName                        ReturnValue                                                      

class FName UBlackboardComponent::GetValueAsName(class FName& KeyName)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.GetValueAsName"));

	Params::UBlackboardComponent_GetValueAsName_Params Parms;
	Parms.KeyName = KeyName;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BlackboardComponent.GetValueAsInt
// (Final, Native, Public, HasOutParams, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FName                        KeyName                                                          
// int32                              ReturnValue                                                      

int32 UBlackboardComponent::GetValueAsInt(class FName& KeyName)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.GetValueAsInt"));

	Params::UBlackboardComponent_GetValueAsInt_Params Parms;
	Parms.KeyName = KeyName;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BlackboardComponent.GetValueAsFloat
// (Final, Native, Public, HasOutParams, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FName                        KeyName                                                          
// float                              ReturnValue                                                      

float UBlackboardComponent::GetValueAsFloat(class FName& KeyName)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.GetValueAsFloat"));

	Params::UBlackboardComponent_GetValueAsFloat_Params Parms;
	Parms.KeyName = KeyName;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BlackboardComponent.GetValueAsEnum
// (Final, Native, Public, HasOutParams, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FName                        KeyName                                                          
// uint8                              ReturnValue                                                      

uint8 UBlackboardComponent::GetValueAsEnum(class FName& KeyName)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.GetValueAsEnum"));

	Params::UBlackboardComponent_GetValueAsEnum_Params Parms;
	Parms.KeyName = KeyName;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BlackboardComponent.GetValueAsClass
// (Final, Native, Public, HasOutParams, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FName                        KeyName                                                          
// class UClass*                      ReturnValue                                                      

class UClass* UBlackboardComponent::GetValueAsClass(class FName& KeyName)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.GetValueAsClass"));

	Params::UBlackboardComponent_GetValueAsClass_Params Parms;
	Parms.KeyName = KeyName;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BlackboardComponent.GetValueAsBool
// (Final, Native, Public, HasOutParams, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FName                        KeyName                                                          
// bool                               ReturnValue                                                      

bool UBlackboardComponent::GetValueAsBool(class FName& KeyName)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.GetValueAsBool"));

	Params::UBlackboardComponent_GetValueAsBool_Params Parms;
	Parms.KeyName = KeyName;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BlackboardComponent.GetRotationFromEntry
// (Final, Native, Public, HasOutParams, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FName                        KeyName                                                          
// struct FRotator                    ResultRotation                                                   
// bool                               ReturnValue                                                      

bool UBlackboardComponent::GetRotationFromEntry(class FName& KeyName, struct FRotator* ResultRotation)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.GetRotationFromEntry"));

	Params::UBlackboardComponent_GetRotationFromEntry_Params Parms;
	Parms.KeyName = KeyName;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	if (ResultRotation != nullptr)
		*ResultRotation = Parms.ResultRotation;

	return Parms.ReturnValue;

}


// Function AIModule.BlackboardComponent.GetLocationFromEntry
// (Final, Native, Public, HasOutParams, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FName                        KeyName                                                          
// struct FVector                     ResultLocation                                                   
// bool                               ReturnValue                                                      

bool UBlackboardComponent::GetLocationFromEntry(class FName& KeyName, struct FVector* ResultLocation)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.GetLocationFromEntry"));

	Params::UBlackboardComponent_GetLocationFromEntry_Params Parms;
	Parms.KeyName = KeyName;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	if (ResultLocation != nullptr)
		*ResultLocation = Parms.ResultLocation;

	return Parms.ReturnValue;

}


// Function AIModule.BlackboardComponent.ClearValueAsVector
// (Final, Native, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class FName                        KeyName                                                          

void UBlackboardComponent::ClearValueAsVector(class FName& KeyName)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.ClearValueAsVector"));

	Params::UBlackboardComponent_ClearValueAsVector_Params Parms;
	Parms.KeyName = KeyName;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BlackboardComponent.ClearValueAsRotator
// (Final, Native, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class FName                        KeyName                                                          

void UBlackboardComponent::ClearValueAsRotator(class FName& KeyName)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.ClearValueAsRotator"));

	Params::UBlackboardComponent_ClearValueAsRotator_Params Parms;
	Parms.KeyName = KeyName;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BlackboardComponent.ClearValue
// (Final, Native, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class FName                        KeyName                                                          

void UBlackboardComponent::ClearValue(class FName& KeyName)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BlackboardComponent.ClearValue"));

	Params::UBlackboardComponent_ClearValue_Params Parms;
	Parms.KeyName = KeyName;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTFunctionLibrary.StopUsingExternalEvent
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UBTNode*                     NodeOwner                                                        

void UBTFunctionLibrary::StopUsingExternalEvent(class UBTNode* NodeOwner)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.StopUsingExternalEvent"));

	Params::UBTFunctionLibrary_StopUsingExternalEvent_Params Parms;
	Parms.NodeOwner = NodeOwner;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTFunctionLibrary.StartUsingExternalEvent
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// class AActor*                      OwningActor                                                      

void UBTFunctionLibrary::StartUsingExternalEvent(class UBTNode* NodeOwner, class AActor* OwningActor)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.StartUsingExternalEvent"));

	Params::UBTFunctionLibrary_StartUsingExternalEvent_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.OwningActor = OwningActor;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsVector
// (Final, Native, Static, Public, HasOutParams, HasDefaults, BlueprintCallable)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// struct FVector                     Value                                                            

void UBTFunctionLibrary::SetBlackboardValueAsVector(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, const struct FVector& Value)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsVector"));

	Params::UBTFunctionLibrary_SetBlackboardValueAsVector_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;
	Parms.Value = Value;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsString
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// class FString                      Value                                                            

void UBTFunctionLibrary::SetBlackboardValueAsString(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, const class FString& Value)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsString"));

	Params::UBTFunctionLibrary_SetBlackboardValueAsString_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;
	Parms.Value = Value;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsRotator
// (Final, Native, Static, Public, HasOutParams, HasDefaults, BlueprintCallable)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// struct FRotator                    Value                                                            

void UBTFunctionLibrary::SetBlackboardValueAsRotator(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, const struct FRotator& Value)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsRotator"));

	Params::UBTFunctionLibrary_SetBlackboardValueAsRotator_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;
	Parms.Value = Value;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsObject
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// class UObject*                     Value                                                            

void UBTFunctionLibrary::SetBlackboardValueAsObject(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, class UObject* Value)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsObject"));

	Params::UBTFunctionLibrary_SetBlackboardValueAsObject_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;
	Parms.Value = Value;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsName
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// class FName                        Value                                                            

void UBTFunctionLibrary::SetBlackboardValueAsName(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, class FName Value)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsName"));

	Params::UBTFunctionLibrary_SetBlackboardValueAsName_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;
	Parms.Value = Value;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsInt
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// int32                              Value                                                            

void UBTFunctionLibrary::SetBlackboardValueAsInt(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, int32 Value)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsInt"));

	Params::UBTFunctionLibrary_SetBlackboardValueAsInt_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;
	Parms.Value = Value;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsFloat
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// float                              Value                                                            

void UBTFunctionLibrary::SetBlackboardValueAsFloat(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, float Value)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsFloat"));

	Params::UBTFunctionLibrary_SetBlackboardValueAsFloat_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;
	Parms.Value = Value;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsEnum
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// uint8                              Value                                                            

void UBTFunctionLibrary::SetBlackboardValueAsEnum(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, uint8 Value)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsEnum"));

	Params::UBTFunctionLibrary_SetBlackboardValueAsEnum_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;
	Parms.Value = Value;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsClass
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// class UClass*                      Value                                                            

void UBTFunctionLibrary::SetBlackboardValueAsClass(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, class UClass* Value)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsClass"));

	Params::UBTFunctionLibrary_SetBlackboardValueAsClass_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;
	Parms.Value = Value;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsBool
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// bool                               Value                                                            

void UBTFunctionLibrary::SetBlackboardValueAsBool(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, bool Value)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsBool"));

	Params::UBTFunctionLibrary_SetBlackboardValueAsBool_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;
	Parms.Value = Value;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTFunctionLibrary.GetOwnersBlackboard
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// class UBlackboardComponent*        ReturnValue                                                      

class UBlackboardComponent* UBTFunctionLibrary::GetOwnersBlackboard(class UBTNode* NodeOwner)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.GetOwnersBlackboard"));

	Params::UBTFunctionLibrary_GetOwnersBlackboard_Params Parms;
	Parms.NodeOwner = NodeOwner;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BTFunctionLibrary.GetOwnerComponent
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// class UBehaviorTreeComponent*      ReturnValue                                                      

class UBehaviorTreeComponent* UBTFunctionLibrary::GetOwnerComponent(class UBTNode* NodeOwner)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.GetOwnerComponent"));

	Params::UBTFunctionLibrary_GetOwnerComponent_Params Parms;
	Parms.NodeOwner = NodeOwner;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsVector
// (Final, Native, Static, Public, HasOutParams, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// struct FVector                     ReturnValue                                                      

struct FVector UBTFunctionLibrary::GetBlackboardValueAsVector(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsVector"));

	Params::UBTFunctionLibrary_GetBlackboardValueAsVector_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsString
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable, BlueprintPure)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// class FString                      ReturnValue                                                      

class FString UBTFunctionLibrary::GetBlackboardValueAsString(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsString"));

	Params::UBTFunctionLibrary_GetBlackboardValueAsString_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsRotator
// (Final, Native, Static, Public, HasOutParams, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// struct FRotator                    ReturnValue                                                      

struct FRotator UBTFunctionLibrary::GetBlackboardValueAsRotator(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsRotator"));

	Params::UBTFunctionLibrary_GetBlackboardValueAsRotator_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsObject
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable, BlueprintPure)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// class UObject*                     ReturnValue                                                      

class UObject* UBTFunctionLibrary::GetBlackboardValueAsObject(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsObject"));

	Params::UBTFunctionLibrary_GetBlackboardValueAsObject_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsName
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable, BlueprintPure)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// class FName                        ReturnValue                                                      

class FName UBTFunctionLibrary::GetBlackboardValueAsName(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsName"));

	Params::UBTFunctionLibrary_GetBlackboardValueAsName_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsInt
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable, BlueprintPure)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// int32                              ReturnValue                                                      

int32 UBTFunctionLibrary::GetBlackboardValueAsInt(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsInt"));

	Params::UBTFunctionLibrary_GetBlackboardValueAsInt_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsFloat
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable, BlueprintPure)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// float                              ReturnValue                                                      

float UBTFunctionLibrary::GetBlackboardValueAsFloat(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsFloat"));

	Params::UBTFunctionLibrary_GetBlackboardValueAsFloat_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsEnum
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable, BlueprintPure)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// uint8                              ReturnValue                                                      

uint8 UBTFunctionLibrary::GetBlackboardValueAsEnum(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsEnum"));

	Params::UBTFunctionLibrary_GetBlackboardValueAsEnum_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsClass
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable, BlueprintPure)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// class UClass*                      ReturnValue                                                      

class UClass* UBTFunctionLibrary::GetBlackboardValueAsClass(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsClass"));

	Params::UBTFunctionLibrary_GetBlackboardValueAsClass_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsBool
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable, BlueprintPure)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// bool                               ReturnValue                                                      

bool UBTFunctionLibrary::GetBlackboardValueAsBool(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsBool"));

	Params::UBTFunctionLibrary_GetBlackboardValueAsBool_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsActor
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable, BlueprintPure)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              
// class AActor*                      ReturnValue                                                      

class AActor* UBTFunctionLibrary::GetBlackboardValueAsActor(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsActor"));

	Params::UBTFunctionLibrary_GetBlackboardValueAsActor_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BTFunctionLibrary.ClearBlackboardValueAsVector
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              

void UBTFunctionLibrary::ClearBlackboardValueAsVector(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.ClearBlackboardValueAsVector"));

	Params::UBTFunctionLibrary_ClearBlackboardValueAsVector_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTFunctionLibrary.ClearBlackboardValue
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class UBTNode*                     NodeOwner                                                        
// struct FBlackboardKeySelector      Key                                                              

void UBTFunctionLibrary::ClearBlackboardValue(class UBTNode* NodeOwner, struct FBlackboardKeySelector& Key)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTFunctionLibrary.ClearBlackboardValue"));

	Params::UBTFunctionLibrary_ClearBlackboardValue_Params Parms;
	Parms.NodeOwner = NodeOwner;
	Parms.Key = Key;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveTickAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AAIController*               OwnerController                                                  
// class APawn*                       ControlledPawn                                                   
// float                              DeltaSeconds                                                     

void UBTDecorator_BlueprintBase::ReceiveTickAI(class AAIController* OwnerController, class APawn* ControlledPawn, float DeltaSeconds)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTDecorator_BlueprintBase.ReceiveTickAI"));

	Params::UBTDecorator_BlueprintBase_ReceiveTickAI_Params Parms;
	Parms.OwnerController = OwnerController;
	Parms.ControlledPawn = ControlledPawn;
	Parms.DeltaSeconds = DeltaSeconds;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveTick
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AActor*                      OwnerActor                                                       
// float                              DeltaSeconds                                                     

void UBTDecorator_BlueprintBase::ReceiveTick(class AActor* OwnerActor, float DeltaSeconds)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTDecorator_BlueprintBase.ReceiveTick"));

	Params::UBTDecorator_BlueprintBase_ReceiveTick_Params Parms;
	Parms.OwnerActor = OwnerActor;
	Parms.DeltaSeconds = DeltaSeconds;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivatedAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AAIController*               OwnerController                                                  
// class APawn*                       ControlledPawn                                                   

void UBTDecorator_BlueprintBase::ReceiveObserverDeactivatedAI(class AAIController* OwnerController, class APawn* ControlledPawn)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivatedAI"));

	Params::UBTDecorator_BlueprintBase_ReceiveObserverDeactivatedAI_Params Parms;
	Parms.OwnerController = OwnerController;
	Parms.ControlledPawn = ControlledPawn;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivated
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AActor*                      OwnerActor                                                       

void UBTDecorator_BlueprintBase::ReceiveObserverDeactivated(class AActor* OwnerActor)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivated"));

	Params::UBTDecorator_BlueprintBase_ReceiveObserverDeactivated_Params Parms;
	Parms.OwnerActor = OwnerActor;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivatedAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AAIController*               OwnerController                                                  
// class APawn*                       ControlledPawn                                                   

void UBTDecorator_BlueprintBase::ReceiveObserverActivatedAI(class AAIController* OwnerController, class APawn* ControlledPawn)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivatedAI"));

	Params::UBTDecorator_BlueprintBase_ReceiveObserverActivatedAI_Params Parms;
	Parms.OwnerController = OwnerController;
	Parms.ControlledPawn = ControlledPawn;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivated
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AActor*                      OwnerActor                                                       

void UBTDecorator_BlueprintBase::ReceiveObserverActivated(class AActor* OwnerActor)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivated"));

	Params::UBTDecorator_BlueprintBase_ReceiveObserverActivated_Params Parms;
	Parms.OwnerActor = OwnerActor;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStartAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AAIController*               OwnerController                                                  
// class APawn*                       ControlledPawn                                                   

void UBTDecorator_BlueprintBase::ReceiveExecutionStartAI(class AAIController* OwnerController, class APawn* ControlledPawn)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStartAI"));

	Params::UBTDecorator_BlueprintBase_ReceiveExecutionStartAI_Params Parms;
	Parms.OwnerController = OwnerController;
	Parms.ControlledPawn = ControlledPawn;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStart
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AActor*                      OwnerActor                                                       

void UBTDecorator_BlueprintBase::ReceiveExecutionStart(class AActor* OwnerActor)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStart"));

	Params::UBTDecorator_BlueprintBase_ReceiveExecutionStart_Params Parms;
	Parms.OwnerActor = OwnerActor;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinishAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AAIController*               OwnerController                                                  
// class APawn*                       ControlledPawn                                                   
// enum class EBTNodeResult           NodeResult                                                       

void UBTDecorator_BlueprintBase::ReceiveExecutionFinishAI(class AAIController* OwnerController, class APawn* ControlledPawn, enum class EBTNodeResult NodeResult)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinishAI"));

	Params::UBTDecorator_BlueprintBase_ReceiveExecutionFinishAI_Params Parms;
	Parms.OwnerController = OwnerController;
	Parms.ControlledPawn = ControlledPawn;
	Parms.NodeResult = NodeResult;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinish
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AActor*                      OwnerActor                                                       
// enum class EBTNodeResult           NodeResult                                                       

void UBTDecorator_BlueprintBase::ReceiveExecutionFinish(class AActor* OwnerActor, enum class EBTNodeResult NodeResult)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinish"));

	Params::UBTDecorator_BlueprintBase_ReceiveExecutionFinish_Params Parms;
	Parms.OwnerActor = OwnerActor;
	Parms.NodeResult = NodeResult;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveConditionCheck
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AActor*                      OwnerActor                                                       

void UBTDecorator_BlueprintBase::ReceiveConditionCheck(class AActor* OwnerActor)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTDecorator_BlueprintBase.ReceiveConditionCheck"));

	Params::UBTDecorator_BlueprintBase_ReceiveConditionCheck_Params Parms;
	Parms.OwnerActor = OwnerActor;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheckAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AAIController*               OwnerController                                                  
// class APawn*                       ControlledPawn                                                   
// bool                               ReturnValue                                                      

bool UBTDecorator_BlueprintBase::PerformConditionCheckAI(class AAIController* OwnerController, class APawn* ControlledPawn)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheckAI"));

	Params::UBTDecorator_BlueprintBase_PerformConditionCheckAI_Params Parms;
	Parms.OwnerController = OwnerController;
	Parms.ControlledPawn = ControlledPawn;

	UObject::ProcessEvent(Func, &Parms);

	return Parms.ReturnValue;

}


// Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheck
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AActor*                      OwnerActor                                                       
// bool                               ReturnValue                                                      

bool UBTDecorator_BlueprintBase::PerformConditionCheck(class AActor* OwnerActor)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheck"));

	Params::UBTDecorator_BlueprintBase_PerformConditionCheck_Params Parms;
	Parms.OwnerActor = OwnerActor;

	UObject::ProcessEvent(Func, &Parms);

	return Parms.ReturnValue;

}


// Function AIModule.BTDecorator_BlueprintBase.IsDecoratorObserverActive
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                               ReturnValue                                                      

bool UBTDecorator_BlueprintBase::IsDecoratorObserverActive()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTDecorator_BlueprintBase.IsDecoratorObserverActive"));

	Params::UBTDecorator_BlueprintBase_IsDecoratorObserverActive_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BTDecorator_BlueprintBase.IsDecoratorExecutionActive
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                               ReturnValue                                                      

bool UBTDecorator_BlueprintBase::IsDecoratorExecutionActive()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTDecorator_BlueprintBase.IsDecoratorExecutionActive"));

	Params::UBTDecorator_BlueprintBase_IsDecoratorExecutionActive_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BTDecorator_BlueprintBase.FinishConditionCheck
// (Final, Native, Protected, BlueprintCallable)
// Parameters:
// bool                               bAllowExecution                                                  

void UBTDecorator_BlueprintBase::FinishConditionCheck(bool bAllowExecution)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTDecorator_BlueprintBase.FinishConditionCheck"));

	Params::UBTDecorator_BlueprintBase_FinishConditionCheck_Params Parms;
	Parms.bAllowExecution = bAllowExecution;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTService_BlueprintBase.ReceiveTickAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AAIController*               OwnerController                                                  
// class APawn*                       ControlledPawn                                                   
// float                              DeltaSeconds                                                     

void UBTService_BlueprintBase::ReceiveTickAI(class AAIController* OwnerController, class APawn* ControlledPawn, float DeltaSeconds)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTService_BlueprintBase.ReceiveTickAI"));

	Params::UBTService_BlueprintBase_ReceiveTickAI_Params Parms;
	Parms.OwnerController = OwnerController;
	Parms.ControlledPawn = ControlledPawn;
	Parms.DeltaSeconds = DeltaSeconds;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTService_BlueprintBase.ReceiveTick
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AActor*                      OwnerActor                                                       
// float                              DeltaSeconds                                                     

void UBTService_BlueprintBase::ReceiveTick(class AActor* OwnerActor, float DeltaSeconds)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTService_BlueprintBase.ReceiveTick"));

	Params::UBTService_BlueprintBase_ReceiveTick_Params Parms;
	Parms.OwnerActor = OwnerActor;
	Parms.DeltaSeconds = DeltaSeconds;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTService_BlueprintBase.ReceiveSearchStartAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AAIController*               OwnerController                                                  
// class APawn*                       ControlledPawn                                                   

void UBTService_BlueprintBase::ReceiveSearchStartAI(class AAIController* OwnerController, class APawn* ControlledPawn)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTService_BlueprintBase.ReceiveSearchStartAI"));

	Params::UBTService_BlueprintBase_ReceiveSearchStartAI_Params Parms;
	Parms.OwnerController = OwnerController;
	Parms.ControlledPawn = ControlledPawn;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTService_BlueprintBase.ReceiveSearchStart
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AActor*                      OwnerActor                                                       

void UBTService_BlueprintBase::ReceiveSearchStart(class AActor* OwnerActor)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTService_BlueprintBase.ReceiveSearchStart"));

	Params::UBTService_BlueprintBase_ReceiveSearchStart_Params Parms;
	Parms.OwnerActor = OwnerActor;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTService_BlueprintBase.ReceiveDeactivationAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AAIController*               OwnerController                                                  
// class APawn*                       ControlledPawn                                                   

void UBTService_BlueprintBase::ReceiveDeactivationAI(class AAIController* OwnerController, class APawn* ControlledPawn)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTService_BlueprintBase.ReceiveDeactivationAI"));

	Params::UBTService_BlueprintBase_ReceiveDeactivationAI_Params Parms;
	Parms.OwnerController = OwnerController;
	Parms.ControlledPawn = ControlledPawn;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTService_BlueprintBase.ReceiveDeactivation
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AActor*                      OwnerActor                                                       

void UBTService_BlueprintBase::ReceiveDeactivation(class AActor* OwnerActor)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTService_BlueprintBase.ReceiveDeactivation"));

	Params::UBTService_BlueprintBase_ReceiveDeactivation_Params Parms;
	Parms.OwnerActor = OwnerActor;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTService_BlueprintBase.ReceiveActivationAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AAIController*               OwnerController                                                  
// class APawn*                       ControlledPawn                                                   

void UBTService_BlueprintBase::ReceiveActivationAI(class AAIController* OwnerController, class APawn* ControlledPawn)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTService_BlueprintBase.ReceiveActivationAI"));

	Params::UBTService_BlueprintBase_ReceiveActivationAI_Params Parms;
	Parms.OwnerController = OwnerController;
	Parms.ControlledPawn = ControlledPawn;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTService_BlueprintBase.ReceiveActivation
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AActor*                      OwnerActor                                                       

void UBTService_BlueprintBase::ReceiveActivation(class AActor* OwnerActor)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTService_BlueprintBase.ReceiveActivation"));

	Params::UBTService_BlueprintBase_ReceiveActivation_Params Parms;
	Parms.OwnerActor = OwnerActor;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTService_BlueprintBase.IsServiceActive
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                               ReturnValue                                                      

bool UBTService_BlueprintBase::IsServiceActive()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTService_BlueprintBase.IsServiceActive"));

	Params::UBTService_BlueprintBase_IsServiceActive_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BTTask_BlueprintBase.SetFinishOnMessageWithId
// (Final, Native, Protected, BlueprintCallable)
// Parameters:
// class FName                        MessageName                                                      
// int32                              RequestID                                                        

void UBTTask_BlueprintBase::SetFinishOnMessageWithId(class FName MessageName, int32 RequestID)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTTask_BlueprintBase.SetFinishOnMessageWithId"));

	Params::UBTTask_BlueprintBase_SetFinishOnMessageWithId_Params Parms;
	Parms.MessageName = MessageName;
	Parms.RequestID = RequestID;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTTask_BlueprintBase.SetFinishOnMessage
// (Final, Native, Protected, BlueprintCallable)
// Parameters:
// class FName                        MessageName                                                      

void UBTTask_BlueprintBase::SetFinishOnMessage(class FName MessageName)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTTask_BlueprintBase.SetFinishOnMessage"));

	Params::UBTTask_BlueprintBase_SetFinishOnMessage_Params Parms;
	Parms.MessageName = MessageName;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTTask_BlueprintBase.ReceiveTickAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AAIController*               OwnerController                                                  
// class APawn*                       ControlledPawn                                                   
// float                              DeltaSeconds                                                     

void UBTTask_BlueprintBase::ReceiveTickAI(class AAIController* OwnerController, class APawn* ControlledPawn, float DeltaSeconds)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTTask_BlueprintBase.ReceiveTickAI"));

	Params::UBTTask_BlueprintBase_ReceiveTickAI_Params Parms;
	Parms.OwnerController = OwnerController;
	Parms.ControlledPawn = ControlledPawn;
	Parms.DeltaSeconds = DeltaSeconds;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTTask_BlueprintBase.ReceiveTick
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AActor*                      OwnerActor                                                       
// float                              DeltaSeconds                                                     

void UBTTask_BlueprintBase::ReceiveTick(class AActor* OwnerActor, float DeltaSeconds)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTTask_BlueprintBase.ReceiveTick"));

	Params::UBTTask_BlueprintBase_ReceiveTick_Params Parms;
	Parms.OwnerActor = OwnerActor;
	Parms.DeltaSeconds = DeltaSeconds;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTTask_BlueprintBase.ReceiveExecuteAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AAIController*               OwnerController                                                  
// class APawn*                       ControlledPawn                                                   

void UBTTask_BlueprintBase::ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTTask_BlueprintBase.ReceiveExecuteAI"));

	Params::UBTTask_BlueprintBase_ReceiveExecuteAI_Params Parms;
	Parms.OwnerController = OwnerController;
	Parms.ControlledPawn = ControlledPawn;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTTask_BlueprintBase.ReceiveExecute
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AActor*                      OwnerActor                                                       

void UBTTask_BlueprintBase::ReceiveExecute(class AActor* OwnerActor)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTTask_BlueprintBase.ReceiveExecute"));

	Params::UBTTask_BlueprintBase_ReceiveExecute_Params Parms;
	Parms.OwnerActor = OwnerActor;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTTask_BlueprintBase.ReceiveAbortAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AAIController*               OwnerController                                                  
// class APawn*                       ControlledPawn                                                   

void UBTTask_BlueprintBase::ReceiveAbortAI(class AAIController* OwnerController, class APawn* ControlledPawn)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTTask_BlueprintBase.ReceiveAbortAI"));

	Params::UBTTask_BlueprintBase_ReceiveAbortAI_Params Parms;
	Parms.OwnerController = OwnerController;
	Parms.ControlledPawn = ControlledPawn;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTTask_BlueprintBase.ReceiveAbort
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AActor*                      OwnerActor                                                       

void UBTTask_BlueprintBase::ReceiveAbort(class AActor* OwnerActor)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTTask_BlueprintBase.ReceiveAbort"));

	Params::UBTTask_BlueprintBase_ReceiveAbort_Params Parms;
	Parms.OwnerActor = OwnerActor;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.BTTask_BlueprintBase.IsTaskExecuting
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                               ReturnValue                                                      

bool UBTTask_BlueprintBase::IsTaskExecuting()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTTask_BlueprintBase.IsTaskExecuting"));

	Params::UBTTask_BlueprintBase_IsTaskExecuting_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BTTask_BlueprintBase.IsTaskAborting
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                               ReturnValue                                                      

bool UBTTask_BlueprintBase::IsTaskAborting()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTTask_BlueprintBase.IsTaskAborting"));

	Params::UBTTask_BlueprintBase_IsTaskAborting_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.BTTask_BlueprintBase.FinishExecute
// (Final, Native, Protected, BlueprintCallable)
// Parameters:
// bool                               bSuccess                                                         

void UBTTask_BlueprintBase::FinishExecute(bool bSuccess)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTTask_BlueprintBase.FinishExecute"));

	Params::UBTTask_BlueprintBase_FinishExecute_Params Parms;
	Parms.bSuccess = bSuccess;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.BTTask_BlueprintBase.FinishAbort
// (Final, Native, Protected, BlueprintCallable)
// Parameters:

void UBTTask_BlueprintBase::FinishAbort()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.BTTask_BlueprintBase.FinishAbort"));

	Params::UBTTask_BlueprintBase_FinishAbort_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.PawnAction.GetActionPriority
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// enum class EAIRequestPriority      ReturnValue                                                      

enum class EAIRequestPriority UPawnAction::GetActionPriority()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PawnAction.GetActionPriority"));

	Params::UPawnAction_GetActionPriority_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.PawnAction.Finish
// (Native, Protected, BlueprintCallable)
// Parameters:
// enum class EPawnActionResult       WithResult                                                       

void UPawnAction::Finish(enum class EPawnActionResult WithResult)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PawnAction.Finish"));

	Params::UPawnAction_Finish_Params Parms;
	Parms.WithResult = WithResult;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.PawnAction.CreateActionInstance
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UObject*                     WorldContextObject                                               
// TSubclassOf<class UPawnAction>     ActionClass                                                      
// class UPawnAction*                 ReturnValue                                                      

class UPawnAction* UPawnAction::CreateActionInstance(class UObject* WorldContextObject, TSubclassOf<class UPawnAction> ActionClass)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PawnAction.CreateActionInstance"));

	Params::UPawnAction_CreateActionInstance_Params Parms;
	Parms.WorldContextObject = WorldContextObject;
	Parms.ActionClass = ActionClass;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleLocation
// (Event, Public, HasOutParams, HasDefaults, BlueprintEvent, Const)
// Parameters:
// class AActor*                      QuerierActor                                                     
// struct FVector                     ResultingLocation                                                

void UEnvQueryContext_BlueprintBase::ProvideSingleLocation(class AActor* QuerierActor, struct FVector* ResultingLocation)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleLocation"));

	Params::UEnvQueryContext_BlueprintBase_ProvideSingleLocation_Params Parms;
	Parms.QuerierActor = QuerierActor;

	UObject::ProcessEvent(Func, &Parms);

	if (ResultingLocation != nullptr)
		*ResultingLocation = Parms.ResultingLocation;

}


// Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleActor
// (Event, Public, HasOutParams, BlueprintEvent, Const)
// Parameters:
// class AActor*                      QuerierActor                                                     
// class AActor*                      ResultingActor                                                   

void UEnvQueryContext_BlueprintBase::ProvideSingleActor(class AActor* QuerierActor, class AActor** ResultingActor)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleActor"));

	Params::UEnvQueryContext_BlueprintBase_ProvideSingleActor_Params Parms;
	Parms.QuerierActor = QuerierActor;

	UObject::ProcessEvent(Func, &Parms);

	if (ResultingActor != nullptr)
		*ResultingActor = Parms.ResultingActor;

}


// Function AIModule.EnvQueryContext_BlueprintBase.ProvideLocationsSet
// (Event, Public, HasOutParams, BlueprintEvent, Const)
// Parameters:
// class AActor*                      QuerierActor                                                     
// TArray<struct FVector>             ResultingLocationSet                                             

void UEnvQueryContext_BlueprintBase::ProvideLocationsSet(class AActor* QuerierActor, TArray<struct FVector>* ResultingLocationSet)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.EnvQueryContext_BlueprintBase.ProvideLocationsSet"));

	Params::UEnvQueryContext_BlueprintBase_ProvideLocationsSet_Params Parms;
	Parms.QuerierActor = QuerierActor;

	UObject::ProcessEvent(Func, &Parms);

	if (ResultingLocationSet != nullptr)
		*ResultingLocationSet = Parms.ResultingLocationSet;

}


// Function AIModule.EnvQueryContext_BlueprintBase.ProvideActorsSet
// (Event, Public, HasOutParams, BlueprintEvent, Const)
// Parameters:
// class AActor*                      QuerierActor                                                     
// TArray<class AActor*>              ResultingActorsSet                                               

void UEnvQueryContext_BlueprintBase::ProvideActorsSet(class AActor* QuerierActor, TArray<class AActor*>* ResultingActorsSet)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.EnvQueryContext_BlueprintBase.ProvideActorsSet"));

	Params::UEnvQueryContext_BlueprintBase_ProvideActorsSet_Params Parms;
	Parms.QuerierActor = QuerierActor;

	UObject::ProcessEvent(Func, &Parms);

	if (ResultingActorsSet != nullptr)
		*ResultingActorsSet = Parms.ResultingActorsSet;

}


// Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsLocations
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// TArray<struct FVector>             ReturnValue                                                      

TArray<struct FVector> UEnvQueryInstanceBlueprintWrapper::GetResultsAsLocations()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsLocations"));

	Params::UEnvQueryInstanceBlueprintWrapper_GetResultsAsLocations_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsActors
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// TArray<class AActor*>              ReturnValue                                                      

TArray<class AActor*> UEnvQueryInstanceBlueprintWrapper::GetResultsAsActors()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsActors"));

	Params::UEnvQueryInstanceBlueprintWrapper_GetResultsAsActors_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.EnvQueryInstanceBlueprintWrapper.GetItemScore
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// int32                              ItemIndex                                                        
// float                              ReturnValue                                                      

float UEnvQueryInstanceBlueprintWrapper::GetItemScore(int32 ItemIndex)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.EnvQueryInstanceBlueprintWrapper.GetItemScore"));

	Params::UEnvQueryInstanceBlueprintWrapper_GetItemScore_Params Parms;
	Parms.ItemIndex = ItemIndex;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// DelegateFunction AIModule.EnvQueryInstanceBlueprintWrapper.EQSQueryDoneSignature__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// class UEnvQueryInstanceBlueprintWrapper*QueryInstance                                                    
// enum class EEnvQueryStatus         QueryStatus                                                      

void UEnvQueryInstanceBlueprintWrapper::EQSQueryDoneSignature__DelegateSignature(class UEnvQueryInstanceBlueprintWrapper* QueryInstance, enum class EEnvQueryStatus QueryStatus)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("DelegateFunction AIModule.EnvQueryInstanceBlueprintWrapper.EQSQueryDoneSignature__DelegateSignature"));

	Params::UEnvQueryInstanceBlueprintWrapper_EQSQueryDoneSignature__DelegateSignature_Params Parms;
	Parms.QueryInstance = QueryInstance;
	Parms.QueryStatus = QueryStatus;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.EnvQueryManager.RunEQSQuery
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UObject*                     WorldContext                                                     
// class UEnvQuery*                   QueryTemplate                                                    
// class UObject*                     Querier                                                          
// enum class EEnvQueryRunMode        RunMode                                                          
// TSubclassOf<class UEnvQueryInstanceBlueprintWrapper>WrapperClass                                                     
// class UEnvQueryInstanceBlueprintWrapper*ReturnValue                                                      

class UEnvQueryInstanceBlueprintWrapper* UEnvQueryManager::RunEQSQuery(class UObject* WorldContext, class UEnvQuery* QueryTemplate, class UObject* Querier, enum class EEnvQueryRunMode RunMode, TSubclassOf<class UEnvQueryInstanceBlueprintWrapper> WrapperClass)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.EnvQueryManager.RunEQSQuery"));

	Params::UEnvQueryManager_RunEQSQuery_Params Parms;
	Parms.WorldContext = WorldContext;
	Parms.QueryTemplate = QueryTemplate;
	Parms.Querier = Querier;
	Parms.RunMode = RunMode;
	Parms.WrapperClass = WrapperClass;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.EnvQueryGenerator_BlueprintBase.GetQuerier
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class UObject*                     ReturnValue                                                      

class UObject* UEnvQueryGenerator_BlueprintBase::GetQuerier()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.EnvQueryGenerator_BlueprintBase.GetQuerier"));

	Params::UEnvQueryGenerator_BlueprintBase_GetQuerier_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.EnvQueryGenerator_BlueprintBase.DoItemGeneration
// (Event, Public, HasOutParams, BlueprintEvent, Const)
// Parameters:
// TArray<struct FVector>             ContextLocations                                                 

void UEnvQueryGenerator_BlueprintBase::DoItemGeneration(TArray<struct FVector>& ContextLocations)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.EnvQueryGenerator_BlueprintBase.DoItemGeneration"));

	Params::UEnvQueryGenerator_BlueprintBase_DoItemGeneration_Params Parms;
	Parms.ContextLocations = ContextLocations;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedVector
// (Final, Native, Public, HasDefaults, BlueprintCallable, Const)
// Parameters:
// struct FVector                     GeneratedVector                                                  

void UEnvQueryGenerator_BlueprintBase::AddGeneratedVector(const struct FVector& GeneratedVector)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedVector"));

	Params::UEnvQueryGenerator_BlueprintBase_AddGeneratedVector_Params Parms;
	Parms.GeneratedVector = GeneratedVector;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedActor
// (Final, Native, Public, BlueprintCallable, Const)
// Parameters:
// class AActor*                      GeneratedActor                                                   

void UEnvQueryGenerator_BlueprintBase::AddGeneratedActor(class AActor* GeneratedActor)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedActor"));

	Params::UEnvQueryGenerator_BlueprintBase_AddGeneratedActor_Params Parms;
	Parms.GeneratedActor = GeneratedActor;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.CrowdFollowingComponent.SuspendCrowdSteering
// (Native, Public, BlueprintCallable)
// Parameters:
// bool                               bSuspend                                                         

void UCrowdFollowingComponent::SuspendCrowdSteering(bool bSuspend)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.CrowdFollowingComponent.SuspendCrowdSteering"));

	Params::UCrowdFollowingComponent_SuspendCrowdSteering_Params Parms;
	Parms.bSuspend = bSuspend;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.PawnAction_BlueprintBase.ActionTick
// (Event, Public, BlueprintEvent)
// Parameters:
// class APawn*                       ControlledPawn                                                   
// float                              DeltaSeconds                                                     

void UPawnAction_BlueprintBase::ActionTick(class APawn* ControlledPawn, float DeltaSeconds)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PawnAction_BlueprintBase.ActionTick"));

	Params::UPawnAction_BlueprintBase_ActionTick_Params Parms;
	Parms.ControlledPawn = ControlledPawn;
	Parms.DeltaSeconds = DeltaSeconds;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.PawnAction_BlueprintBase.ActionStart
// (Event, Public, BlueprintEvent)
// Parameters:
// class APawn*                       ControlledPawn                                                   

void UPawnAction_BlueprintBase::ActionStart(class APawn* ControlledPawn)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PawnAction_BlueprintBase.ActionStart"));

	Params::UPawnAction_BlueprintBase_ActionStart_Params Parms;
	Parms.ControlledPawn = ControlledPawn;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.PawnAction_BlueprintBase.ActionResume
// (Event, Public, BlueprintEvent)
// Parameters:
// class APawn*                       ControlledPawn                                                   

void UPawnAction_BlueprintBase::ActionResume(class APawn* ControlledPawn)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PawnAction_BlueprintBase.ActionResume"));

	Params::UPawnAction_BlueprintBase_ActionResume_Params Parms;
	Parms.ControlledPawn = ControlledPawn;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.PawnAction_BlueprintBase.ActionPause
// (Event, Public, BlueprintEvent)
// Parameters:
// class APawn*                       ControlledPawn                                                   

void UPawnAction_BlueprintBase::ActionPause(class APawn* ControlledPawn)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PawnAction_BlueprintBase.ActionPause"));

	Params::UPawnAction_BlueprintBase_ActionPause_Params Parms;
	Parms.ControlledPawn = ControlledPawn;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.PawnAction_BlueprintBase.ActionFinished
// (Event, Public, BlueprintEvent)
// Parameters:
// class APawn*                       ControlledPawn                                                   
// enum class EPawnActionResult       WithResult                                                       

void UPawnAction_BlueprintBase::ActionFinished(class APawn* ControlledPawn, enum class EPawnActionResult WithResult)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PawnAction_BlueprintBase.ActionFinished"));

	Params::UPawnAction_BlueprintBase_ActionFinished_Params Parms;
	Parms.ControlledPawn = ControlledPawn;
	Parms.WithResult = WithResult;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.PawnSensingComponent.SetSensingUpdatesEnabled
// (BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// bool                               bEnabled                                                         

void UPawnSensingComponent::SetSensingUpdatesEnabled(bool bEnabled)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PawnSensingComponent.SetSensingUpdatesEnabled"));

	Params::UPawnSensingComponent_SetSensingUpdatesEnabled_Params Parms;
	Parms.bEnabled = bEnabled;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.PawnSensingComponent.SetSensingInterval
// (BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// float                              NewSensingInterval                                               

void UPawnSensingComponent::SetSensingInterval(float NewSensingInterval)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PawnSensingComponent.SetSensingInterval"));

	Params::UPawnSensingComponent_SetSensingInterval_Params Parms;
	Parms.NewSensingInterval = NewSensingInterval;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIModule.PawnSensingComponent.SetPeripheralVisionAngle
// (BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// float                              NewPeripheralVisionAngle                                         

void UPawnSensingComponent::SetPeripheralVisionAngle(float NewPeripheralVisionAngle)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PawnSensingComponent.SetPeripheralVisionAngle"));

	Params::UPawnSensingComponent_SetPeripheralVisionAngle_Params Parms;
	Parms.NewPeripheralVisionAngle = NewPeripheralVisionAngle;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// DelegateFunction AIModule.PawnSensingComponent.SeePawnDelegate__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// class APawn*                       Pawn                                                             

void UPawnSensingComponent::SeePawnDelegate__DelegateSignature(class APawn* Pawn)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("DelegateFunction AIModule.PawnSensingComponent.SeePawnDelegate__DelegateSignature"));

	Params::UPawnSensingComponent_SeePawnDelegate__DelegateSignature_Params Parms;
	Parms.Pawn = Pawn;

	UObject::ProcessEvent(Func, &Parms);

}


// DelegateFunction AIModule.PawnSensingComponent.HearNoiseDelegate__DelegateSignature
// (MulticastDelegate, Public, Delegate, HasOutParams, HasDefaults)
// Parameters:
// class APawn*                       Instigator                                                       
// struct FVector                     Location                                                         
// float                              Volume                                                           

void UPawnSensingComponent::HearNoiseDelegate__DelegateSignature(class APawn* Instigator, struct FVector& Location, float Volume)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("DelegateFunction AIModule.PawnSensingComponent.HearNoiseDelegate__DelegateSignature"));

	Params::UPawnSensingComponent_HearNoiseDelegate__DelegateSignature_Params Parms;
	Parms.Instigator = Instigator;
	Parms.Location = Location;
	Parms.Volume = Volume;

	UObject::ProcessEvent(Func, &Parms);

}


// Function AIModule.PawnSensingComponent.GetPeripheralVisionCosine
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                              ReturnValue                                                      

float UPawnSensingComponent::GetPeripheralVisionCosine()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PawnSensingComponent.GetPeripheralVisionCosine"));

	Params::UPawnSensingComponent_GetPeripheralVisionCosine_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIModule.PawnSensingComponent.GetPeripheralVisionAngle
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                              ReturnValue                                                      

float UPawnSensingComponent::GetPeripheralVisionAngle()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIModule.PawnSensingComponent.GetPeripheralVisionAngle"));

	Params::UPawnSensingComponent_GetPeripheralVisionAngle_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}

}


