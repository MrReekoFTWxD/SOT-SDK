#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// ENUMS
//---------------------------------------------------------------------------------------------------------------------

enum class EArrivalTunnelWorkerState : uint8
{
	Initialise                     = 0,
	SetupAndRetrieveInitialDestinationLocation = 1,
	RetryingRequestEventFromScheduler = 2,
	WaitingForEventHandleStatusChanged = 3,
	WaitingForEQSLocationRequest   = 4,
	ServeDestinationLocationToTunnel = 5,
	StartExitFlow                  = 6,
	EArrivalTunnelWorkerState_MAX  = 7,
};


//---------------------------------------------------------------------------------------------------------------------
// STRUCTS
//---------------------------------------------------------------------------------------------------------------------

// 0x40 (0x40 - 0x0)
// ScriptStruct AdventureOnDemand.AdventureOnDemandServiceCrewEntry
struct FAdventureOnDemandServiceCrewEntry
{
public:
	uint8                                        Pad_37D2[0x38];                                    // Fixing Size After Last Property
	class UTunnelDesc*                           TunnelDesc;                                        // 0x38(0x8)
};

}


