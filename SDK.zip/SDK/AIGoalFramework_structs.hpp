#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// ENUMS
//---------------------------------------------------------------------------------------------------------------------

enum class EAIGoalTargetChangedReason : uint8
{
	NoPreviousTarget               = 0,
	TargetOutOfRange               = 1,
	TargetEnteredInvalidMovementMode = 2,
	HigherPriorityTargetFound      = 3,
	EAIGoalTargetChangedReason_MAX = 4,
};


//---------------------------------------------------------------------------------------------------------------------
// STRUCTS
//---------------------------------------------------------------------------------------------------------------------

// 0x20 (0x20 - 0x0)
// ScriptStruct AIGoalFramework.AIGoalMovementModeFilter
struct FAIGoalMovementModeFilter
{
public:
	TArray<enum class EMovementMode>             DisallowedMovementModes;                           // 0x0(0x10)
	TArray<enum class ECustomMovementModeId>     DisallowedCustomMovementModes;                     // 0x10(0x10)
};

// 0x8 (0x8 - 0x0)
// ScriptStruct AIGoalFramework.EventAIGoalHighPriorityTargetSuggestion
struct FEventAIGoalHighPriorityTargetSuggestion
{
public:
	class AActor*                                HighPriorityTarget;                                // 0x0(0x8)
};

// 0x18 (0x18 - 0x0)
// ScriptStruct AIGoalFramework.EventAIGoalTargetActorChanged
struct FEventAIGoalTargetActorChanged
{
public:
	class AActor*                                PreviousTargetActor;                               // 0x0(0x8)
	class AActor*                                NewTargetActor;                                    // 0x8(0x8)
	enum class EAIGoalTargetChangedReason        TargetChangedReason;                               // 0x10(0x1)
	enum class EMovementMode                     InvalidMovementMode;                               // 0x11(0x1)
	uint8                                        Pad_2BEB[0x6];                                     // Fixing Size Of Struct
};

}


