#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x28 - 0x28)
// Class AIGoalFramework.AIAreaOfOperationInterface
class UAIAreaOfOperationInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIAreaOfOperationInterface"));
		return Clss;
	}

};

// 0x10 (0xD8 - 0xC8)
// Class AIGoalFramework.AIAreaOfOperationComponent
class UAIAreaOfOperationComponent : public UActorComponent
{
public:
	uint8                                        Pad_2BE6[0x8];                                     // Fixing Size After Last Property
	bool                                         UseAreaOfOperationOnSpawn;                         // 0xD0(0x1)
	uint8                                        Pad_2BE7[0x3];                                     // Fixing Size After Last Property
	float                                        InitialRadius;                                     // 0xD4(0x4)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIAreaOfOperationComponent"));
		return Clss;
	}

};

// 0x18 (0x40 - 0x28)
// Class AIGoalFramework.AIGoal
class UAIGoal : public UObject
{
public:
	class UBehaviorTree*                         BehaviorTree;                                      // 0x28(0x8)
	TSubclassOf<class UAIActionActivity>         WhileActiveActivityType;                           // 0x30(0x8)
	uint8                                        Pad_2BE8[0x8];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIGoal"));
		return Clss;
	}

};

// 0x10 (0x38 - 0x28)
// Class AIGoalFramework.AIGoalAssetList
class UAIGoalAssetList : public UDataAsset
{
public:
	TArray<class UAIGoal*>                       GoalTemplates;                                     // 0x28(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIGoalAssetList"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIGoalFramework.AIGoalProcessorInterface
class UAIGoalProcessorInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIGoalProcessorInterface"));
		return Clss;
	}

};

// 0x60 (0x128 - 0xC8)
// Class AIGoalFramework.AIGoalProcessorComponent
class UAIGoalProcessorComponent : public UActorComponent
{
public:
	uint8                                        Pad_2BE9[0x8];                                     // Fixing Size After Last Property
	TArray<class UAIGoal*>                       Goals;                                             // 0xD0(0x10)
	class UAIGoalAssetList*                      AIGoalAssetList;                                   // 0xE0(0x8)
	class UAIGoal*                               ActiveGoal;                                        // 0xE8(0x8)
	TArray<class UAIGoalAssetList*>              AdditionalGoalLists;                               // 0xF0(0x10)
	uint8                                        Pad_2BEA[0x28];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIGoalProcessorComponent"));
		return Clss;
	}

};

// 0x0 (0x128 - 0x128)
// Class AIGoalFramework.FirstActionableAIGoalProcessorComponent
class UFirstActionableAIGoalProcessorComponent : public UAIGoalProcessorComponent
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("FirstActionableAIGoalProcessorComponent"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIGoalFramework.AIHomeInterface
class UAIHomeInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIHomeInterface"));
		return Clss;
	}

};

}


