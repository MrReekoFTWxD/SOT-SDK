#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x4A0 - 0x4A0)
// BlueprintGeneratedClass AD_FirstPerson_PlayerPirate_Male_Thin.AD_FirstPerson_PlayerPirate_Male_Thin_C
class UAD_FirstPerson_PlayerPirate_Male_Thin_C : public UAD_FirstPerson_PlayerPirate_Male_Default_C
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AD_FirstPerson_PlayerPirate_Male_Thin_C"));
		return Clss;
	}

};

}


