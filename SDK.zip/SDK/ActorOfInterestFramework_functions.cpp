#include "pch.h"

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// FUNCTIONS
//---------------------------------------------------------------------------------------------------------------------


// Function ActorOfInterestFramework.ActorOfInterestBlueprintFunctionLibrary.GetActorsOfInterestFromIds
// (Final, RequiredAPI, Native, Static, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class UObject*                     WorldContextObject                                               
// TArray<TSubclassOf<class UActorOfInterestId>>ActorOfInterestIds                                               
// TArray<class AActor*>              Actors                                                           

void UActorOfInterestBlueprintFunctionLibrary::GetActorsOfInterestFromIds(class UObject* WorldContextObject, TArray<TSubclassOf<class UActorOfInterestId>>& ActorOfInterestIds, TArray<class AActor*>* Actors)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActorOfInterestFramework.ActorOfInterestBlueprintFunctionLibrary.GetActorsOfInterestFromIds"));

	Params::UActorOfInterestBlueprintFunctionLibrary_GetActorsOfInterestFromIds_Params Parms;
	Parms.WorldContextObject = WorldContextObject;
	Parms.ActorOfInterestIds = ActorOfInterestIds;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	if (Actors != nullptr)
		*Actors = Parms.Actors;

}


// Function ActorOfInterestFramework.ActorOfInterestBlueprintFunctionLibrary.GetActorOfInterestFromId
// (Final, RequiredAPI, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UObject*                     WorldContextObject                                               
// TSubclassOf<class UActorOfInterestId>ActorOfInterestId                                                
// class AActor*                      ReturnValue                                                      

class AActor* UActorOfInterestBlueprintFunctionLibrary::GetActorOfInterestFromId(class UObject* WorldContextObject, TSubclassOf<class UActorOfInterestId> ActorOfInterestId)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActorOfInterestFramework.ActorOfInterestBlueprintFunctionLibrary.GetActorOfInterestFromId"));

	Params::UActorOfInterestBlueprintFunctionLibrary_GetActorOfInterestFromId_Params Parms;
	Parms.WorldContextObject = WorldContextObject;
	Parms.ActorOfInterestId = ActorOfInterestId;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}

}


