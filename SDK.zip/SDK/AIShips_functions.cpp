#include "pch.h"

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// FUNCTIONS
//---------------------------------------------------------------------------------------------------------------------


// Function AIShips.AIShipDebugFunctionLibrary.RequestAIShipForCrew
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class UObject*                     WorldContextObject                                               
// struct FGuid                       CrewId                                                           

void UAIShipDebugFunctionLibrary::RequestAIShipForCrew(class UObject* WorldContextObject, const struct FGuid& CrewId)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIShips.AIShipDebugFunctionLibrary.RequestAIShipForCrew"));

	Params::UAIShipDebugFunctionLibrary_RequestAIShipForCrew_Params Parms;
	Parms.WorldContextObject = WorldContextObject;
	Parms.CrewId = CrewId;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIShips.AIShipDebugFunctionLibrary.GenerateAIShipBattleDesc
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UObject*                     WorldContextObject                                               
// class UAIShipServiceDataAsset*     ServiceParams                                                    
// struct FAIShipEncounterBattleDesc  ReturnValue                                                      

struct FAIShipEncounterBattleDesc UAIShipDebugFunctionLibrary::GenerateAIShipBattleDesc(class UObject* WorldContextObject, class UAIShipServiceDataAsset* ServiceParams)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIShips.AIShipDebugFunctionLibrary.GenerateAIShipBattleDesc"));

	Params::UAIShipDebugFunctionLibrary_GenerateAIShipBattleDesc_Params Parms;
	Parms.WorldContextObject = WorldContextObject;
	Parms.ServiceParams = ServiceParams;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIShips.AIShipsBlueprintFunctionLibrary.RequestPassiveAIShipForPlayerShip
// (Final, BlueprintAuthorityOnly, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UObject*                     WorldContext                                                     
// class AActor*                      PlayerShip                                                       
// TSubclassOf<class UShipSize>       ForcedAIShipSize                                                 
// bool                               ReturnValue                                                      

bool UAIShipsBlueprintFunctionLibrary::RequestPassiveAIShipForPlayerShip(class UObject* WorldContext, class AActor* PlayerShip, TSubclassOf<class UShipSize> ForcedAIShipSize)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIShips.AIShipsBlueprintFunctionLibrary.RequestPassiveAIShipForPlayerShip"));

	Params::UAIShipsBlueprintFunctionLibrary_RequestPassiveAIShipForPlayerShip_Params Parms;
	Parms.WorldContext = WorldContext;
	Parms.PlayerShip = PlayerShip;
	Parms.ForcedAIShipSize = ForcedAIShipSize;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIShips.AIShipsBlueprintFunctionLibrary.RequestPassiveAIShipAtLocation
// (Final, BlueprintAuthorityOnly, Native, Static, Public, HasOutParams, HasDefaults, BlueprintCallable)
// Parameters:
// class UObject*                     WorldContext                                                     
// struct FVector                     Location                                                         
// class AActor*                      PlayerShip                                                       
// TSubclassOf<class UShipSize>       ForcedAIShipSize                                                 
// bool                               ReturnValue                                                      

bool UAIShipsBlueprintFunctionLibrary::RequestPassiveAIShipAtLocation(class UObject* WorldContext, struct FVector& Location, class AActor* PlayerShip, TSubclassOf<class UShipSize> ForcedAIShipSize)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIShips.AIShipsBlueprintFunctionLibrary.RequestPassiveAIShipAtLocation"));

	Params::UAIShipsBlueprintFunctionLibrary_RequestPassiveAIShipAtLocation_Params Parms;
	Parms.WorldContext = WorldContext;
	Parms.Location = Location;
	Parms.PlayerShip = PlayerShip;
	Parms.ForcedAIShipSize = ForcedAIShipSize;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIShips.AIShipsBlueprintFunctionLibrary.RequestAggressiveAIShipForPlayerShip
// (Final, BlueprintAuthorityOnly, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UObject*                     WorldContext                                                     
// class AActor*                      PlayerShip                                                       
// TSubclassOf<class UShipSize>       ForcedAIShipSize                                                 
// bool                               ReturnValue                                                      

bool UAIShipsBlueprintFunctionLibrary::RequestAggressiveAIShipForPlayerShip(class UObject* WorldContext, class AActor* PlayerShip, TSubclassOf<class UShipSize> ForcedAIShipSize)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIShips.AIShipsBlueprintFunctionLibrary.RequestAggressiveAIShipForPlayerShip"));

	Params::UAIShipsBlueprintFunctionLibrary_RequestAggressiveAIShipForPlayerShip_Params Parms;
	Parms.WorldContext = WorldContext;
	Parms.PlayerShip = PlayerShip;
	Parms.ForcedAIShipSize = ForcedAIShipSize;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIShips.AIShipsBlueprintFunctionLibrary.RequestAggressiveAIShipAtLocation
// (Final, BlueprintAuthorityOnly, Native, Static, Public, HasOutParams, HasDefaults, BlueprintCallable)
// Parameters:
// class UObject*                     WorldContext                                                     
// struct FVector                     Location                                                         
// class AActor*                      PlayerShip                                                       
// TSubclassOf<class UShipSize>       ForcedAIShipSize                                                 
// bool                               ReturnValue                                                      

bool UAIShipsBlueprintFunctionLibrary::RequestAggressiveAIShipAtLocation(class UObject* WorldContext, struct FVector& Location, class AActor* PlayerShip, TSubclassOf<class UShipSize> ForcedAIShipSize)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIShips.AIShipsBlueprintFunctionLibrary.RequestAggressiveAIShipAtLocation"));

	Params::UAIShipsBlueprintFunctionLibrary_RequestAggressiveAIShipAtLocation_Params Parms;
	Parms.WorldContext = WorldContext;
	Parms.Location = Location;
	Parms.PlayerShip = PlayerShip;
	Parms.ForcedAIShipSize = ForcedAIShipSize;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function AIShips.AthenaAIShipController.ApplyControllerParams
// (Native, Public, BlueprintCallable)
// Parameters:
// class UAthenaAIControllerParamsDataAsset*ParamsAsset                                                      
// class APawn*                       InPawn                                                           

void AAthenaAIShipController::ApplyControllerParams(class UAthenaAIControllerParamsDataAsset* ParamsAsset, class APawn* InPawn)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIShips.AthenaAIShipController.ApplyControllerParams"));

	Params::AAthenaAIShipController_ApplyControllerParams_Params Parms;
	Parms.ParamsAsset = ParamsAsset;
	Parms.InPawn = InPawn;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function AIShips.CursedCrewCustomisationInterface.SetCursedCrewCustomisationProperties
// (Native, Event, Public, HasOutParams, BlueprintEvent)
// Parameters:
// struct FAIShipSailData             SailData                                                         

void UCursedCrewCustomisationInterface::SetCursedCrewCustomisationProperties(struct FAIShipSailData& SailData)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AIShips.CursedCrewCustomisationInterface.SetCursedCrewCustomisationProperties"));

	Params::UCursedCrewCustomisationInterface_SetCursedCrewCustomisationProperties_Params Parms;
	Parms.SailData = SailData;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}

}


