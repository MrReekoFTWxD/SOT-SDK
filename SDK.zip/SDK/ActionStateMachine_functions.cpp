#include "pch.h"

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// FUNCTIONS
//---------------------------------------------------------------------------------------------------------------------


// Function ActionStateMachine.ActionStateMachineComponent.Server_RequestActionWithMessageForCurrentState
// (Net, NetReliable, Native, Event, Protected, NetServer, NetValidate)
// Parameters:
// struct FActionStateChangeRequestId InEpochId                                                        
// struct FActionStateChangeRequestId InRequestId                                                      
// struct FSerialisedActionStateInfo  InSerialisedActionStateConstructionInfo                          
// struct FSerialisedActionStateMessageInSerialisedPreviousStateMessage                                 

void UActionStateMachineComponent::Server_RequestActionWithMessageForCurrentState(const struct FActionStateChangeRequestId& InEpochId, const struct FActionStateChangeRequestId& InRequestId, struct FSerialisedActionStateInfo& InSerialisedActionStateConstructionInfo, struct FSerialisedActionStateMessage& InSerialisedPreviousStateMessage)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponent.Server_RequestActionWithMessageForCurrentState"));

	Params::UActionStateMachineComponent_Server_RequestActionWithMessageForCurrentState_Params Parms;
	Parms.InEpochId = InEpochId;
	Parms.InRequestId = InRequestId;
	Parms.InSerialisedActionStateConstructionInfo = InSerialisedActionStateConstructionInfo;
	Parms.InSerialisedPreviousStateMessage = InSerialisedPreviousStateMessage;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function ActionStateMachine.ActionStateMachineComponent.Server_RequestAction
// (Net, NetReliable, Native, Event, Protected, NetServer, NetValidate)
// Parameters:
// struct FActionStateChangeRequestId InEpochId                                                        
// struct FActionStateChangeRequestId InRequestId                                                      
// struct FSerialisedActionStateInfo  InSerialisedActionStateConstructionInfo                          
// enum class EActionPredictionType   ClientPredicted                                                  

void UActionStateMachineComponent::Server_RequestAction(const struct FActionStateChangeRequestId& InEpochId, const struct FActionStateChangeRequestId& InRequestId, struct FSerialisedActionStateInfo& InSerialisedActionStateConstructionInfo, enum class EActionPredictionType ClientPredicted)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponent.Server_RequestAction"));

	Params::UActionStateMachineComponent_Server_RequestAction_Params Parms;
	Parms.InEpochId = InEpochId;
	Parms.InRequestId = InRequestId;
	Parms.InSerialisedActionStateConstructionInfo = InSerialisedActionStateConstructionInfo;
	Parms.ClientPredicted = ClientPredicted;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function ActionStateMachine.ActionStateMachineComponent.PostNetInit
// (Final, Native, Public, BlueprintCallable)
// Parameters:

void UActionStateMachineComponent::PostNetInit()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponent.PostNetInit"));

	Params::UActionStateMachineComponent_PostNetInit_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function ActionStateMachine.ActionStateMachineComponent.OnNetOwnershipChanged
// (Final, Native, Protected)
// Parameters:

void UActionStateMachineComponent::OnNetOwnershipChanged()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponent.OnNetOwnershipChanged"));

	Params::UActionStateMachineComponent_OnNetOwnershipChanged_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function ActionStateMachine.ActionStateMachineComponent.Multicast_PushSerialisableData
// (Net, NetReliable, Native, Event, NetMulticast, Protected)
// Parameters:
// struct FActionStateChangeRequestId InEpochId                                                        
// struct FSerialisedActionStateInfo  InSerialisedActionStateSerialisationStateInfo                    

void UActionStateMachineComponent::Multicast_PushSerialisableData(const struct FActionStateChangeRequestId& InEpochId, struct FSerialisedActionStateInfo& InSerialisedActionStateSerialisationStateInfo)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponent.Multicast_PushSerialisableData"));

	Params::UActionStateMachineComponent_Multicast_PushSerialisableData_Params Parms;
	Parms.InEpochId = InEpochId;
	Parms.InSerialisedActionStateSerialisationStateInfo = InSerialisedActionStateSerialisationStateInfo;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function ActionStateMachine.ActionStateMachineComponent.Multicast_PushActionFromRequest
// (Net, NetReliable, Native, Event, NetMulticast, Protected)
// Parameters:
// struct FActionStateChangeRequestId InEpochId                                                        
// struct FSerialisedActionStateInfo  InSerialisedActionStateConstructionInfo                          

void UActionStateMachineComponent::Multicast_PushActionFromRequest(const struct FActionStateChangeRequestId& InEpochId, struct FSerialisedActionStateInfo& InSerialisedActionStateConstructionInfo)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponent.Multicast_PushActionFromRequest"));

	Params::UActionStateMachineComponent_Multicast_PushActionFromRequest_Params Parms;
	Parms.InEpochId = InEpochId;
	Parms.InSerialisedActionStateConstructionInfo = InSerialisedActionStateConstructionInfo;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function ActionStateMachine.ActionStateMachineComponent.Multicast_PushAction
// (Net, NetReliable, Native, Event, NetMulticast, Protected)
// Parameters:
// struct FActionStateChangeRequestId InEpochId                                                        
// struct FSerialisedActionStateInfo  InSerialisedActionStateConstructionInfo                          

void UActionStateMachineComponent::Multicast_PushAction(const struct FActionStateChangeRequestId& InEpochId, struct FSerialisedActionStateInfo& InSerialisedActionStateConstructionInfo)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponent.Multicast_PushAction"));

	Params::UActionStateMachineComponent_Multicast_PushAction_Params Parms;
	Parms.InEpochId = InEpochId;
	Parms.InSerialisedActionStateConstructionInfo = InSerialisedActionStateConstructionInfo;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function ActionStateMachine.ActionStateMachineComponent.End
// (Final, Native, Public, BlueprintCallable)
// Parameters:

void UActionStateMachineComponent::End()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponent.End"));

	Params::UActionStateMachineComponent_End_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function ActionStateMachine.ActionStateMachineComponent.Client_ResetStateMachine
// (Net, NetReliable, Native, Event, Protected, NetClient)
// Parameters:
// struct FResetStateMachineRpc       Rpc                                                              

void UActionStateMachineComponent::Client_ResetStateMachine(const struct FResetStateMachineRpc& Rpc)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponent.Client_ResetStateMachine"));

	Params::UActionStateMachineComponent_Client_ResetStateMachine_Params Parms;
	Parms.Rpc = Rpc;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function ActionStateMachine.ActionStateMachineComponent.Client_CorrectAction
// (Net, NetReliable, Native, Event, Protected, NetClient)
// Parameters:
// struct FActionStateChangeRequestId InEpochId                                                        
// struct FActionStateChangeRequestId InRequestId                                                      
// struct FSerialisedActionStateInfo  InSerialisedActionStateConstructionInfo                          

void UActionStateMachineComponent::Client_CorrectAction(const struct FActionStateChangeRequestId& InEpochId, const struct FActionStateChangeRequestId& InRequestId, struct FSerialisedActionStateInfo& InSerialisedActionStateConstructionInfo)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponent.Client_CorrectAction"));

	Params::UActionStateMachineComponent_Client_CorrectAction_Params Parms;
	Parms.InEpochId = InEpochId;
	Parms.InRequestId = InRequestId;
	Parms.InSerialisedActionStateConstructionInfo = InSerialisedActionStateConstructionInfo;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.SetTestStateValidatorThatAlwaysPassesExceptForId
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UActionStateMachineComponent*InComponent                                                      
// TSubclassOf<class UActionStateId>  StateId                                                          
// bool                               ReturnValue                                                      

bool UActionStateMachineComponentTestFunctions::SetTestStateValidatorThatAlwaysPassesExceptForId(class UActionStateMachineComponent* InComponent, TSubclassOf<class UActionStateId> StateId)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponentTestFunctions.SetTestStateValidatorThatAlwaysPassesExceptForId"));

	Params::UActionStateMachineComponentTestFunctions_SetTestStateValidatorThatAlwaysPassesExceptForId_Params Parms;
	Parms.InComponent = InComponent;
	Parms.StateId = StateId;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.SetTestStateValidatorThatAlwaysPasses
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UActionStateMachineComponent*InComponent                                                      
// bool                               ReturnValue                                                      

bool UActionStateMachineComponentTestFunctions::SetTestStateValidatorThatAlwaysPasses(class UActionStateMachineComponent* InComponent)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponentTestFunctions.SetTestStateValidatorThatAlwaysPasses"));

	Params::UActionStateMachineComponentTestFunctions_SetTestStateValidatorThatAlwaysPasses_Params Parms;
	Parms.InComponent = InComponent;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.SetTestStateValidatorThatAlwaysFails
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UActionStateMachineComponent*InComponent                                                      
// bool                               ReturnValue                                                      

bool UActionStateMachineComponentTestFunctions::SetTestStateValidatorThatAlwaysFails(class UActionStateMachineComponent* InComponent)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponentTestFunctions.SetTestStateValidatorThatAlwaysFails"));

	Params::UActionStateMachineComponentTestFunctions_SetTestStateValidatorThatAlwaysFails_Params Parms;
	Parms.InComponent = InComponent;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.SetTestStateFactoryChangeToNullOnUpdate
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UActionStateMachineComponent*InComponent                                                      
// bool                               ReturnValue                                                      

bool UActionStateMachineComponentTestFunctions::SetTestStateFactoryChangeToNullOnUpdate(class UActionStateMachineComponent* InComponent)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponentTestFunctions.SetTestStateFactoryChangeToNullOnUpdate"));

	Params::UActionStateMachineComponentTestFunctions_SetTestStateFactoryChangeToNullOnUpdate_Params Parms;
	Parms.InComponent = InComponent;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.SetTestStateFactory
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UActionStateMachineComponent*InComponent                                                      
// bool                               ReturnValue                                                      

bool UActionStateMachineComponentTestFunctions::SetTestStateFactory(class UActionStateMachineComponent* InComponent)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponentTestFunctions.SetTestStateFactory"));

	Params::UActionStateMachineComponentTestFunctions_SetTestStateFactory_Params Parms;
	Parms.InComponent = InComponent;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.SetCustomClientValidationTestStateFactory
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UActionStateMachineComponent*InComponent                                                      
// class UCustomClientValidityCheckCallback*InCallback                                                       
// bool                               ReturnValue                                                      

bool UActionStateMachineComponentTestFunctions::SetCustomClientValidationTestStateFactory(class UActionStateMachineComponent* InComponent, class UCustomClientValidityCheckCallback* InCallback)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponentTestFunctions.SetCustomClientValidationTestStateFactory"));

	Params::UActionStateMachineComponentTestFunctions_SetCustomClientValidationTestStateFactory_Params Parms;
	Parms.InComponent = InComponent;
	Parms.InCallback = InCallback;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.RequestUnpredictedTestActionStateWithIdOnTrack
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UActionStateMachineComponent*InComponent                                                      
// enum class EActionStateMachineTrackIdTrackId                                                          
// TSubclassOf<class UActionStateId>  ClientStateId                                                    
// TSubclassOf<class UActionStateId>  ServerStateId                                                    
// bool                               ReturnValue                                                      

bool UActionStateMachineComponentTestFunctions::RequestUnpredictedTestActionStateWithIdOnTrack(class UActionStateMachineComponent* InComponent, enum class EActionStateMachineTrackId TrackId, TSubclassOf<class UActionStateId> ClientStateId, TSubclassOf<class UActionStateId> ServerStateId)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponentTestFunctions.RequestUnpredictedTestActionStateWithIdOnTrack"));

	Params::UActionStateMachineComponentTestFunctions_RequestUnpredictedTestActionStateWithIdOnTrack_Params Parms;
	Parms.InComponent = InComponent;
	Parms.TrackId = TrackId;
	Parms.ClientStateId = ClientStateId;
	Parms.ServerStateId = ServerStateId;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.RequestTestActionStateWithIdOnTrack
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UActionStateMachineComponent*InComponent                                                      
// enum class EActionStateMachineTrackIdTrackId                                                          
// TSubclassOf<class UActionStateId>  StateId                                                          
// bool                               ReturnValue                                                      

bool UActionStateMachineComponentTestFunctions::RequestTestActionStateWithIdOnTrack(class UActionStateMachineComponent* InComponent, enum class EActionStateMachineTrackId TrackId, TSubclassOf<class UActionStateId> StateId)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponentTestFunctions.RequestTestActionStateWithIdOnTrack"));

	Params::UActionStateMachineComponentTestFunctions_RequestTestActionStateWithIdOnTrack_Params Parms;
	Parms.InComponent = InComponent;
	Parms.TrackId = TrackId;
	Parms.StateId = StateId;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.RequestNullActionStateOnTrack
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UActionStateMachineComponent*InComponent                                                      
// enum class EActionStateMachineTrackIdTrackId                                                          
// bool                               ReturnValue                                                      

bool UActionStateMachineComponentTestFunctions::RequestNullActionStateOnTrack(class UActionStateMachineComponent* InComponent, enum class EActionStateMachineTrackId TrackId)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponentTestFunctions.RequestNullActionStateOnTrack"));

	Params::UActionStateMachineComponentTestFunctions_RequestNullActionStateOnTrack_Params Parms;
	Parms.InComponent = InComponent;
	Parms.TrackId = TrackId;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.PushTestActionStateSerialisableDataOnTrack
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UActionStateMachineComponent*InComponent                                                      
// enum class EActionStateMachineTrackIdTrackId                                                          
// TSubclassOf<class UActionStateId>  StateId                                                          
// int32                              DataValue                                                        

void UActionStateMachineComponentTestFunctions::PushTestActionStateSerialisableDataOnTrack(class UActionStateMachineComponent* InComponent, enum class EActionStateMachineTrackId TrackId, TSubclassOf<class UActionStateId> StateId, int32 DataValue)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponentTestFunctions.PushTestActionStateSerialisableDataOnTrack"));

	Params::UActionStateMachineComponentTestFunctions_PushTestActionStateSerialisableDataOnTrack_Params Parms;
	Parms.InComponent = InComponent;
	Parms.TrackId = TrackId;
	Parms.StateId = StateId;
	Parms.DataValue = DataValue;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

}


// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.IsActionStateTypeActiveOnTrack
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class UActionStateMachineComponent*InComponent                                                      
// enum class EActionStateMachineTrackIdTrackId                                                          
// TSubclassOf<class UActionStateId>  StateId                                                          
// bool                               ReturnValue                                                      

bool UActionStateMachineComponentTestFunctions::IsActionStateTypeActiveOnTrack(class UActionStateMachineComponent* InComponent, enum class EActionStateMachineTrackId TrackId, TSubclassOf<class UActionStateId> StateId)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponentTestFunctions.IsActionStateTypeActiveOnTrack"));

	Params::UActionStateMachineComponentTestFunctions_IsActionStateTypeActiveOnTrack_Params Parms;
	Parms.InComponent = InComponent;
	Parms.TrackId = TrackId;
	Parms.StateId = StateId;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.GetTypeOfActionStateActiveOnTrack
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class UActionStateMachineComponent*InComponent                                                      
// enum class EActionStateMachineTrackIdTrackId                                                          
// TSubclassOf<class UActionStateId>  ReturnValue                                                      

TSubclassOf<class UActionStateId> UActionStateMachineComponentTestFunctions::GetTypeOfActionStateActiveOnTrack(class UActionStateMachineComponent* InComponent, enum class EActionStateMachineTrackId TrackId)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponentTestFunctions.GetTypeOfActionStateActiveOnTrack"));

	Params::UActionStateMachineComponentTestFunctions_GetTypeOfActionStateActiveOnTrack_Params Parms;
	Parms.InComponent = InComponent;
	Parms.TrackId = TrackId;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.GetTestActionStateSerialisableDataOnTrack
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable)
// Parameters:
// class UActionStateMachineComponent*InComponent                                                      
// enum class EActionStateMachineTrackIdTrackId                                                          
// struct FTestActionStateSerialisableDataData                                                             
// bool                               ReturnValue                                                      

bool UActionStateMachineComponentTestFunctions::GetTestActionStateSerialisableDataOnTrack(class UActionStateMachineComponent* InComponent, enum class EActionStateMachineTrackId TrackId, struct FTestActionStateSerialisableData* Data)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponentTestFunctions.GetTestActionStateSerialisableDataOnTrack"));

	Params::UActionStateMachineComponentTestFunctions_GetTestActionStateSerialisableDataOnTrack_Params Parms;
	Parms.InComponent = InComponent;
	Parms.TrackId = TrackId;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	if (Data != nullptr)
		*Data = Parms.Data;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.CreateCustomClientValidityCheckCallback
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UCustomClientValidityCheckCallback*ReturnValue                                                      

class UCustomClientValidityCheckCallback* UActionStateMachineComponentTestFunctions::CreateCustomClientValidityCheckCallback()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStateMachineComponentTestFunctions.CreateCustomClientValidityCheckCallback"));

	Params::UActionStateMachineComponentTestFunctions_CreateCustomClientValidityCheckCallback_Params Parms;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.ActionStatePriorityTableUtility.GetPriority
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FActionStatePriorityTable   PriorityTable                                                    
// TSubclassOf<class UActionStateId>  InStateA                                                         
// TSubclassOf<class UActionStateId>  InStateB                                                         
// enum class EActionStatePriority    ReturnValue                                                      

enum class EActionStatePriority UActionStatePriorityTableUtility::GetPriority(struct FActionStatePriorityTable& PriorityTable, TSubclassOf<class UActionStateId> InStateA, TSubclassOf<class UActionStateId> InStateB)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStatePriorityTableUtility.GetPriority"));

	Params::UActionStatePriorityTableUtility_GetPriority_Params Parms;
	Parms.PriorityTable = PriorityTable;
	Parms.InStateA = InStateA;
	Parms.InStateB = InStateB;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.ActionStatePriorityTableUtility.CreatePriorityTable
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class UActionStatePriorityTableData*Data                                                             
// struct FActionStatePriorityTable   ReturnValue                                                      

struct FActionStatePriorityTable UActionStatePriorityTableUtility::CreatePriorityTable(class UActionStatePriorityTableData* Data)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.ActionStatePriorityTableUtility.CreatePriorityTable"));

	Params::UActionStatePriorityTableUtility_CreatePriorityTable_Params Parms;
	Parms.Data = Data;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.IsValid
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FSerialisedActionStateInfo  TestStruct                                                       
// bool                               ReturnValue                                                      

bool USerialisedActionStateConstructionInfoTestFunctions::IsValid(struct FSerialisedActionStateInfo& TestStruct)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.IsValid"));

	Params::USerialisedActionStateConstructionInfoTestFunctions_IsValid_Params Parms;
	Parms.TestStruct = TestStruct;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.HasTestConstructionInfoWithInner
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FSerialisedActionStateInfo  TestStruct                                                       
// bool                               ReturnValue                                                      

bool USerialisedActionStateConstructionInfoTestFunctions::HasTestConstructionInfoWithInner(struct FSerialisedActionStateInfo& TestStruct)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.HasTestConstructionInfoWithInner"));

	Params::USerialisedActionStateConstructionInfoTestFunctions_HasTestConstructionInfoWithInner_Params Parms;
	Parms.TestStruct = TestStruct;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.HasTestConstructionInfo
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FSerialisedActionStateInfo  TestStruct                                                       
// bool                               ReturnValue                                                      

bool USerialisedActionStateConstructionInfoTestFunctions::HasTestConstructionInfo(struct FSerialisedActionStateInfo& TestStruct)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.HasTestConstructionInfo"));

	Params::USerialisedActionStateConstructionInfoTestFunctions_HasTestConstructionInfo_Params Parms;
	Parms.TestStruct = TestStruct;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.GetTestConstructionInfoWithInner
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FSerialisedActionStateInfo  TestStruct                                                       
// struct FTestActionStateConstructionInfoWithInnerReturnValue                                                      

struct FTestActionStateConstructionInfoWithInner USerialisedActionStateConstructionInfoTestFunctions::GetTestConstructionInfoWithInner(struct FSerialisedActionStateInfo& TestStruct)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.GetTestConstructionInfoWithInner"));

	Params::USerialisedActionStateConstructionInfoTestFunctions_GetTestConstructionInfoWithInner_Params Parms;
	Parms.TestStruct = TestStruct;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.GetTestConstructionInfo
// (Final, Native, Static, Public, HasOutParams, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FSerialisedActionStateInfo  TestStruct                                                       
// struct FTestActionStateConstructionInfoReturnValue                                                      

struct FTestActionStateConstructionInfo USerialisedActionStateConstructionInfoTestFunctions::GetTestConstructionInfo(struct FSerialisedActionStateInfo& TestStruct)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.GetTestConstructionInfo"));

	Params::USerialisedActionStateConstructionInfoTestFunctions_GetTestConstructionInfo_Params Parms;
	Parms.TestStruct = TestStruct;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.CreateTestSerialisableData
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// TSubclassOf<class UActionStateId>  Id                                                               
// int32                              IntProp                                                          
// struct FSerialisedActionStateInfo  ReturnValue                                                      

struct FSerialisedActionStateInfo USerialisedActionStateConstructionInfoTestFunctions::CreateTestSerialisableData(TSubclassOf<class UActionStateId> Id, int32 IntProp)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.CreateTestSerialisableData"));

	Params::USerialisedActionStateConstructionInfoTestFunctions_CreateTestSerialisableData_Params Parms;
	Parms.Id = Id;
	Parms.IntProp = IntProp;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.CreateTestConstructionInfoWithInner
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// TSubclassOf<class UActionStateId>  Id                                                               
// float                              FloatProp                                                        
// bool                               BoolProp                                                         
// class FString                      StringProp                                                       
// struct FSerialisedActionStateInfo  ReturnValue                                                      

struct FSerialisedActionStateInfo USerialisedActionStateConstructionInfoTestFunctions::CreateTestConstructionInfoWithInner(TSubclassOf<class UActionStateId> Id, float FloatProp, bool BoolProp, const class FString& StringProp)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.CreateTestConstructionInfoWithInner"));

	Params::USerialisedActionStateConstructionInfoTestFunctions_CreateTestConstructionInfoWithInner_Params Parms;
	Parms.Id = Id;
	Parms.FloatProp = FloatProp;
	Parms.BoolProp = BoolProp;
	Parms.StringProp = StringProp;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}


// Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.CreateTestConstructionInfo
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// TSubclassOf<class UActionStateId>  Id                                                               
// int32                              IntProp                                                          
// struct FSerialisedActionStateInfo  ReturnValue                                                      

struct FSerialisedActionStateInfo USerialisedActionStateConstructionInfoTestFunctions::CreateTestConstructionInfo(TSubclassOf<class UActionStateId> Id, int32 IntProp)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.CreateTestConstructionInfo"));

	Params::USerialisedActionStateConstructionInfoTestFunctions_CreateTestConstructionInfo_Params Parms;
	Parms.Id = Id;
	Parms.IntProp = IntProp;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}

}


