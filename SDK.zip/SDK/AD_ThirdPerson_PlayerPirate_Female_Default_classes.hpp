#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x700 (0x798 - 0x98)
// BlueprintGeneratedClass AD_ThirdPerson_PlayerPirate_Female_Default.AD_ThirdPerson_PlayerPirate_Female_Default_C
class UAD_ThirdPerson_PlayerPirate_Female_Default_C : public UAthenaAnimationThirdPersonAnimationData
{
public:
	struct FADS_IdlesNative                      Idles;                                             // 0x98(0x10)
	struct FADS_LocomotionNative                 Locomotion;                                        // 0xA8(0x50)
	struct FADS_LocomotionAlternateNative        LocomotionAlternate;                               // 0xF8(0x140)
	struct FADS_JumpingNative                    Jumping;                                           // 0x238(0x78)
	struct FADS_SwimmingNative                   Swimming;                                          // 0x2B0(0x68)
	struct FADS_WheelNative                      Wheel;                                             // 0x318(0x88)
	struct FADS_CapstanNative                    Capstan;                                           // 0x3A0(0x68)
	struct FADS_LadderNative                     Ladder;                                            // 0x408(0x68)
	struct FADS_ObjectsNative                    Items;                                             // 0x470(0x10)
	struct FADS_CannonNative                     Cannon;                                            // 0x480(0x38)
	struct FADS_HarpoonLauncherNative            HarpoonLauncher;                                   // 0x4B8(0x28)
	struct FADS_Sockets                          Sockets;                                           // 0x4E0(0x2)
	uint8                                        Pad_3B6B[0x6];                                     // Fixing Size After Last Property
	struct FADS_FacialNative                     Facial;                                            // 0x4E8(0x90)
	struct FADS_IKFootPlantingNative             IkFootPlanting;                                    // 0x578(0x1C)
	uint8                                        Pad_3B6C[0x4];                                     // Fixing Size After Last Property
	struct FADS_HitReactsNative                  HitReacts;                                         // 0x598(0x40)
	struct FADS_MapTableNative                   MapTable;                                          // 0x5D8(0x30)
	struct FADS_SpawnNative2                     Spawning;                                          // 0x608(0x10)
	struct FADS_CharacterSelectNative            CharacterSelect;                                   // 0x618(0x10)
	struct FADS_SkeletonFleeNative               SkeletonFlee;                                      // 0x628(0x10)
	struct FADS_InteractionNative                ShopInteraction;                                   // 0x638(0x10)
	struct FADS_SkeletonSensing                  SkeletonSensing;                                   // 0x648(0x10)
	struct FADS_SkeletonEmoteActions             SkeletonActionEmotes;                              // 0x658(0x10)
	struct FADS_RowingBoatNative                 Rowboat;                                           // 0x668(0x98)
	struct FADS_SkeletonCaptainNative            SkeletonShipCaptain;                               // 0x700(0x48)
	struct FADS_SkeletonCurseNative              SkeletonCurse;                                     // 0x748(0x28)
	struct FADS_WaterPumpNative                  WaterPump;                                         // 0x770(0x28)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AD_ThirdPerson_PlayerPirate_Female_Default_C"));
		return Clss;
	}

};

}


