#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x138 - 0x138)
// BlueprintGeneratedClass AIShipBattleGameEventOnDemand_MA_Proposal.AIShipBattleGameEventOnDemand_MA_Proposal_C
class UAIShipBattleGameEventOnDemand_MA_Proposal_C : public UGameEventOnDemandVoyageProposalDesc
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipBattleGameEventOnDemand_MA_Proposal_C"));
		return Clss;
	}

};

}


