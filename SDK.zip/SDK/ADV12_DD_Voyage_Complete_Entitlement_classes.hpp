#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xC8 - 0xC8)
// BlueprintGeneratedClass ADV12_DD_Voyage_Complete_Entitlement.ADV12_DD_Voyage_Complete_Entitlement_C
class UADV12_DD_Voyage_Complete_Entitlement_C : public UEntitlementDesc
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ADV12_DD_Voyage_Complete_Entitlement_C"));
		return Clss;
	}

};

}


