#pragma once


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x18 (0x18 - 0x0)
// Function AIModule.AIController.UseBlackboard
struct AAIController_UseBlackboard_Params
{
public:
	class UBlackboardData*                       BlackboardAsset;                                   // 0x0(0x8)
	class UBlackboardComponent*                  BlackboardComponent;                               // 0x8(0x8)
	bool                                         ReturnValue;                                       // 0x10(0x1)
	uint8                                        Pad_2C06[0x7];                                     // Fixing Size Of Struct
};

// 0x1 (0x1 - 0x0)
// Function AIModule.AIController.SetMoveBlockDetection
struct AAIController_SetMoveBlockDetection_Params
{
public:
	bool                                         bEnable;                                           // 0x0(0x1)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.AIController.RunBehaviorTree
struct AAIController_RunBehaviorTree_Params
{
public:
	class UBehaviorTree*                         BTAsset;                                           // 0x0(0x8)
	bool                                         ReturnValue;                                       // 0x8(0x1)
	uint8                                        Pad_2C07[0x7];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.AIController.OnUsingBlackBoard
struct AAIController_OnUsingBlackBoard_Params
{
public:
	class UBlackboardComponent*                  BlackboardComp;                                    // 0x0(0x8)
	class UBlackboardData*                       BlackboardAsset;                                   // 0x8(0x8)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.AIController.OnPossess
struct AAIController_OnPossess_Params
{
public:
	class APawn*                                 PossessedPawn;                                     // 0x0(0x8)
};

// 0x4 (0x4 - 0x0)
// Function AIModule.AIController.OnGameplayTaskResourcesClaimed
struct AAIController_OnGameplayTaskResourcesClaimed_Params
{
public:
	struct FGameplayResourceSet                  NewlyClaimed;                                      // 0x0(0x2)
	struct FGameplayResourceSet                  FreshlyReleased;                                   // 0x2(0x2)
};

// 0x28 (0x28 - 0x0)
// Function AIModule.AIController.MoveToLocation
struct AAIController_MoveToLocation_Params
{
public:
	struct FVector                               Dest;                                              // 0x0(0xC)
	float                                        AcceptanceRadius;                                  // 0xC(0x4)
	bool                                         bStopOnOverlap;                                    // 0x10(0x1)
	bool                                         bUsePathfinding;                                   // 0x11(0x1)
	bool                                         bProjectDestinationToNavigation;                   // 0x12(0x1)
	bool                                         bCanStrafe;                                        // 0x13(0x1)
	uint8                                        Pad_2C08[0x4];                                     // Fixing Size After Last Property
	TSubclassOf<class UNavigationQueryFilter>    FilterClass;                                       // 0x18(0x8)
	bool                                         bAllowPartialPath;                                 // 0x20(0x1)
	enum class EPathFollowingRequestResult       ReturnValue;                                       // 0x21(0x1)
	uint8                                        Pad_2C09[0x6];                                     // Fixing Size Of Struct
};

// 0x20 (0x20 - 0x0)
// Function AIModule.AIController.MoveToActor
struct AAIController_MoveToActor_Params
{
public:
	class AActor*                                Goal;                                              // 0x0(0x8)
	float                                        AcceptanceRadius;                                  // 0x8(0x4)
	bool                                         bStopOnOverlap;                                    // 0xC(0x1)
	bool                                         bUsePathfinding;                                   // 0xD(0x1)
	bool                                         bCanStrafe;                                        // 0xE(0x1)
	uint8                                        Pad_2C0A[0x1];                                     // Fixing Size After Last Property
	TSubclassOf<class UNavigationQueryFilter>    FilterClass;                                       // 0x10(0x8)
	bool                                         bAllowPartialPath;                                 // 0x18(0x1)
	enum class EPathFollowingRequestResult       ReturnValue;                                       // 0x19(0x1)
	uint8                                        Pad_2C0B[0x6];                                     // Fixing Size Of Struct
};

// 0x8 (0x8 - 0x0)
// Function AIModule.AIController.K2_SetFocus
struct AAIController_K2_SetFocus_Params
{
public:
	class AActor*                                NewFocus;                                          // 0x0(0x8)
};

// 0xC (0xC - 0x0)
// Function AIModule.AIController.K2_SetFocalPoint
struct AAIController_K2_SetFocalPoint_Params
{
public:
	struct FVector                               FP;                                                // 0x0(0xC)
};

// 0x0 (0x0 - 0x0)
// Function AIModule.AIController.K2_ClearFocus
struct AAIController_K2_ClearFocus_Params
{
public:
};

// 0x1 (0x1 - 0x0)
// Function AIModule.AIController.HasPartialPath
struct AAIController_HasPartialPath_Params
{
public:
	bool                                         ReturnValue;                                       // 0x0(0x1)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.AIController.GetPathFollowingComponent
struct AAIController_GetPathFollowingComponent_Params
{
public:
	class UPathFollowingComponent*               ReturnValue;                                       // 0x0(0x8)
};

// 0x1 (0x1 - 0x0)
// Function AIModule.AIController.GetMoveStatus
struct AAIController_GetMoveStatus_Params
{
public:
	enum class EPathFollowingStatus              ReturnValue;                                       // 0x0(0x1)
};

// 0xC (0xC - 0x0)
// Function AIModule.AIController.GetImmediateMoveDestination
struct AAIController_GetImmediateMoveDestination_Params
{
public:
	struct FVector                               ReturnValue;                                       // 0x0(0xC)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.AIController.GetFocusActor
struct AAIController_GetFocusActor_Params
{
public:
	class AActor*                                ReturnValue;                                       // 0x0(0x8)
};

// 0x18 (0x18 - 0x0)
// Function AIModule.AIController.GetFocalPointOnActor
struct AAIController_GetFocalPointOnActor_Params
{
public:
	class AActor*                                Actor;                                             // 0x0(0x8)
	struct FVector                               ReturnValue;                                       // 0x8(0xC)
	uint8                                        Pad_2C0C[0x4];                                     // Fixing Size Of Struct
};

// 0xC (0xC - 0x0)
// Function AIModule.AIController.GetFocalPoint
struct AAIController_GetFocalPoint_Params
{
public:
	struct FVector                               ReturnValue;                                       // 0x0(0xC)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.AIController.GetAIPerceptionComponent
struct AAIController_GetAIPerceptionComponent_Params
{
public:
	class UAIPerceptionComponent*                ReturnValue;                                       // 0x0(0x8)
};

// 0xA0 (0xA0 - 0x0)
// Function AIModule.PathFollowingComponent.OnActorBump
struct UPathFollowingComponent_OnActorBump_Params
{
public:
	class AActor*                                SelfActor;                                         // 0x0(0x8)
	class AActor*                                OtherActor;                                        // 0x8(0x8)
	struct FVector                               NormalImpulse;                                     // 0x10(0xC)
	struct FHitResult                            Hit;                                               // 0x1C(0x80)
	uint8                                        Pad_2C11[0x4];                                     // Fixing Size Of Struct
};

// 0xC (0xC - 0x0)
// Function AIModule.PathFollowingComponent.GetPathDestination
struct UPathFollowingComponent_GetPathDestination_Params
{
public:
	struct FVector                               ReturnValue;                                       // 0x0(0xC)
};

// 0x1 (0x1 - 0x0)
// Function AIModule.PathFollowingComponent.GetPathActionType
struct UPathFollowingComponent_GetPathActionType_Params
{
public:
	enum class EPathFollowingAction              ReturnValue;                                       // 0x0(0x1)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.AIAsyncTaskBlueprintProxy.OnMoveCompleted
struct UAIAsyncTaskBlueprintProxy_OnMoveCompleted_Params
{
public:
	struct FAIRequestID                          RequestID;                                         // 0x0(0x4)
	enum class EPathFollowingResult              MovementResult;                                    // 0x4(0x1)
	uint8                                        Pad_2C16[0x3];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.AIBlueprintHelperLibrary.UnlockAIResourcesWithAnimation
struct UAIBlueprintHelperLibrary_UnlockAIResourcesWithAnimation_Params
{
public:
	class UAnimInstance*                         AnimInstance;                                      // 0x0(0x8)
	bool                                         bUnlockMovement;                                   // 0x8(0x1)
	bool                                         UnlockAILogic;                                     // 0x9(0x1)
	uint8                                        Pad_2C18[0x6];                                     // Fixing Size Of Struct
};

// 0x40 (0x40 - 0x0)
// Function AIModule.AIBlueprintHelperLibrary.SpawnAIFromClass
struct UAIBlueprintHelperLibrary_SpawnAIFromClass_Params
{
public:
	class UObject*                               WorldContextObject;                                // 0x0(0x8)
	TSubclassOf<class APawn>                     PawnClass;                                         // 0x8(0x8)
	class UBehaviorTree*                         BehaviorTree;                                      // 0x10(0x8)
	struct FVector                               Location;                                          // 0x18(0xC)
	struct FRotator                              Rotation;                                          // 0x24(0xC)
	bool                                         bNoCollisionFail;                                  // 0x30(0x1)
	uint8                                        Pad_2C19[0x7];                                     // Fixing Size After Last Property
	class APawn*                                 ReturnValue;                                       // 0x38(0x8)
};

// 0x20 (0x20 - 0x0)
// Function AIModule.AIBlueprintHelperLibrary.SendAIMessage
struct UAIBlueprintHelperLibrary_SendAIMessage_Params
{
public:
	class APawn*                                 Target;                                            // 0x0(0x8)
	class FName                                  Message;                                           // 0x8(0x8)
	class UObject*                               MessageSource;                                     // 0x10(0x8)
	bool                                         bSuccess;                                          // 0x18(0x1)
	uint8                                        Pad_2C1A[0x7];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.AIBlueprintHelperLibrary.LockAIResourcesWithAnimation
struct UAIBlueprintHelperLibrary_LockAIResourcesWithAnimation_Params
{
public:
	class UAnimInstance*                         AnimInstance;                                      // 0x0(0x8)
	bool                                         bLockMovement;                                     // 0x8(0x1)
	bool                                         LockAILogic;                                       // 0x9(0x1)
	uint8                                        Pad_2C1B[0x6];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.AIBlueprintHelperLibrary.IsValidAIRotation
struct UAIBlueprintHelperLibrary_IsValidAIRotation_Params
{
public:
	struct FRotator                              Rotation;                                          // 0x0(0xC)
	bool                                         ReturnValue;                                       // 0xC(0x1)
	uint8                                        Pad_2C1C[0x3];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.AIBlueprintHelperLibrary.IsValidAILocation
struct UAIBlueprintHelperLibrary_IsValidAILocation_Params
{
public:
	struct FVector                               Location;                                          // 0x0(0xC)
	bool                                         ReturnValue;                                       // 0xC(0x1)
	uint8                                        Pad_2C1D[0x3];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.AIBlueprintHelperLibrary.IsValidAIDirection
struct UAIBlueprintHelperLibrary_IsValidAIDirection_Params
{
public:
	struct FVector                               DirectionVector;                                   // 0x0(0xC)
	bool                                         ReturnValue;                                       // 0xC(0x1)
	uint8                                        Pad_2C1E[0x3];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.AIBlueprintHelperLibrary.GetBlackboard
struct UAIBlueprintHelperLibrary_GetBlackboard_Params
{
public:
	class AActor*                                Target;                                            // 0x0(0x8)
	class UBlackboardComponent*                  ReturnValue;                                       // 0x8(0x8)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.AIBlueprintHelperLibrary.GetAIController
struct UAIBlueprintHelperLibrary_GetAIController_Params
{
public:
	class AActor*                                ControlledActor;                                   // 0x0(0x8)
	class AAIController*                         ReturnValue;                                       // 0x8(0x8)
};

// 0x38 (0x38 - 0x0)
// Function AIModule.AIBlueprintHelperLibrary.CreateMoveToProxyObject
struct UAIBlueprintHelperLibrary_CreateMoveToProxyObject_Params
{
public:
	class UObject*                               WorldContextObject;                                // 0x0(0x8)
	class APawn*                                 Pawn;                                              // 0x8(0x8)
	struct FVector                               Destination;                                       // 0x10(0xC)
	uint8                                        Pad_2C1F[0x4];                                     // Fixing Size After Last Property
	class AActor*                                TargetActor;                                       // 0x20(0x8)
	float                                        AcceptanceRadius;                                  // 0x28(0x4)
	bool                                         bStopOnOverlap;                                    // 0x2C(0x1)
	uint8                                        Pad_2C20[0x3];                                     // Fixing Size After Last Property
	class UAIAsyncTaskBlueprintProxy*            ReturnValue;                                       // 0x30(0x8)
};

// 0x20 (0x20 - 0x0)
// Function AIModule.PawnActionsComponent.K2_PushAction
struct UPawnActionsComponent_K2_PushAction_Params
{
public:
	class UPawnAction*                           NewAction;                                         // 0x0(0x8)
	enum class EAIRequestPriority                Priority;                                          // 0x8(0x1)
	uint8                                        Pad_2C21[0x7];                                     // Fixing Size After Last Property
	class UObject*                               Instigator;                                        // 0x10(0x8)
	bool                                         ReturnValue;                                       // 0x18(0x1)
	uint8                                        Pad_2C22[0x7];                                     // Fixing Size Of Struct
};

// 0x18 (0x18 - 0x0)
// Function AIModule.PawnActionsComponent.K2_PerformAction
struct UPawnActionsComponent_K2_PerformAction_Params
{
public:
	class APawn*                                 Pawn;                                              // 0x0(0x8)
	class UPawnAction*                           Action;                                            // 0x8(0x8)
	enum class EAIRequestPriority                Priority;                                          // 0x10(0x1)
	bool                                         ReturnValue;                                       // 0x11(0x1)
	uint8                                        Pad_2C23[0x6];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.PawnActionsComponent.K2_ForceAbortAction
struct UPawnActionsComponent_K2_ForceAbortAction_Params
{
public:
	class UPawnAction*                           ActionToAbort;                                     // 0x0(0x8)
	enum class EPawnActionAbortState             ReturnValue;                                       // 0x8(0x1)
	uint8                                        Pad_2C24[0x7];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.PawnActionsComponent.K2_AbortAction
struct UPawnActionsComponent_K2_AbortAction_Params
{
public:
	class UPawnAction*                           ActionToAbort;                                     // 0x0(0x8)
	enum class EPawnActionAbortState             ReturnValue;                                       // 0x8(0x1)
	uint8                                        Pad_2C25[0x7];                                     // Fixing Size Of Struct
};

// 0x0 (0x0 - 0x0)
// Function AIModule.AISystem.AILoggingVerbose
struct UAISystem_AILoggingVerbose_Params
{
public:
};

// 0x0 (0x0 - 0x0)
// Function AIModule.AISystem.AIIgnorePlayers
struct UAISystem_AIIgnorePlayers_Params
{
public:
};

// 0x10 (0x10 - 0x0)
// Function AIModule.AIPerceptionSystem.ReportPerceptionEvent
struct UAIPerceptionSystem_ReportPerceptionEvent_Params
{
public:
	class UObject*                               WorldContext;                                      // 0x0(0x8)
	class UAISenseEvent*                         PerceptionEvent;                                   // 0x8(0x8)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.AIPerceptionSystem.ReportEvent
struct UAIPerceptionSystem_ReportEvent_Params
{
public:
	class UAISenseEvent*                         PerceptionEvent;                                   // 0x0(0x8)
};

// 0x20 (0x20 - 0x0)
// Function AIModule.AIPerceptionSystem.RegisterPerceptionStimuliSource
struct UAIPerceptionSystem_RegisterPerceptionStimuliSource_Params
{
public:
	class UObject*                               WorldContext;                                      // 0x0(0x8)
	TSubclassOf<class UAISense>                  Sense;                                             // 0x8(0x8)
	class AActor*                                Target;                                            // 0x10(0x8)
	bool                                         ReturnValue;                                       // 0x18(0x1)
	uint8                                        Pad_2C2F[0x7];                                     // Fixing Size Of Struct
};

// 0x1 (0x1 - 0x0)
// Function AIModule.AIPerceptionSystem.OnPerceptionStimuliSourceEndPlay
struct UAIPerceptionSystem_OnPerceptionStimuliSourceEndPlay_Params
{
public:
	enum class EEndPlayReason                    EndPlayReason;                                     // 0x0(0x1)
};

// 0x50 (0x50 - 0x0)
// Function AIModule.AIPerceptionSystem.GetSenseClassForStimulus
struct UAIPerceptionSystem_GetSenseClassForStimulus_Params
{
public:
	class UObject*                               WorldContext;                                      // 0x0(0x8)
	struct FAIStimulus                           Stimulus;                                          // 0x8(0x3C)
	uint8                                        Pad_2C30[0x4];                                     // Fixing Size After Last Property
	TSubclassOf<class UAISense>                  ReturnValue;                                       // 0x48(0x8)
};

// 0x0 (0x0 - 0x0)
// Function AIModule.AIPerceptionComponent.RequestStimuliListenerUpdate
struct UAIPerceptionComponent_RequestStimuliListenerUpdate_Params
{
public:
};

// 0x1 (0x1 - 0x0)
// Function AIModule.AIPerceptionComponent.OnOwnerEndPlay
struct UAIPerceptionComponent_OnOwnerEndPlay_Params
{
public:
	enum class EEndPlayReason                    EndPlayReason;                                     // 0x0(0x1)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.AIPerceptionComponent.IsIgnored
struct UAIPerceptionComponent_IsIgnored_Params
{
public:
	class AActor*                                Actor;                                             // 0x0(0x8)
	bool                                         ReturnValue;                                       // 0x8(0x1)
	uint8                                        Pad_2C33[0x7];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.AIPerceptionComponent.GetPerceivedHostileActors
struct UAIPerceptionComponent_GetPerceivedHostileActors_Params
{
public:
	TArray<class AActor*>                        OutActors;                                         // 0x0(0x10)
};

// 0x18 (0x18 - 0x0)
// Function AIModule.AIPerceptionComponent.GetPerceivedActors
struct UAIPerceptionComponent_GetPerceivedActors_Params
{
public:
	TSubclassOf<class UAISense>                  SenseToUse;                                        // 0x0(0x8)
	TArray<class AActor*>                        OutActors;                                         // 0x8(0x10)
};

// 0x30 (0x30 - 0x0)
// Function AIModule.AIPerceptionComponent.GetActorsPerception
struct UAIPerceptionComponent_GetActorsPerception_Params
{
public:
	class AActor*                                Actor;                                             // 0x0(0x8)
	struct FActorPerceptionBlueprintInfo         Info;                                              // 0x8(0x20)
	bool                                         ReturnValue;                                       // 0x28(0x1)
	uint8                                        Pad_2C34[0x7];                                     // Fixing Size Of Struct
};

// 0x8 (0x8 - 0x0)
// Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromSense
struct UAIPerceptionStimuliSourceComponent_UnregisterFromSense_Params
{
public:
	TSubclassOf<class UAISense>                  SenseClass;                                        // 0x0(0x8)
};

// 0x0 (0x0 - 0x0)
// Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromPerceptionSystem
struct UAIPerceptionStimuliSourceComponent_UnregisterFromPerceptionSystem_Params
{
public:
};

// 0x0 (0x0 - 0x0)
// Function AIModule.AIPerceptionStimuliSourceComponent.RegisterWithPerceptionSystem
struct UAIPerceptionStimuliSourceComponent_RegisterWithPerceptionSystem_Params
{
public:
};

// 0x8 (0x8 - 0x0)
// Function AIModule.AIPerceptionStimuliSourceComponent.RegisterForSense
struct UAIPerceptionStimuliSourceComponent_RegisterForSense_Params
{
public:
	TSubclassOf<class UAISense>                  SenseClass;                                        // 0x0(0x8)
};

// 0x18 (0x18 - 0x0)
// Function AIModule.AISense_Blueprint.OnUpdate
struct UAISense_Blueprint_OnUpdate_Params
{
public:
	TArray<class UAISenseEvent*>                 EventsToProcess;                                   // 0x0(0x10)
	float                                        ReturnValue;                                       // 0x10(0x4)
	uint8                                        Pad_2C3A[0x4];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.AISense_Blueprint.OnListenerUpdated
struct UAISense_Blueprint_OnListenerUpdated_Params
{
public:
	class AActor*                                ActorListener;                                     // 0x0(0x8)
	class UAIPerceptionComponent*                PerceptionComponent;                               // 0x8(0x8)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.AISense_Blueprint.OnListenerUnregistered
struct UAISense_Blueprint_OnListenerUnregistered_Params
{
public:
	class AActor*                                ActorListener;                                     // 0x0(0x8)
	class UAIPerceptionComponent*                PerceptionComponent;                               // 0x8(0x8)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.AISense_Blueprint.OnListenerRegistered
struct UAISense_Blueprint_OnListenerRegistered_Params
{
public:
	class AActor*                                ActorListener;                                     // 0x0(0x8)
	class UAIPerceptionComponent*                PerceptionComponent;                               // 0x8(0x8)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.AISense_Blueprint.K2_OnNewPawn
struct UAISense_Blueprint_K2_OnNewPawn_Params
{
public:
	class APawn*                                 NewPawn;                                           // 0x0(0x8)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.AISense_Blueprint.GetAllListenerComponents
struct UAISense_Blueprint_GetAllListenerComponents_Params
{
public:
	TArray<class UAIPerceptionComponent*>        ListenerComponents;                                // 0x0(0x10)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.AISense_Blueprint.GetAllListenerActors
struct UAISense_Blueprint_GetAllListenerActors_Params
{
public:
	TArray<class AActor*>                        ListenerActors;                                    // 0x0(0x10)
};

// 0x38 (0x38 - 0x0)
// Function AIModule.AISense_Damage.ReportDamageEvent
struct UAISense_Damage_ReportDamageEvent_Params
{
public:
	class UObject*                               WorldContext;                                      // 0x0(0x8)
	class AActor*                                DamagedActor;                                      // 0x8(0x8)
	class AActor*                                Instigator;                                        // 0x10(0x8)
	float                                        DamageAmount;                                      // 0x18(0x4)
	struct FVector                               EventLocation;                                     // 0x1C(0xC)
	struct FVector                               HitLocation;                                       // 0x28(0xC)
	uint8                                        Pad_2C3B[0x4];                                     // Fixing Size Of Struct
};

// 0x30 (0x30 - 0x0)
// Function AIModule.AISense_Hearing.ReportNoiseEvent
struct UAISense_Hearing_ReportNoiseEvent_Params
{
public:
	class UObject*                               WorldContext;                                      // 0x0(0x8)
	struct FVector                               NoiseLocation;                                     // 0x8(0xC)
	float                                        Loudness;                                          // 0x14(0x4)
	class AActor*                                Instigator;                                        // 0x18(0x8)
	float                                        MaxRange;                                          // 0x20(0x4)
	class FName                                  Tag;                                               // 0x24(0x8)
	uint8                                        Pad_2C3C[0x4];                                     // Fixing Size Of Struct
};

// 0x18 (0x18 - 0x0)
// Function AIModule.AISense_Prediction.RequestPawnPredictionEvent
struct UAISense_Prediction_RequestPawnPredictionEvent_Params
{
public:
	class APawn*                                 Requestor;                                         // 0x0(0x8)
	class AActor*                                PredictedActor;                                    // 0x8(0x8)
	float                                        PredictionTime;                                    // 0x10(0x4)
	uint8                                        Pad_2C40[0x4];                                     // Fixing Size Of Struct
};

// 0x18 (0x18 - 0x0)
// Function AIModule.AISense_Prediction.RequestControllerPredictionEvent
struct UAISense_Prediction_RequestControllerPredictionEvent_Params
{
public:
	class AAIController*                         Requestor;                                         // 0x0(0x8)
	class AActor*                                PredictedActor;                                    // 0x8(0x8)
	float                                        PredictionTime;                                    // 0x10(0x4)
	uint8                                        Pad_2C41[0x4];                                     // Fixing Size Of Struct
};

// 0x30 (0x30 - 0x0)
// Function AIModule.AITask_MoveTo.AIMoveTo
struct UAITask_MoveTo_AIMoveTo_Params
{
public:
	class AAIController*                         Controller;                                        // 0x0(0x8)
	struct FVector                               GoalLocation;                                      // 0x8(0xC)
	uint8                                        Pad_2C48[0x4];                                     // Fixing Size After Last Property
	class AActor*                                GoalActor;                                         // 0x18(0x8)
	float                                        AcceptanceRadius;                                  // 0x20(0x4)
	enum class EAIOptionFlag                     StopOnOverlap;                                     // 0x24(0x1)
	enum class EAIOptionFlag                     AcceptPartialPath;                                 // 0x25(0x1)
	bool                                         bUsePathfinding;                                   // 0x26(0x1)
	bool                                         bLockAILogic;                                      // 0x27(0x1)
	class UAITask_MoveTo*                        ReturnValue;                                       // 0x28(0x8)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BrainComponent.StopLogic
struct UBrainComponent_StopLogic_Params
{
public:
	class FString                                Reason;                                            // 0x0(0x10)
};

// 0x0 (0x0 - 0x0)
// Function AIModule.BrainComponent.RestartLogic
struct UBrainComponent_RestartLogic_Params
{
public:
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BehaviorTreeComponent.SetDynamicSubtree
struct UBehaviorTreeComponent_SetDynamicSubtree_Params
{
public:
	struct FGameplayTag                          InjectTag;                                         // 0x0(0x8)
	class UBehaviorTree*                         BehaviorAsset;                                     // 0x8(0x8)
};

// 0xC (0xC - 0x0)
// Function AIModule.BehaviorTreeComponent.GetTagCooldownEndTime
struct UBehaviorTreeComponent_GetTagCooldownEndTime_Params
{
public:
	struct FGameplayTag                          CooldownTag;                                       // 0x0(0x8)
	float                                        ReturnValue;                                       // 0x8(0x4)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BehaviorTreeComponent.AddCooldownTagDuration
struct UBehaviorTreeComponent_AddCooldownTagDuration_Params
{
public:
	struct FGameplayTag                          CooldownTag;                                       // 0x0(0x8)
	float                                        CoolDownDuration;                                  // 0x8(0x4)
	bool                                         bAddToExistingDuration;                            // 0xC(0x1)
	uint8                                        Pad_2C4D[0x3];                                     // Fixing Size Of Struct
};

// 0x14 (0x14 - 0x0)
// Function AIModule.BlackboardComponent.SetValueAsVector
struct UBlackboardComponent_SetValueAsVector_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	struct FVector                               VectorValue;                                       // 0x8(0xC)
};

// 0x18 (0x18 - 0x0)
// Function AIModule.BlackboardComponent.SetValueAsString
struct UBlackboardComponent_SetValueAsString_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	class FString                                StringValue;                                       // 0x8(0x10)
};

// 0x14 (0x14 - 0x0)
// Function AIModule.BlackboardComponent.SetValueAsRotator
struct UBlackboardComponent_SetValueAsRotator_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	struct FRotator                              VectorValue;                                       // 0x8(0xC)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BlackboardComponent.SetValueAsObject
struct UBlackboardComponent_SetValueAsObject_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	class UObject*                               ObjectValue;                                       // 0x8(0x8)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BlackboardComponent.SetValueAsName
struct UBlackboardComponent_SetValueAsName_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	class FName                                  NameValue;                                         // 0x8(0x8)
};

// 0xC (0xC - 0x0)
// Function AIModule.BlackboardComponent.SetValueAsInt
struct UBlackboardComponent_SetValueAsInt_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	int32                                        IntValue;                                          // 0x8(0x4)
};

// 0xC (0xC - 0x0)
// Function AIModule.BlackboardComponent.SetValueAsFloat
struct UBlackboardComponent_SetValueAsFloat_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	float                                        FloatValue;                                        // 0x8(0x4)
};

// 0xC (0xC - 0x0)
// Function AIModule.BlackboardComponent.SetValueAsEnum
struct UBlackboardComponent_SetValueAsEnum_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	uint8                                        EnumValue;                                         // 0x8(0x1)
	uint8                                        Pad_2C55[0x3];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BlackboardComponent.SetValueAsClass
struct UBlackboardComponent_SetValueAsClass_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	class UClass*                                ClassValue;                                        // 0x8(0x8)
};

// 0xC (0xC - 0x0)
// Function AIModule.BlackboardComponent.SetValueAsBool
struct UBlackboardComponent_SetValueAsBool_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	bool                                         BoolValue;                                         // 0x8(0x1)
	uint8                                        Pad_2C56[0x3];                                     // Fixing Size Of Struct
};

// 0xC (0xC - 0x0)
// Function AIModule.BlackboardComponent.IsVectorValueSet
struct UBlackboardComponent_IsVectorValueSet_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	bool                                         ReturnValue;                                       // 0x8(0x1)
	uint8                                        Pad_2C57[0x3];                                     // Fixing Size Of Struct
};

// 0x14 (0x14 - 0x0)
// Function AIModule.BlackboardComponent.GetValueAsVector
struct UBlackboardComponent_GetValueAsVector_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	struct FVector                               ReturnValue;                                       // 0x8(0xC)
};

// 0x18 (0x18 - 0x0)
// Function AIModule.BlackboardComponent.GetValueAsString
struct UBlackboardComponent_GetValueAsString_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	class FString                                ReturnValue;                                       // 0x8(0x10)
};

// 0x14 (0x14 - 0x0)
// Function AIModule.BlackboardComponent.GetValueAsRotator
struct UBlackboardComponent_GetValueAsRotator_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	struct FRotator                              ReturnValue;                                       // 0x8(0xC)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BlackboardComponent.GetValueAsObject
struct UBlackboardComponent_GetValueAsObject_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	class UObject*                               ReturnValue;                                       // 0x8(0x8)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BlackboardComponent.GetValueAsName
struct UBlackboardComponent_GetValueAsName_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	class FName                                  ReturnValue;                                       // 0x8(0x8)
};

// 0xC (0xC - 0x0)
// Function AIModule.BlackboardComponent.GetValueAsInt
struct UBlackboardComponent_GetValueAsInt_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	int32                                        ReturnValue;                                       // 0x8(0x4)
};

// 0xC (0xC - 0x0)
// Function AIModule.BlackboardComponent.GetValueAsFloat
struct UBlackboardComponent_GetValueAsFloat_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	float                                        ReturnValue;                                       // 0x8(0x4)
};

// 0xC (0xC - 0x0)
// Function AIModule.BlackboardComponent.GetValueAsEnum
struct UBlackboardComponent_GetValueAsEnum_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	uint8                                        ReturnValue;                                       // 0x8(0x1)
	uint8                                        Pad_2C58[0x3];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BlackboardComponent.GetValueAsClass
struct UBlackboardComponent_GetValueAsClass_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	class UClass*                                ReturnValue;                                       // 0x8(0x8)
};

// 0xC (0xC - 0x0)
// Function AIModule.BlackboardComponent.GetValueAsBool
struct UBlackboardComponent_GetValueAsBool_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	bool                                         ReturnValue;                                       // 0x8(0x1)
	uint8                                        Pad_2C59[0x3];                                     // Fixing Size Of Struct
};

// 0x18 (0x18 - 0x0)
// Function AIModule.BlackboardComponent.GetRotationFromEntry
struct UBlackboardComponent_GetRotationFromEntry_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	struct FRotator                              ResultRotation;                                    // 0x8(0xC)
	bool                                         ReturnValue;                                       // 0x14(0x1)
	uint8                                        Pad_2C5A[0x3];                                     // Fixing Size Of Struct
};

// 0x18 (0x18 - 0x0)
// Function AIModule.BlackboardComponent.GetLocationFromEntry
struct UBlackboardComponent_GetLocationFromEntry_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
	struct FVector                               ResultLocation;                                    // 0x8(0xC)
	bool                                         ReturnValue;                                       // 0x14(0x1)
	uint8                                        Pad_2C5B[0x3];                                     // Fixing Size Of Struct
};

// 0x8 (0x8 - 0x0)
// Function AIModule.BlackboardComponent.ClearValueAsVector
struct UBlackboardComponent_ClearValueAsVector_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.BlackboardComponent.ClearValueAsRotator
struct UBlackboardComponent_ClearValueAsRotator_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.BlackboardComponent.ClearValue
struct UBlackboardComponent_ClearValue_Params
{
public:
	class FName                                  KeyName;                                           // 0x0(0x8)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.BTFunctionLibrary.StopUsingExternalEvent
struct UBTFunctionLibrary_StopUsingExternalEvent_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BTFunctionLibrary.StartUsingExternalEvent
struct UBTFunctionLibrary_StartUsingExternalEvent_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	class AActor*                                OwningActor;                                       // 0x8(0x8)
};

// 0x40 (0x40 - 0x0)
// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsVector
struct UBTFunctionLibrary_SetBlackboardValueAsVector_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	struct FVector                               Value;                                             // 0x30(0xC)
	uint8                                        Pad_2C5E[0x4];                                     // Fixing Size Of Struct
};

// 0x40 (0x40 - 0x0)
// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsString
struct UBTFunctionLibrary_SetBlackboardValueAsString_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	class FString                                Value;                                             // 0x30(0x10)
};

// 0x40 (0x40 - 0x0)
// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsRotator
struct UBTFunctionLibrary_SetBlackboardValueAsRotator_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	struct FRotator                              Value;                                             // 0x30(0xC)
	uint8                                        Pad_2C5F[0x4];                                     // Fixing Size Of Struct
};

// 0x38 (0x38 - 0x0)
// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsObject
struct UBTFunctionLibrary_SetBlackboardValueAsObject_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	class UObject*                               Value;                                             // 0x30(0x8)
};

// 0x38 (0x38 - 0x0)
// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsName
struct UBTFunctionLibrary_SetBlackboardValueAsName_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	class FName                                  Value;                                             // 0x30(0x8)
};

// 0x38 (0x38 - 0x0)
// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsInt
struct UBTFunctionLibrary_SetBlackboardValueAsInt_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	int32                                        Value;                                             // 0x30(0x4)
	uint8                                        Pad_2C60[0x4];                                     // Fixing Size Of Struct
};

// 0x38 (0x38 - 0x0)
// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsFloat
struct UBTFunctionLibrary_SetBlackboardValueAsFloat_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	float                                        Value;                                             // 0x30(0x4)
	uint8                                        Pad_2C61[0x4];                                     // Fixing Size Of Struct
};

// 0x38 (0x38 - 0x0)
// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsEnum
struct UBTFunctionLibrary_SetBlackboardValueAsEnum_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	uint8                                        Value;                                             // 0x30(0x1)
	uint8                                        Pad_2C62[0x7];                                     // Fixing Size Of Struct
};

// 0x38 (0x38 - 0x0)
// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsClass
struct UBTFunctionLibrary_SetBlackboardValueAsClass_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	class UClass*                                Value;                                             // 0x30(0x8)
};

// 0x38 (0x38 - 0x0)
// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsBool
struct UBTFunctionLibrary_SetBlackboardValueAsBool_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	bool                                         Value;                                             // 0x30(0x1)
	uint8                                        Pad_2C63[0x7];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BTFunctionLibrary.GetOwnersBlackboard
struct UBTFunctionLibrary_GetOwnersBlackboard_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	class UBlackboardComponent*                  ReturnValue;                                       // 0x8(0x8)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BTFunctionLibrary.GetOwnerComponent
struct UBTFunctionLibrary_GetOwnerComponent_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	class UBehaviorTreeComponent*                ReturnValue;                                       // 0x8(0x8)
};

// 0x40 (0x40 - 0x0)
// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsVector
struct UBTFunctionLibrary_GetBlackboardValueAsVector_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	struct FVector                               ReturnValue;                                       // 0x30(0xC)
	uint8                                        Pad_2C64[0x4];                                     // Fixing Size Of Struct
};

// 0x40 (0x40 - 0x0)
// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsString
struct UBTFunctionLibrary_GetBlackboardValueAsString_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	class FString                                ReturnValue;                                       // 0x30(0x10)
};

// 0x40 (0x40 - 0x0)
// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsRotator
struct UBTFunctionLibrary_GetBlackboardValueAsRotator_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	struct FRotator                              ReturnValue;                                       // 0x30(0xC)
	uint8                                        Pad_2C65[0x4];                                     // Fixing Size Of Struct
};

// 0x38 (0x38 - 0x0)
// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsObject
struct UBTFunctionLibrary_GetBlackboardValueAsObject_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	class UObject*                               ReturnValue;                                       // 0x30(0x8)
};

// 0x38 (0x38 - 0x0)
// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsName
struct UBTFunctionLibrary_GetBlackboardValueAsName_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	class FName                                  ReturnValue;                                       // 0x30(0x8)
};

// 0x38 (0x38 - 0x0)
// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsInt
struct UBTFunctionLibrary_GetBlackboardValueAsInt_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	int32                                        ReturnValue;                                       // 0x30(0x4)
	uint8                                        Pad_2C66[0x4];                                     // Fixing Size Of Struct
};

// 0x38 (0x38 - 0x0)
// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsFloat
struct UBTFunctionLibrary_GetBlackboardValueAsFloat_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	float                                        ReturnValue;                                       // 0x30(0x4)
	uint8                                        Pad_2C67[0x4];                                     // Fixing Size Of Struct
};

// 0x38 (0x38 - 0x0)
// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsEnum
struct UBTFunctionLibrary_GetBlackboardValueAsEnum_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	uint8                                        ReturnValue;                                       // 0x30(0x1)
	uint8                                        Pad_2C68[0x7];                                     // Fixing Size Of Struct
};

// 0x38 (0x38 - 0x0)
// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsClass
struct UBTFunctionLibrary_GetBlackboardValueAsClass_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	class UClass*                                ReturnValue;                                       // 0x30(0x8)
};

// 0x38 (0x38 - 0x0)
// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsBool
struct UBTFunctionLibrary_GetBlackboardValueAsBool_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	bool                                         ReturnValue;                                       // 0x30(0x1)
	uint8                                        Pad_2C69[0x7];                                     // Fixing Size Of Struct
};

// 0x38 (0x38 - 0x0)
// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsActor
struct UBTFunctionLibrary_GetBlackboardValueAsActor_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
	class AActor*                                ReturnValue;                                       // 0x30(0x8)
};

// 0x30 (0x30 - 0x0)
// Function AIModule.BTFunctionLibrary.ClearBlackboardValueAsVector
struct UBTFunctionLibrary_ClearBlackboardValueAsVector_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
};

// 0x30 (0x30 - 0x0)
// Function AIModule.BTFunctionLibrary.ClearBlackboardValue
struct UBTFunctionLibrary_ClearBlackboardValue_Params
{
public:
	class UBTNode*                               NodeOwner;                                         // 0x0(0x8)
	struct FBlackboardKeySelector                Key;                                               // 0x8(0x28)
};

// 0x18 (0x18 - 0x0)
// Function AIModule.BTDecorator_BlueprintBase.ReceiveTickAI
struct UBTDecorator_BlueprintBase_ReceiveTickAI_Params
{
public:
	class AAIController*                         OwnerController;                                   // 0x0(0x8)
	class APawn*                                 ControlledPawn;                                    // 0x8(0x8)
	float                                        DeltaSeconds;                                      // 0x10(0x4)
	uint8                                        Pad_2C6C[0x4];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BTDecorator_BlueprintBase.ReceiveTick
struct UBTDecorator_BlueprintBase_ReceiveTick_Params
{
public:
	class AActor*                                OwnerActor;                                        // 0x0(0x8)
	float                                        DeltaSeconds;                                      // 0x8(0x4)
	uint8                                        Pad_2C6D[0x4];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivatedAI
struct UBTDecorator_BlueprintBase_ReceiveObserverDeactivatedAI_Params
{
public:
	class AAIController*                         OwnerController;                                   // 0x0(0x8)
	class APawn*                                 ControlledPawn;                                    // 0x8(0x8)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivated
struct UBTDecorator_BlueprintBase_ReceiveObserverDeactivated_Params
{
public:
	class AActor*                                OwnerActor;                                        // 0x0(0x8)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivatedAI
struct UBTDecorator_BlueprintBase_ReceiveObserverActivatedAI_Params
{
public:
	class AAIController*                         OwnerController;                                   // 0x0(0x8)
	class APawn*                                 ControlledPawn;                                    // 0x8(0x8)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivated
struct UBTDecorator_BlueprintBase_ReceiveObserverActivated_Params
{
public:
	class AActor*                                OwnerActor;                                        // 0x0(0x8)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStartAI
struct UBTDecorator_BlueprintBase_ReceiveExecutionStartAI_Params
{
public:
	class AAIController*                         OwnerController;                                   // 0x0(0x8)
	class APawn*                                 ControlledPawn;                                    // 0x8(0x8)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStart
struct UBTDecorator_BlueprintBase_ReceiveExecutionStart_Params
{
public:
	class AActor*                                OwnerActor;                                        // 0x0(0x8)
};

// 0x18 (0x18 - 0x0)
// Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinishAI
struct UBTDecorator_BlueprintBase_ReceiveExecutionFinishAI_Params
{
public:
	class AAIController*                         OwnerController;                                   // 0x0(0x8)
	class APawn*                                 ControlledPawn;                                    // 0x8(0x8)
	enum class EBTNodeResult                     NodeResult;                                        // 0x10(0x1)
	uint8                                        Pad_2C6E[0x7];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinish
struct UBTDecorator_BlueprintBase_ReceiveExecutionFinish_Params
{
public:
	class AActor*                                OwnerActor;                                        // 0x0(0x8)
	enum class EBTNodeResult                     NodeResult;                                        // 0x8(0x1)
	uint8                                        Pad_2C6F[0x7];                                     // Fixing Size Of Struct
};

// 0x8 (0x8 - 0x0)
// Function AIModule.BTDecorator_BlueprintBase.ReceiveConditionCheck
struct UBTDecorator_BlueprintBase_ReceiveConditionCheck_Params
{
public:
	class AActor*                                OwnerActor;                                        // 0x0(0x8)
};

// 0x18 (0x18 - 0x0)
// Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheckAI
struct UBTDecorator_BlueprintBase_PerformConditionCheckAI_Params
{
public:
	class AAIController*                         OwnerController;                                   // 0x0(0x8)
	class APawn*                                 ControlledPawn;                                    // 0x8(0x8)
	bool                                         ReturnValue;                                       // 0x10(0x1)
	uint8                                        Pad_2C70[0x7];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheck
struct UBTDecorator_BlueprintBase_PerformConditionCheck_Params
{
public:
	class AActor*                                OwnerActor;                                        // 0x0(0x8)
	bool                                         ReturnValue;                                       // 0x8(0x1)
	uint8                                        Pad_2C71[0x7];                                     // Fixing Size Of Struct
};

// 0x1 (0x1 - 0x0)
// Function AIModule.BTDecorator_BlueprintBase.IsDecoratorObserverActive
struct UBTDecorator_BlueprintBase_IsDecoratorObserverActive_Params
{
public:
	bool                                         ReturnValue;                                       // 0x0(0x1)
};

// 0x1 (0x1 - 0x0)
// Function AIModule.BTDecorator_BlueprintBase.IsDecoratorExecutionActive
struct UBTDecorator_BlueprintBase_IsDecoratorExecutionActive_Params
{
public:
	bool                                         ReturnValue;                                       // 0x0(0x1)
};

// 0x1 (0x1 - 0x0)
// Function AIModule.BTDecorator_BlueprintBase.FinishConditionCheck
struct UBTDecorator_BlueprintBase_FinishConditionCheck_Params
{
public:
	bool                                         bAllowExecution;                                   // 0x0(0x1)
};

// 0x18 (0x18 - 0x0)
// Function AIModule.BTService_BlueprintBase.ReceiveTickAI
struct UBTService_BlueprintBase_ReceiveTickAI_Params
{
public:
	class AAIController*                         OwnerController;                                   // 0x0(0x8)
	class APawn*                                 ControlledPawn;                                    // 0x8(0x8)
	float                                        DeltaSeconds;                                      // 0x10(0x4)
	uint8                                        Pad_2C82[0x4];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BTService_BlueprintBase.ReceiveTick
struct UBTService_BlueprintBase_ReceiveTick_Params
{
public:
	class AActor*                                OwnerActor;                                        // 0x0(0x8)
	float                                        DeltaSeconds;                                      // 0x8(0x4)
	uint8                                        Pad_2C83[0x4];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BTService_BlueprintBase.ReceiveSearchStartAI
struct UBTService_BlueprintBase_ReceiveSearchStartAI_Params
{
public:
	class AAIController*                         OwnerController;                                   // 0x0(0x8)
	class APawn*                                 ControlledPawn;                                    // 0x8(0x8)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.BTService_BlueprintBase.ReceiveSearchStart
struct UBTService_BlueprintBase_ReceiveSearchStart_Params
{
public:
	class AActor*                                OwnerActor;                                        // 0x0(0x8)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BTService_BlueprintBase.ReceiveDeactivationAI
struct UBTService_BlueprintBase_ReceiveDeactivationAI_Params
{
public:
	class AAIController*                         OwnerController;                                   // 0x0(0x8)
	class APawn*                                 ControlledPawn;                                    // 0x8(0x8)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.BTService_BlueprintBase.ReceiveDeactivation
struct UBTService_BlueprintBase_ReceiveDeactivation_Params
{
public:
	class AActor*                                OwnerActor;                                        // 0x0(0x8)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BTService_BlueprintBase.ReceiveActivationAI
struct UBTService_BlueprintBase_ReceiveActivationAI_Params
{
public:
	class AAIController*                         OwnerController;                                   // 0x0(0x8)
	class APawn*                                 ControlledPawn;                                    // 0x8(0x8)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.BTService_BlueprintBase.ReceiveActivation
struct UBTService_BlueprintBase_ReceiveActivation_Params
{
public:
	class AActor*                                OwnerActor;                                        // 0x0(0x8)
};

// 0x1 (0x1 - 0x0)
// Function AIModule.BTService_BlueprintBase.IsServiceActive
struct UBTService_BlueprintBase_IsServiceActive_Params
{
public:
	bool                                         ReturnValue;                                       // 0x0(0x1)
};

// 0xC (0xC - 0x0)
// Function AIModule.BTTask_BlueprintBase.SetFinishOnMessageWithId
struct UBTTask_BlueprintBase_SetFinishOnMessageWithId_Params
{
public:
	class FName                                  MessageName;                                       // 0x0(0x8)
	int32                                        RequestID;                                         // 0x8(0x4)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.BTTask_BlueprintBase.SetFinishOnMessage
struct UBTTask_BlueprintBase_SetFinishOnMessage_Params
{
public:
	class FName                                  MessageName;                                       // 0x0(0x8)
};

// 0x18 (0x18 - 0x0)
// Function AIModule.BTTask_BlueprintBase.ReceiveTickAI
struct UBTTask_BlueprintBase_ReceiveTickAI_Params
{
public:
	class AAIController*                         OwnerController;                                   // 0x0(0x8)
	class APawn*                                 ControlledPawn;                                    // 0x8(0x8)
	float                                        DeltaSeconds;                                      // 0x10(0x4)
	uint8                                        Pad_2C8B[0x4];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BTTask_BlueprintBase.ReceiveTick
struct UBTTask_BlueprintBase_ReceiveTick_Params
{
public:
	class AActor*                                OwnerActor;                                        // 0x0(0x8)
	float                                        DeltaSeconds;                                      // 0x8(0x4)
	uint8                                        Pad_2C8C[0x4];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BTTask_BlueprintBase.ReceiveExecuteAI
struct UBTTask_BlueprintBase_ReceiveExecuteAI_Params
{
public:
	class AAIController*                         OwnerController;                                   // 0x0(0x8)
	class APawn*                                 ControlledPawn;                                    // 0x8(0x8)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.BTTask_BlueprintBase.ReceiveExecute
struct UBTTask_BlueprintBase_ReceiveExecute_Params
{
public:
	class AActor*                                OwnerActor;                                        // 0x0(0x8)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.BTTask_BlueprintBase.ReceiveAbortAI
struct UBTTask_BlueprintBase_ReceiveAbortAI_Params
{
public:
	class AAIController*                         OwnerController;                                   // 0x0(0x8)
	class APawn*                                 ControlledPawn;                                    // 0x8(0x8)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.BTTask_BlueprintBase.ReceiveAbort
struct UBTTask_BlueprintBase_ReceiveAbort_Params
{
public:
	class AActor*                                OwnerActor;                                        // 0x0(0x8)
};

// 0x1 (0x1 - 0x0)
// Function AIModule.BTTask_BlueprintBase.IsTaskExecuting
struct UBTTask_BlueprintBase_IsTaskExecuting_Params
{
public:
	bool                                         ReturnValue;                                       // 0x0(0x1)
};

// 0x1 (0x1 - 0x0)
// Function AIModule.BTTask_BlueprintBase.IsTaskAborting
struct UBTTask_BlueprintBase_IsTaskAborting_Params
{
public:
	bool                                         ReturnValue;                                       // 0x0(0x1)
};

// 0x1 (0x1 - 0x0)
// Function AIModule.BTTask_BlueprintBase.FinishExecute
struct UBTTask_BlueprintBase_FinishExecute_Params
{
public:
	bool                                         bSuccess;                                          // 0x0(0x1)
};

// 0x0 (0x0 - 0x0)
// Function AIModule.BTTask_BlueprintBase.FinishAbort
struct UBTTask_BlueprintBase_FinishAbort_Params
{
public:
};

// 0x1 (0x1 - 0x0)
// Function AIModule.PawnAction.GetActionPriority
struct UPawnAction_GetActionPriority_Params
{
public:
	enum class EAIRequestPriority                ReturnValue;                                       // 0x0(0x1)
};

// 0x1 (0x1 - 0x0)
// Function AIModule.PawnAction.Finish
struct UPawnAction_Finish_Params
{
public:
	enum class EPawnActionResult                 WithResult;                                        // 0x0(0x1)
};

// 0x18 (0x18 - 0x0)
// Function AIModule.PawnAction.CreateActionInstance
struct UPawnAction_CreateActionInstance_Params
{
public:
	class UObject*                               WorldContextObject;                                // 0x0(0x8)
	TSubclassOf<class UPawnAction>               ActionClass;                                       // 0x8(0x8)
	class UPawnAction*                           ReturnValue;                                       // 0x10(0x8)
};

// 0x18 (0x18 - 0x0)
// Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleLocation
struct UEnvQueryContext_BlueprintBase_ProvideSingleLocation_Params
{
public:
	class AActor*                                QuerierActor;                                      // 0x0(0x8)
	struct FVector                               ResultingLocation;                                 // 0x8(0xC)
	uint8                                        Pad_2C96[0x4];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleActor
struct UEnvQueryContext_BlueprintBase_ProvideSingleActor_Params
{
public:
	class AActor*                                QuerierActor;                                      // 0x0(0x8)
	class AActor*                                ResultingActor;                                    // 0x8(0x8)
};

// 0x18 (0x18 - 0x0)
// Function AIModule.EnvQueryContext_BlueprintBase.ProvideLocationsSet
struct UEnvQueryContext_BlueprintBase_ProvideLocationsSet_Params
{
public:
	class AActor*                                QuerierActor;                                      // 0x0(0x8)
	TArray<struct FVector>                       ResultingLocationSet;                              // 0x8(0x10)
};

// 0x18 (0x18 - 0x0)
// Function AIModule.EnvQueryContext_BlueprintBase.ProvideActorsSet
struct UEnvQueryContext_BlueprintBase_ProvideActorsSet_Params
{
public:
	class AActor*                                QuerierActor;                                      // 0x0(0x8)
	TArray<class AActor*>                        ResultingActorsSet;                                // 0x8(0x10)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsLocations
struct UEnvQueryInstanceBlueprintWrapper_GetResultsAsLocations_Params
{
public:
	TArray<struct FVector>                       ReturnValue;                                       // 0x0(0x10)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsActors
struct UEnvQueryInstanceBlueprintWrapper_GetResultsAsActors_Params
{
public:
	TArray<class AActor*>                        ReturnValue;                                       // 0x0(0x10)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.EnvQueryInstanceBlueprintWrapper.GetItemScore
struct UEnvQueryInstanceBlueprintWrapper_GetItemScore_Params
{
public:
	int32                                        ItemIndex;                                         // 0x0(0x4)
	float                                        ReturnValue;                                       // 0x4(0x4)
};

// 0x10 (0x10 - 0x0)
// DelegateFunction AIModule.EnvQueryInstanceBlueprintWrapper.EQSQueryDoneSignature__DelegateSignature
struct UEnvQueryInstanceBlueprintWrapper_EQSQueryDoneSignature__DelegateSignature_Params
{
public:
	class UEnvQueryInstanceBlueprintWrapper*     QueryInstance;                                     // 0x0(0x8)
	enum class EEnvQueryStatus                   QueryStatus;                                       // 0x8(0x1)
	uint8                                        Pad_2C98[0x7];                                     // Fixing Size Of Struct
};

// 0x30 (0x30 - 0x0)
// Function AIModule.EnvQueryManager.RunEQSQuery
struct UEnvQueryManager_RunEQSQuery_Params
{
public:
	class UObject*                               WorldContext;                                      // 0x0(0x8)
	class UEnvQuery*                             QueryTemplate;                                     // 0x8(0x8)
	class UObject*                               Querier;                                           // 0x10(0x8)
	enum class EEnvQueryRunMode                  RunMode;                                           // 0x18(0x1)
	uint8                                        Pad_2C9C[0x7];                                     // Fixing Size After Last Property
	TSubclassOf<class UEnvQueryInstanceBlueprintWrapper> WrapperClass;                                      // 0x20(0x8)
	class UEnvQueryInstanceBlueprintWrapper*     ReturnValue;                                       // 0x28(0x8)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.EnvQueryGenerator_BlueprintBase.GetQuerier
struct UEnvQueryGenerator_BlueprintBase_GetQuerier_Params
{
public:
	class UObject*                               ReturnValue;                                       // 0x0(0x8)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.EnvQueryGenerator_BlueprintBase.DoItemGeneration
struct UEnvQueryGenerator_BlueprintBase_DoItemGeneration_Params
{
public:
	TArray<struct FVector>                       ContextLocations;                                  // 0x0(0x10)
};

// 0xC (0xC - 0x0)
// Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedVector
struct UEnvQueryGenerator_BlueprintBase_AddGeneratedVector_Params
{
public:
	struct FVector                               GeneratedVector;                                   // 0x0(0xC)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedActor
struct UEnvQueryGenerator_BlueprintBase_AddGeneratedActor_Params
{
public:
	class AActor*                                GeneratedActor;                                    // 0x0(0x8)
};

// 0x1 (0x1 - 0x0)
// Function AIModule.CrowdFollowingComponent.SuspendCrowdSteering
struct UCrowdFollowingComponent_SuspendCrowdSteering_Params
{
public:
	bool                                         bSuspend;                                          // 0x0(0x1)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.PawnAction_BlueprintBase.ActionTick
struct UPawnAction_BlueprintBase_ActionTick_Params
{
public:
	class APawn*                                 ControlledPawn;                                    // 0x0(0x8)
	float                                        DeltaSeconds;                                      // 0x8(0x4)
	uint8                                        Pad_2CB1[0x4];                                     // Fixing Size Of Struct
};

// 0x8 (0x8 - 0x0)
// Function AIModule.PawnAction_BlueprintBase.ActionStart
struct UPawnAction_BlueprintBase_ActionStart_Params
{
public:
	class APawn*                                 ControlledPawn;                                    // 0x0(0x8)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.PawnAction_BlueprintBase.ActionResume
struct UPawnAction_BlueprintBase_ActionResume_Params
{
public:
	class APawn*                                 ControlledPawn;                                    // 0x0(0x8)
};

// 0x8 (0x8 - 0x0)
// Function AIModule.PawnAction_BlueprintBase.ActionPause
struct UPawnAction_BlueprintBase_ActionPause_Params
{
public:
	class APawn*                                 ControlledPawn;                                    // 0x0(0x8)
};

// 0x10 (0x10 - 0x0)
// Function AIModule.PawnAction_BlueprintBase.ActionFinished
struct UPawnAction_BlueprintBase_ActionFinished_Params
{
public:
	class APawn*                                 ControlledPawn;                                    // 0x0(0x8)
	enum class EPawnActionResult                 WithResult;                                        // 0x8(0x1)
	uint8                                        Pad_2CB2[0x7];                                     // Fixing Size Of Struct
};

// 0x1 (0x1 - 0x0)
// Function AIModule.PawnSensingComponent.SetSensingUpdatesEnabled
struct UPawnSensingComponent_SetSensingUpdatesEnabled_Params
{
public:
	bool                                         bEnabled;                                          // 0x0(0x1)
};

// 0x4 (0x4 - 0x0)
// Function AIModule.PawnSensingComponent.SetSensingInterval
struct UPawnSensingComponent_SetSensingInterval_Params
{
public:
	float                                        NewSensingInterval;                                // 0x0(0x4)
};

// 0x4 (0x4 - 0x0)
// Function AIModule.PawnSensingComponent.SetPeripheralVisionAngle
struct UPawnSensingComponent_SetPeripheralVisionAngle_Params
{
public:
	float                                        NewPeripheralVisionAngle;                          // 0x0(0x4)
};

// 0x8 (0x8 - 0x0)
// DelegateFunction AIModule.PawnSensingComponent.SeePawnDelegate__DelegateSignature
struct UPawnSensingComponent_SeePawnDelegate__DelegateSignature_Params
{
public:
	class APawn*                                 Pawn;                                              // 0x0(0x8)
};

// 0x18 (0x18 - 0x0)
// DelegateFunction AIModule.PawnSensingComponent.HearNoiseDelegate__DelegateSignature
struct UPawnSensingComponent_HearNoiseDelegate__DelegateSignature_Params
{
public:
	class APawn*                                 Instigator;                                        // 0x0(0x8)
	struct FVector                               Location;                                          // 0x8(0xC)
	float                                        Volume;                                            // 0x14(0x4)
};

// 0x4 (0x4 - 0x0)
// Function AIModule.PawnSensingComponent.GetPeripheralVisionCosine
struct UPawnSensingComponent_GetPeripheralVisionCosine_Params
{
public:
	float                                        ReturnValue;                                       // 0x0(0x4)
};

// 0x4 (0x4 - 0x0)
// Function AIModule.PawnSensingComponent.GetPeripheralVisionAngle
struct UPawnSensingComponent_GetPeripheralVisionAngle_Params
{
public:
	float                                        ReturnValue;                                       // 0x0(0x4)
};

}
}


