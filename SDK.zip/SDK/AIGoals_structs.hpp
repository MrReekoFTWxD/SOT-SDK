#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// ENUMS
//---------------------------------------------------------------------------------------------------------------------


//---------------------------------------------------------------------------------------------------------------------
// STRUCTS
//---------------------------------------------------------------------------------------------------------------------

// 0x34 (0x34 - 0x0)
// ScriptStruct AIGoals.BestActionSpotSelectionCriteria
struct FBestActionSpotSelectionCriteria
{
public:
	bool                                         PreferActionSpotsRelativeToTargetForwardFacingDirection; // 0x0(0x1)
	uint8                                        Pad_2BF1[0x3];                                     // Fixing Size After Last Property
	float                                        ForwardFacingPreferenceMinAngleInDegrees;          // 0x4(0x4)
	float                                        ForwardFacingPreferenceMaxAngleInDegrees;          // 0x8(0x4)
	float                                        ForwardFacingPreferenceMinDistance;                // 0xC(0x4)
	float                                        ForwardFacingPreferenceMaxDistance;                // 0x10(0x4)
	bool                                         PreferStayingAtCurrentSpotOverMovingToNewSpot;     // 0x14(0x1)
	uint8                                        Pad_2BF2[0x3];                                     // Fixing Size After Last Property
	float                                        StayingPreferenceDistance;                         // 0x18(0x4)
	bool                                         PreferActionSpotsCloserToSelf;                     // 0x1C(0x1)
	uint8                                        Pad_2BF3[0x3];                                     // Fixing Size After Last Property
	float                                        MaximumDistanceAllowedFromTarget;                  // 0x20(0x4)
	bool                                         ShouldAlwaysRefreshWhileOwnerMoving;               // 0x24(0x1)
	bool                                         ShouldRefreshAfterTargetMovesBeyondThreshold;      // 0x25(0x1)
	uint8                                        Pad_2BF4[0x2];                                     // Fixing Size After Last Property
	float                                        TargetMovementRefreshThresholdDistance;            // 0x28(0x4)
	bool                                         ShouldRefreshAfterStayingForTooLong;               // 0x2C(0x1)
	uint8                                        Pad_2BF5[0x3];                                     // Fixing Size After Last Property
	float                                        RefreshTimeInSeconds;                              // 0x30(0x4)
};

// 0x18 (0x40 - 0x28)
// ScriptStruct AIGoals.HasAllActionContextTagsCondition
struct FHasAllActionContextTagsCondition : public FTargetedPayloadConditionBase
{
public:
	TArray<TSubclassOf<class UAIActionContextTag>> RequiredContextTags;                               // 0x28(0x10)
	bool                                         ExpectedValue;                                     // 0x38(0x1)
	uint8                                        Pad_2BF6[0x7];                                     // Fixing Size Of Struct
};

}


