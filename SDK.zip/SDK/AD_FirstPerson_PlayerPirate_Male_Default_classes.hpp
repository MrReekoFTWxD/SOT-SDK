#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x420 (0x4A0 - 0x80)
// BlueprintGeneratedClass AD_FirstPerson_PlayerPirate_Male_Default.AD_FirstPerson_PlayerPirate_Male_Default_C
class UAD_FirstPerson_PlayerPirate_Male_Default_C : public UFirstPersonAnimationData
{
public:
	struct FADS_IdlesNative                      Idles;                                             // 0x80(0x10)
	struct FADS_LocomotionNative                 Locomotion;                                        // 0x90(0x50)
	struct FADS_JumpingNative                    Jumping;                                           // 0xE0(0x78)
	struct FADS_SwimmingNative                   Swimming;                                          // 0x158(0x68)
	struct FADS_WheelNative                      Wheel;                                             // 0x1C0(0x88)
	struct FADS_CapstanNative                    Capstan;                                           // 0x248(0x68)
	struct FADS_CameraAdditiveNative             CameraAdditive;                                    // 0x2B0(0x50)
	struct FADS_ObjectsNative                    Items;                                             // 0x300(0x10)
	struct FADS_Sockets                          Sockets;                                           // 0x310(0x2)
	uint8                                        Pad_3E91[0x6];                                     // Fixing Size After Last Property
	struct FADS_CannonNative                     Cannon;                                            // 0x318(0x38)
	struct FADS_RowingBoatNative                 Rowboat;                                           // 0x350(0x98)
	struct FADS_WaterPumpNative                  WaterPump;                                         // 0x3E8(0x28)
	struct FADS_FacialNative                     Facial;                                            // 0x410(0x90)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AD_FirstPerson_PlayerPirate_Male_Default_C"));
		return Clss;
	}

};

}


