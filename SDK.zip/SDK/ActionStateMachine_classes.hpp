#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x28 - 0x28)
// Class ActionStateMachine.ActionStateId
class UActionStateId : public UObject
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ActionStateId"));
		return Clss;
	}

};

// 0x0 (0x3C8 - 0x3C8)
// Class ActionStateMachine.ActionStateCreatorDefinition
class AActionStateCreatorDefinition : public AActor
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ActionStateCreatorDefinition"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class ActionStateMachine.ActionStateInitialStateCreatorDefinition
class UActionStateInitialStateCreatorDefinition : public UObject
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ActionStateInitialStateCreatorDefinition"));
		return Clss;
	}

};

// 0x28 (0x600 - 0x5D8)
// Class ActionStateMachine.CharacterWithActionStateMachine
class ACharacterWithActionStateMachine : public ACharacter
{
public:
	uint8                                        Pad_2901[0x8];                                     // Fixing Size After Last Property
	class UActionStateMachineComponent*          ActionStateMachineComponent;                       // 0x5E0(0x8)
	class UActionStatePriorityTableData*         ActionStatePriorityTableData;                      // 0x5E8(0x8)
	TSubclassOf<class AActionStateCreatorDefinition> ActionStateCreatorDefinition;                      // 0x5F0(0x8)
	TSubclassOf<class UActionStateInitialStateCreatorDefinition> ActionStateInitialStateCreatorDefinition;          // 0x5F8(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("CharacterWithActionStateMachine"));
		return Clss;
	}

};

// 0x18 (0x3E0 - 0x3C8)
// Class ActionStateMachine.TestActionStateCreatorDefinition
class ATestActionStateCreatorDefinition : public AActionStateCreatorDefinition
{
public:
	uint8                                        Pad_2902[0x18];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("TestActionStateCreatorDefinition"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class ActionStateMachine.CustomClientValidityActionState2Id
class UCustomClientValidityActionState2Id : public UActionStateId
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("CustomClientValidityActionState2Id"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class ActionStateMachine.CustomClientValidityActionStateId
class UCustomClientValidityActionStateId : public UActionStateId
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("CustomClientValidityActionStateId"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class ActionStateMachine.NullActionStateId
class UNullActionStateId : public UActionStateId
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("NullActionStateId"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class ActionStateMachine.TestActionStateId
class UTestActionStateId : public UActionStateId
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("TestActionStateId"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class ActionStateMachine.TestActionStateId2
class UTestActionStateId2 : public UActionStateId
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("TestActionStateId2"));
		return Clss;
	}

};

// 0x790 (0x858 - 0xC8)
// Class ActionStateMachine.ActionStateMachineComponent
class UActionStateMachineComponent : public UActorComponent
{
public:
	uint8                                        Pad_290A[0x18];                                    // Fixing Size After Last Property
	UMulticastInlineDelegateProperty_            OnActionChangedOnTrack;                            // 0xE0(0x10)
	uint8                                        Pad_290B[0x768];                                   // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ActionStateMachineComponent"));
		return Clss;
	}

	void Server_RequestActionWithMessageForCurrentState(const struct FActionStateChangeRequestId& InEpochId, const struct FActionStateChangeRequestId& InRequestId, struct FSerialisedActionStateInfo& InSerialisedActionStateConstructionInfo, struct FSerialisedActionStateMessage& InSerialisedPreviousStateMessage);
	void Server_RequestAction(const struct FActionStateChangeRequestId& InEpochId, const struct FActionStateChangeRequestId& InRequestId, struct FSerialisedActionStateInfo& InSerialisedActionStateConstructionInfo, enum class EActionPredictionType ClientPredicted);
	void PostNetInit();
	void OnNetOwnershipChanged();
	void Multicast_PushSerialisableData(const struct FActionStateChangeRequestId& InEpochId, struct FSerialisedActionStateInfo& InSerialisedActionStateSerialisationStateInfo);
	void Multicast_PushActionFromRequest(const struct FActionStateChangeRequestId& InEpochId, struct FSerialisedActionStateInfo& InSerialisedActionStateConstructionInfo);
	void Multicast_PushAction(const struct FActionStateChangeRequestId& InEpochId, struct FSerialisedActionStateInfo& InSerialisedActionStateConstructionInfo);
	void End();
	void Client_ResetStateMachine(const struct FResetStateMachineRpc& Rpc);
	void Client_CorrectAction(const struct FActionStateChangeRequestId& InEpochId, const struct FActionStateChangeRequestId& InRequestId, struct FSerialisedActionStateInfo& InSerialisedActionStateConstructionInfo);
};

// 0x0 (0x28 - 0x28)
// Class ActionStateMachine.ActionStateMachineInterface
class UActionStateMachineInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ActionStateMachineInterface"));
		return Clss;
	}

};

// 0x48 (0x8A0 - 0x858)
// Class ActionStateMachine.SelfInitialisingActionStateMachineComponent
class USelfInitialisingActionStateMachineComponent : public UActionStateMachineComponent
{
public:
	uint8                                        Pad_290C[0x8];                                     // Fixing Size After Last Property
	class UActionStatePriorityTableData*         ActionStatePriorityTableData;                      // 0x860(0x8)
	TSubclassOf<class AActionStateCreatorDefinition> ActionStateCreatorDefinition;                      // 0x868(0x8)
	TSubclassOf<class UActionStateInitialStateCreatorDefinition> ActionStateInitialStateCreatorDefinition;          // 0x870(0x8)
	uint8                                        Pad_290D[0x28];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("SelfInitialisingActionStateMachineComponent"));
		return Clss;
	}

};

// 0x8 (0x30 - 0x28)
// Class ActionStateMachine.CustomClientValidityCheckCallback
class UCustomClientValidityCheckCallback : public UObject
{
public:
	bool                                         ShouldPassClientValidation;                        // 0x28(0x1)
	uint8                                        Pad_290E[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("CustomClientValidityCheckCallback"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class ActionStateMachine.ActionStateMachineComponentTestFunctions
class UActionStateMachineComponentTestFunctions : public UBlueprintFunctionLibrary
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ActionStateMachineComponentTestFunctions"));
		return Clss;
	}

	bool SetTestStateValidatorThatAlwaysPassesExceptForId(class UActionStateMachineComponent* InComponent, TSubclassOf<class UActionStateId> StateId);
	bool SetTestStateValidatorThatAlwaysPasses(class UActionStateMachineComponent* InComponent);
	bool SetTestStateValidatorThatAlwaysFails(class UActionStateMachineComponent* InComponent);
	bool SetTestStateFactoryChangeToNullOnUpdate(class UActionStateMachineComponent* InComponent);
	bool SetTestStateFactory(class UActionStateMachineComponent* InComponent);
	bool SetCustomClientValidationTestStateFactory(class UActionStateMachineComponent* InComponent, class UCustomClientValidityCheckCallback* InCallback);
	bool RequestUnpredictedTestActionStateWithIdOnTrack(class UActionStateMachineComponent* InComponent, enum class EActionStateMachineTrackId TrackId, TSubclassOf<class UActionStateId> ClientStateId, TSubclassOf<class UActionStateId> ServerStateId);
	bool RequestTestActionStateWithIdOnTrack(class UActionStateMachineComponent* InComponent, enum class EActionStateMachineTrackId TrackId, TSubclassOf<class UActionStateId> StateId);
	bool RequestNullActionStateOnTrack(class UActionStateMachineComponent* InComponent, enum class EActionStateMachineTrackId TrackId);
	void PushTestActionStateSerialisableDataOnTrack(class UActionStateMachineComponent* InComponent, enum class EActionStateMachineTrackId TrackId, TSubclassOf<class UActionStateId> StateId, int32 DataValue);
	bool IsActionStateTypeActiveOnTrack(class UActionStateMachineComponent* InComponent, enum class EActionStateMachineTrackId TrackId, TSubclassOf<class UActionStateId> StateId);
	TSubclassOf<class UActionStateId> GetTypeOfActionStateActiveOnTrack(class UActionStateMachineComponent* InComponent, enum class EActionStateMachineTrackId TrackId);
	bool GetTestActionStateSerialisableDataOnTrack(class UActionStateMachineComponent* InComponent, enum class EActionStateMachineTrackId TrackId, struct FTestActionStateSerialisableData* Data);
	class UCustomClientValidityCheckCallback* CreateCustomClientValidityCheckCallback();
};

// 0x20 (0x48 - 0x28)
// Class ActionStateMachine.ActionStatePriorityTableData
class UActionStatePriorityTableData : public UDataAsset
{
public:
	TArray<struct FActionStatePriorityRelationship> StateDefaultValue;                                 // 0x28(0x10)
	TArray<struct FActionStatePriorityList>      PriorityTableEntry;                                // 0x38(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ActionStatePriorityTableData"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class ActionStateMachine.ActionStatePriorityTableUtility
class UActionStatePriorityTableUtility : public UBlueprintFunctionLibrary
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ActionStatePriorityTableUtility"));
		return Clss;
	}

	enum class EActionStatePriority GetPriority(struct FActionStatePriorityTable& PriorityTable, TSubclassOf<class UActionStateId> InStateA, TSubclassOf<class UActionStateId> InStateB);
	struct FActionStatePriorityTable CreatePriorityTable(class UActionStatePriorityTableData* Data);
};

// 0x0 (0x28 - 0x28)
// Class ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions
class USerialisedActionStateConstructionInfoTestFunctions : public UBlueprintFunctionLibrary
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("SerialisedActionStateConstructionInfoTestFunctions"));
		return Clss;
	}

	bool IsValid(struct FSerialisedActionStateInfo& TestStruct);
	bool HasTestConstructionInfoWithInner(struct FSerialisedActionStateInfo& TestStruct);
	bool HasTestConstructionInfo(struct FSerialisedActionStateInfo& TestStruct);
	struct FTestActionStateConstructionInfoWithInner GetTestConstructionInfoWithInner(struct FSerialisedActionStateInfo& TestStruct);
	struct FTestActionStateConstructionInfo GetTestConstructionInfo(struct FSerialisedActionStateInfo& TestStruct);
	struct FSerialisedActionStateInfo CreateTestSerialisableData(TSubclassOf<class UActionStateId> Id, int32 IntProp);
	struct FSerialisedActionStateInfo CreateTestConstructionInfoWithInner(TSubclassOf<class UActionStateId> Id, float FloatProp, bool BoolProp, const class FString& StringProp);
	struct FSerialisedActionStateInfo CreateTestConstructionInfo(TSubclassOf<class UActionStateId> Id, int32 IntProp);
};

}


