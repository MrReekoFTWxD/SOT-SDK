#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x30 - 0x28)
// Class AdventureOnDemandFramework.AdventureOnDemandArrivalTunnelWorkerBase
class UAdventureOnDemandArrivalTunnelWorkerBase : public UObject
{
public:
	class UWorld*                                WorldPtr;                                          // 0x28(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandArrivalTunnelWorkerBase"));
		return Clss;
	}

};

// 0x0 (0x98 - 0x98)
// Class AdventureOnDemandFramework.AdventureOnDemandAreCrewNearQuestTargetStep
class UAdventureOnDemandAreCrewNearQuestTargetStep : public UTaleQuestStep
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandAreCrewNearQuestTargetStep"));
		return Clss;
	}

};

// 0x30 (0xB0 - 0x80)
// Class AdventureOnDemandFramework.AdventureOnDemandAreCrewNearQuestTargetStepDesc
class UAdventureOnDemandAreCrewNearQuestTargetStepDesc : public UTaleQuestStepDesc
{
public:
	struct FQuestVariableBool                    AreCrewNearQuestTarget;                            // 0x80(0x30)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandAreCrewNearQuestTargetStepDesc"));
		return Clss;
	}

};

// 0x20 (0xF8 - 0xD8)
// Class AdventureOnDemandFramework.AdventureOnDemandArrivalTunnelDependencies
class UAdventureOnDemandArrivalTunnelDependencies : public UArrivalTunnelDependencies
{
public:
	UInterfaceProperty_                          AdventureOnDemandService;                          // 0xD8(0x10)
	UInterfaceProperty_                          GameEventSchedulerService;                         // 0xE8(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandArrivalTunnelDependencies"));
		return Clss;
	}

};

// 0x28 (0xD8 - 0xB0)
// Class AdventureOnDemandFramework.AdventureOnDemandArrivalTunnelDesc
class UAdventureOnDemandArrivalTunnelDesc : public UClientDestinationPreLoadingArrivalTunnelDesc
{
public:
	struct FVector                               ResurfaceLocationOffset;                           // 0xB0(0xC)
	uint8                                        Pad_37D3[0x4];                                     // Fixing Size After Last Property
	class UAdventureOnDemandArrivalTunnelWorkerBase* DefaultArrivalLocationWorkerClass;                 // 0xC0(0x8)
	class UEnvQuery*                             ResurfaceLocationEQ;                               // 0xC8(0x8)
	bool                                         ShouldExcludeCrewFromBeingTargetedForGameEvents;   // 0xD0(0x1)
	uint8                                        Pad_37D4[0x3];                                     // Fixing Size After Last Property
	float                                        ExclusionTimerFromBeingTargetedForGameEvents;      // 0xD4(0x4)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandArrivalTunnelDesc"));
		return Clss;
	}

};

// 0x60 (0x700 - 0x6A0)
// Class AdventureOnDemandFramework.AdventureOnDemandArrivalTunnelOfTheDamned
class AAdventureOnDemandArrivalTunnelOfTheDamned : public AClientDestinationPreLoadingArrivalTunnelOfTheDamned
{
public:
	uint8                                        Pad_37D5[0x28];                                    // Fixing Size After Last Property
	class UAdventureOnDemandArrivalTunnelDesc*   AdventureOnDemandArrivalTunnelDesc;                // 0x6C8(0x8)
	class UAdventureOnDemandArrivalTunnelWorkerBase* ArrivalLocationWorker;                             // 0x6D0(0x8)
	UInterfaceProperty_                          AdventureOnDemandServiceWeakPtr;                   // 0x6D8(0x10)
	UInterfaceProperty_                          GameEventSchedulerServiceWeakPtr;                  // 0x6E8(0x10)
	uint8                                        Pad_37D6[0x8];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandArrivalTunnelOfTheDamned"));
		return Clss;
	}

};

// 0x0 (0x30 - 0x30)
// Class AdventureOnDemandFramework.VoyageOnDemandArrivalTunnelWorker
class UVoyageOnDemandArrivalTunnelWorker : public UAdventureOnDemandArrivalTunnelWorkerBase
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("VoyageOnDemandArrivalTunnelWorker"));
		return Clss;
	}

};

// 0x10 (0x148 - 0x138)
// Class AdventureOnDemandFramework.AdventureOnDemandDepartureTunnelDependencies
class UAdventureOnDemandDepartureTunnelDependencies : public UDepartureTunnelDependencies
{
public:
	UInterfaceProperty_                          AdventureOnDemandService;                          // 0x138(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandDepartureTunnelDependencies"));
		return Clss;
	}

};

// 0x0 (0x148 - 0x148)
// Class AdventureOnDemandFramework.GameEventOnDemandDepartureTunnelDependencies
class UGameEventOnDemandDepartureTunnelDependencies : public UAdventureOnDemandDepartureTunnelDependencies
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("GameEventOnDemandDepartureTunnelDependencies"));
		return Clss;
	}

};

// 0x0 (0x148 - 0x148)
// Class AdventureOnDemandFramework.VoyageOnDemandDepartureTunnelDependencies
class UVoyageOnDemandDepartureTunnelDependencies : public UAdventureOnDemandDepartureTunnelDependencies
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("VoyageOnDemandDepartureTunnelDependencies"));
		return Clss;
	}

};

// 0x10 (0x128 - 0x118)
// Class AdventureOnDemandFramework.AdventureOnDemandDepartureTunnelDesc
class UAdventureOnDemandDepartureTunnelDesc : public UDepartureTunnelDesc
{
public:
	float                                        SecondsAfterCrewArriveInTunnelBeforeAllowingTunnelCancellation; // 0x118(0x4)
	float                                        SecondsBetweenTunnelCancellationPopupReminder;     // 0x11C(0x4)
	class UPopUpMessageDesc*                     DefaultTunnelCancellationAvailableReminderPopup;   // 0x120(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandDepartureTunnelDesc"));
		return Clss;
	}

};

// 0x20 (0x148 - 0x128)
// Class AdventureOnDemandFramework.GameEventOnDemandDepartureTunnelDesc
class UGameEventOnDemandDepartureTunnelDesc : public UAdventureOnDemandDepartureTunnelDesc
{
public:
	TSoftClassPtr<class UGameEventType>          GameEventType;                                     // 0x128(0x20)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("GameEventOnDemandDepartureTunnelDesc"));
		return Clss;
	}

};

// 0x0 (0x128 - 0x128)
// Class AdventureOnDemandFramework.VoyageOnDemandDepartureTunnelDesc
class UVoyageOnDemandDepartureTunnelDesc : public UAdventureOnDemandDepartureTunnelDesc
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("VoyageOnDemandDepartureTunnelDesc"));
		return Clss;
	}

};

// 0x10 (0x38 - 0x28)
// Class AdventureOnDemandFramework.TradingCompanyPopUpBackgroundCollectionDataAsset
class UTradingCompanyPopUpBackgroundCollectionDataAsset : public UDataAsset
{
public:
	TArray<struct FTradingCompanyPopUpBackgroundEntry> Entries;                                           // 0x28(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("TradingCompanyPopUpBackgroundCollectionDataAsset"));
		return Clss;
	}

};

// 0x38 (0x8F0 - 0x8B8)
// Class AdventureOnDemandFramework.AdventureOnDemandDepartureTunnelOfTheDamned
class AAdventureOnDemandDepartureTunnelOfTheDamned : public ADepartureTunnelOfTheDamned
{
public:
	class UAdventureOnDemandDepartureTunnelDesc* AdventureOnDemandDepartureTunnelDesc;              // 0x8B8(0x8)
	UInterfaceProperty_                          AdventureOnDemandService;                          // 0x8C0(0x10)
	uint8                                        Pad_37D7[0x20];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandDepartureTunnelOfTheDamned"));
		return Clss;
	}

};

// 0x10 (0x900 - 0x8F0)
// Class AdventureOnDemandFramework.GameEventOnDemandDepartureTunnelOfTheDamned
class AGameEventOnDemandDepartureTunnelOfTheDamned : public AAdventureOnDemandDepartureTunnelOfTheDamned
{
public:
	class UGameEventOnDemandDepartureTunnelDesc* GameEventOnDemandDepartureTunnelDesc;              // 0x8F0(0x8)
	uint8                                        Pad_37D8[0x8];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("GameEventOnDemandDepartureTunnelOfTheDamned"));
		return Clss;
	}

};

// 0x10 (0x900 - 0x8F0)
// Class AdventureOnDemandFramework.VoyageOnDemandDepartureTunnelOfTheDamned
class AVoyageOnDemandDepartureTunnelOfTheDamned : public AAdventureOnDemandDepartureTunnelOfTheDamned
{
public:
	class UVoyageOnDemandDepartureTunnelDesc*    VoyageOnDemandDepartureTunnelDesc;                 // 0x8F0(0x8)
	uint8                                        Pad_37D9[0x8];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("VoyageOnDemandDepartureTunnelOfTheDamned"));
		return Clss;
	}

};

// 0x48 (0x70 - 0x28)
// Class AdventureOnDemandFramework.AdventureOnDemandVoyageSelectionCompanyDataAsset
class UAdventureOnDemandVoyageSelectionCompanyDataAsset : public UDataAsset
{
public:
	class FName                                  CompanyName;                                       // 0x28(0x8)
	TSubclassOf<class UCompany>                  Company;                                           // 0x30(0x8)
	TSubclassOf<class UQuestTableDiscoverTileCategory> DiscoverTileCategory;                              // 0x38(0x8)
	struct FFeatureFlag                          Feature;                                           // 0x40(0xC)
	uint8                                        Pad_37DA[0x4];                                     // Fixing Size After Last Property
	TArray<class UInteractionPrerequisiteBase*>  Prerequisites;                                     // 0x50(0x10)
	TArray<struct FAdventureOnDemandVoyageSelectionVoyageProposalGroup> VoyageGroups;                                      // 0x60(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandVoyageSelectionCompanyDataAsset"));
		return Clss;
	}

};

// 0xD8 (0x100 - 0x28)
// Class AdventureOnDemandFramework.AdventureOnDemandTallTaleCategoryDataAsset
class UAdventureOnDemandTallTaleCategoryDataAsset : public UDataAsset
{
public:
	class FName                                  TaleId;                                            // 0x28(0x8)
	enum class ETallTaleCategory                 TaleCategory;                                      // 0x30(0x1)
	uint8                                        Pad_37DB[0x7];                                     // Fixing Size After Last Property
	TSubclassOf<class UQuestTableDiscoverTileCategory> DiscoverTileCategory;                              // 0x38(0x8)
	class FText                                  DisplayName;                                       // 0x40(0x38)
	class FText                                  Description;                                       // 0x78(0x38)
	struct FStringAssetReference                 BackgroundImageUrl;                                // 0xB0(0x10)
	struct FStringAssetReference                 IconImageUrl;                                      // 0xC0(0x10)
	TArray<class FText>                          LockedDescriptions;                                // 0xD0(0x10)
	TArray<class UInteractionPrerequisiteBase*>  Prerequisites;                                     // 0xE0(0x10)
	TArray<struct FAdventureOnDemandTallTaleProposalGroup> TallTales;                                         // 0xF0(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandTallTaleCategoryDataAsset"));
		return Clss;
	}

};

// 0x20 (0x48 - 0x28)
// Class AdventureOnDemandFramework.AdventureOnDemandDiscoveryPageMysteryDataAsset
class UAdventureOnDemandDiscoveryPageMysteryDataAsset : public UDataAsset
{
public:
	TArray<class UInteractionPrerequisiteBase*>  Prerequisites;                                     // 0x28(0x10)
	TArray<struct FAdventureOnDemandVoyageDiscoveryPageMysteryProposal> MysteryProposals;                                  // 0x38(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandDiscoveryPageMysteryDataAsset"));
		return Clss;
	}

};

// 0x28 (0x50 - 0x28)
// Class AdventureOnDemandFramework.AdventureOnDemandVoyageSelectionDataAsset
class UAdventureOnDemandVoyageSelectionDataAsset : public UDataAsset
{
public:
	class UAdventureOnDemandDiscoveryPageMysteryDataAsset* DiscoveryPageMysteryEntries;                       // 0x28(0x8)
	TArray<class UAdventureOnDemandVoyageSelectionCompanyDataAsset*> CompanyEntries;                                    // 0x30(0x10)
	TArray<class UAdventureOnDemandTallTaleCategoryDataAsset*> TallTales;                                         // 0x40(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandVoyageSelectionDataAsset"));
		return Clss;
	}

};

// 0x0 (0x98 - 0x98)
// Class AdventureOnDemandFramework.AdventureOnDemandDisplayHintPopUpStep
class UAdventureOnDemandDisplayHintPopUpStep : public UTaleQuestStep
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandDisplayHintPopUpStep"));
		return Clss;
	}

};

// 0x0 (0x80 - 0x80)
// Class AdventureOnDemandFramework.AdventureOnDemandDisplayHintPopUpStepDesc
class UAdventureOnDemandDisplayHintPopUpStepDesc : public UTaleQuestStepDesc
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandDisplayHintPopUpStepDesc"));
		return Clss;
	}

};

// 0x8 (0xA0 - 0x98)
// Class AdventureOnDemandFramework.AdventureOnDemandForceIslandBannerStep
class UAdventureOnDemandForceIslandBannerStep : public UTaleQuestStep
{
public:
	class UAdventureOnDemandForceIslandBannerStepDesc* StepDesc;                                          // 0x98(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandForceIslandBannerStep"));
		return Clss;
	}

};

// 0x8 (0x88 - 0x80)
// Class AdventureOnDemandFramework.AdventureOnDemandForceIslandBannerStepDesc
class UAdventureOnDemandForceIslandBannerStepDesc : public UTaleQuestStepDesc
{
public:
	bool                                         MuteBannerAudio;                                   // 0x80(0x1)
	uint8                                        Pad_37DC[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandForceIslandBannerStepDesc"));
		return Clss;
	}

};

// 0x0 (0x98 - 0x98)
// Class AdventureOnDemandFramework.AdventureOnDemandGetIsDivingToTunnelStep
class UAdventureOnDemandGetIsDivingToTunnelStep : public UTaleQuestStep
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandGetIsDivingToTunnelStep"));
		return Clss;
	}

};

// 0x30 (0xB0 - 0x80)
// Class AdventureOnDemandFramework.AdventureOnDemandGetIsDivingToTunnelStepDesc
class UAdventureOnDemandGetIsDivingToTunnelStepDesc : public UTaleQuestStepDesc
{
public:
	struct FQuestVariableBool                    IsCrewDivingToTunnel;                              // 0x80(0x30)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandGetIsDivingToTunnelStepDesc"));
		return Clss;
	}

};

// 0x0 (0x98 - 0x98)
// Class AdventureOnDemandFramework.AdventureOnDemandGetTunnelDescStep
class UAdventureOnDemandGetTunnelDescStep : public UTaleQuestStep
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandGetTunnelDescStep"));
		return Clss;
	}

};

// 0x30 (0xB0 - 0x80)
// Class AdventureOnDemandFramework.AdventureOnDemandGetTunnelDescStepDesc
class UAdventureOnDemandGetTunnelDescStepDesc : public UTaleQuestStepDesc
{
public:
	struct FQuestVariableDataAsset               TunnelDesc;                                        // 0x80(0x30)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandGetTunnelDescStepDesc"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AdventureOnDemandFramework.AdventureOnDemandServiceInterface
class UAdventureOnDemandServiceInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandServiceInterface"));
		return Clss;
	}

};

// 0x48 (0x70 - 0x28)
// Class AdventureOnDemandFramework.AdventureOnDemandServiceParams
class UAdventureOnDemandServiceParams : public UDataAsset
{
public:
	class UVoyageDescDataAsset*                  DiveToTunnelVoyageDesc;                            // 0x28(0x8)
	class UTunnelDesc*                           VoyageTunnelDesc;                                  // 0x30(0x8)
	class UVoyageDescDataAsset*                  LeaveTunnelVoyageDesc;                             // 0x38(0x8)
	TArray<struct FExtraSpawnDistanceFromIsland> ExtraSpawnDistanceFromIsland;                      // 0x40(0x10)
	float                                        WorldEventsCooldown;                               // 0x50(0x4)
	uint8                                        Pad_37DD[0x4];                                     // Fixing Size After Last Property
	class UGameEventsOnDemandBannerDataAsset*    GameEventsOnDemandBannerDataAsset;                 // 0x58(0x8)
	class UGameEventsOnDemandStatDataAsset*      GameEventsOnDemandStatDataAsset;                   // 0x60(0x8)
	TSubclassOf<class UCompany>                  HuntersCallCompany;                                // 0x68(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandServiceParams"));
		return Clss;
	}

};

// 0x0 (0x98 - 0x98)
// Class AdventureOnDemandFramework.AdventureOnDemandSetDirectionToApproachTargetFromStep
class UAdventureOnDemandSetDirectionToApproachTargetFromStep : public UTaleQuestStep
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandSetDirectionToApproachTargetFromStep"));
		return Clss;
	}

};

// 0x90 (0x110 - 0x80)
// Class AdventureOnDemandFramework.AdventureOnDemandSetDirectionToApproachTargetFromStepDesc
class UAdventureOnDemandSetDirectionToApproachTargetFromStepDesc : public UTaleQuestStepDesc
{
public:
	struct FQuestVariableVector                  DirectionToApproachTargetFrom;                     // 0x80(0x30)
	struct FQuestVariableVector                  PointOfInterestToGetDirectionToTargetFrom;         // 0xB0(0x30)
	struct FQuestVariableActor                   ActorToGetDirectionToTargetFrom;                   // 0xE0(0x30)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandSetDirectionToApproachTargetFromStepDesc"));
		return Clss;
	}

};

// 0x0 (0x98 - 0x98)
// Class AdventureOnDemandFramework.AdventureOnDemandSetHintPopUpStep
class UAdventureOnDemandSetHintPopUpStep : public UTaleQuestStep
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandSetHintPopUpStep"));
		return Clss;
	}

};

// 0x8 (0x88 - 0x80)
// Class AdventureOnDemandFramework.AdventureOnDemandSetHintPopUpStepDesc
class UAdventureOnDemandSetHintPopUpStepDesc : public UTaleQuestStepDesc
{
public:
	enum class EVoyagesPrioritisedPromptTutorialHintTypes HintType;                                          // 0x80(0x1)
	uint8                                        Pad_37DE[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandSetHintPopUpStepDesc"));
		return Clss;
	}

};

// 0x0 (0x98 - 0x98)
// Class AdventureOnDemandFramework.AdventureOnDemandSetTargetLocationStep
class UAdventureOnDemandSetTargetLocationStep : public UTaleQuestStep
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandSetTargetLocationStep"));
		return Clss;
	}

};

// 0xF0 (0x170 - 0x80)
// Class AdventureOnDemandFramework.AdventureOnDemandSetTargetLocationStepDesc
class UAdventureOnDemandSetTargetLocationStepDesc : public UTaleQuestStepDesc
{
public:
	struct FQuestVariableName                    IslandName;                                        // 0x80(0x30)
	struct FQuestVariableActor                   IslandData;                                        // 0xB0(0x30)
	struct FQuestVariableVector                  TargetLocation;                                    // 0xE0(0x30)
	struct FQuestVariableFloat                   RadiusFromTarget;                                  // 0x110(0x30)
	struct FQuestVariableFloat                   DefaultRadiusModifier;                             // 0x140(0x30)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandSetTargetLocationStepDesc"));
		return Clss;
	}

};

// 0x0 (0x98 - 0x98)
// Class AdventureOnDemandFramework.AdventureOnDemandSetTunnelDescStep
class UAdventureOnDemandSetTunnelDescStep : public UTaleQuestStep
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandSetTunnelDescStep"));
		return Clss;
	}

};

// 0x8 (0x88 - 0x80)
// Class AdventureOnDemandFramework.AdventureOnDemandSetTunnelDescStepDesc
class UAdventureOnDemandSetTunnelDescStepDesc : public UTaleQuestStepDesc
{
public:
	class UTunnelDesc*                           TunnelDesc;                                        // 0x80(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandSetTunnelDescStepDesc"));
		return Clss;
	}

};

// 0x8 (0xA0 - 0x98)
// Class AdventureOnDemandFramework.AdventureOnDemandSuppressIslandBannerStep
class UAdventureOnDemandSuppressIslandBannerStep : public UTaleQuestStep
{
public:
	class UAdventureOnDemandSuppressIslandBannerStepDesc* StepDesc;                                          // 0x98(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandSuppressIslandBannerStep"));
		return Clss;
	}

};

// 0x8 (0x88 - 0x80)
// Class AdventureOnDemandFramework.AdventureOnDemandSuppressIslandBannerStepDesc
class UAdventureOnDemandSuppressIslandBannerStepDesc : public UTaleQuestStepDesc
{
public:
	enum class EPOIRevelationSuppressionFlags    BannerSuppressionFlags;                            // 0x80(0x1)
	uint8                                        Pad_37DF[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandSuppressIslandBannerStepDesc"));
		return Clss;
	}

};

// 0x18 (0xB0 - 0x98)
// Class AdventureOnDemandFramework.AdventureOnDemandYieldQuestResumeOnConditionsTaleStep
class UAdventureOnDemandYieldQuestResumeOnConditionsTaleStep : public UTaleQuestStep
{
public:
	uint8                                        Pad_37E0[0x18];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandYieldQuestResumeOnConditionsTaleStep"));
		return Clss;
	}

};

// 0x0 (0x180 - 0x180)
// Class AdventureOnDemandFramework.AdventureOnDemandTaleFunctionLibrary
class UAdventureOnDemandTaleFunctionLibrary : public UTaleQuestFunctionStepLibrary
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandTaleFunctionLibrary"));
		return Clss;
	}

	bool CompareOnDemandQuestResumeConditionMetReason(enum class EOnDemandQuestResumeConditionMetReason Left, enum class EOnDemandQuestResumeConditionMetReason Right);
};

// 0x30 (0xB0 - 0x80)
// Class AdventureOnDemandFramework.AdventureOnDemandYieldQuestResumeOnConditionsStepDesc
class UAdventureOnDemandYieldQuestResumeOnConditionsStepDesc : public UTaleQuestStepDesc
{
public:
	struct FOnDemandQuestResumeConditionMetReasonQuestVariable OutConditionsMetReason;                            // 0x80(0x30)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AdventureOnDemandYieldQuestResumeOnConditionsStepDesc"));
		return Clss;
	}

};

// 0xF0 (0x118 - 0x28)
// Class AdventureOnDemandFramework.GameEventsOnDemandBannerDataAsset
class UGameEventsOnDemandBannerDataAsset : public UDataAsset
{
public:
	TArray<struct FGameEventOnDemandBannerTextData> GameEventSpecificBannerTextData;                   // 0x28(0x10)
	class FText                                  OnShipSunkBannerText;                              // 0x38(0x38)
	class FText                                  OnVoyageCancelledBannerText;                       // 0x70(0x38)
	class FText                                  OnCrewJoinedGameEventBannerHeaderText;             // 0xA8(0x38)
	class FText                                  OnCrewJoinedGameEventBannerMessageText;            // 0xE0(0x38)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("GameEventsOnDemandBannerDataAsset"));
		return Clss;
	}

};

// 0x10 (0x38 - 0x28)
// Class AdventureOnDemandFramework.GameEventsOnDemandStatDataAsset
class UGameEventsOnDemandStatDataAsset : public UDataAsset
{
public:
	TArray<struct FGameEventOnDemandCompanyStatData> CompletedEventStatsPerCompany;                     // 0x28(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("GameEventsOnDemandStatDataAsset"));
		return Clss;
	}

};

// 0x2C0 (0x2E8 - 0x28)
// Class AdventureOnDemandFramework.QuestTableAdventureOnDemandParams
class UQuestTableAdventureOnDemandParams : public UDataAsset
{
public:
	class ULootTeleportFilterDataAsset*          LootFilter;                                        // 0x28(0x8)
	TArray<class UInteractionPrerequisiteBase*>  NewPlayerTutorialPrerequisites;                    // 0x30(0x10)
	TArray<struct FQuestTableCompanyTutorialPrerequisites> NewPlayerCompanyTutorialPrerequisites;             // 0x40(0x10)
	struct FQuestTableBakedInfoDiscoverTile      NewPlayerTutorialDiscoverTabTile;                  // 0x50(0x148)
	struct FStringAssetReference                 EmptyCompanyRequirementImageUrl;                   // 0x198(0x10)
	class FText                                  SailToQuestText_Default;                           // 0x1A8(0x38)
	class FText                                  SailToQuestText_BlockedDueToWorldEvent;            // 0x1E0(0x38)
	class FText                                  DiveToQuestText_Default;                           // 0x218(0x38)
	class FText                                  DiveToQuestText_BlockedDueToTutorial;              // 0x250(0x38)
	class FText                                  DiveToQuestText_BlockedDueToCooldown;              // 0x288(0x38)
	class UQuestTableDiscoverTabData*            DiscoverTabData;                                   // 0x2C0(0x8)
	TSubclassOf<class UQuestTableDiscoverTileCategory> InfoDiscoverTileCategory;                          // 0x2C8(0x8)
	TSubclassOf<class UQuestTableDiscoverTileCategory> LimitedInfoDiscoverTileCategory;                   // 0x2D0(0x8)
	TArray<struct FQuestTableBakedQuestDiscoverTile> BakedQuestDiscoverTiles;                           // 0x2D8(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("QuestTableAdventureOnDemandParams"));
		return Clss;
	}

};

// 0x0 (0x90 - 0x90)
// Class AdventureOnDemandFramework.WantsToDivePrerequisite
class UWantsToDivePrerequisite : public UInteractionPrerequisiteBase
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("WantsToDivePrerequisite"));
		return Clss;
	}

};

}


