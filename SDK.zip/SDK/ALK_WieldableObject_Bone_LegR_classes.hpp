#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x28 - 0x28)
// BlueprintGeneratedClass ALK_WieldableObject_Bone_LegR.ALK_WieldableObject_Bone_LegR_C
class UALK_WieldableObject_Bone_LegR_C : public UWieldableItemAnimationStoreId
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ALK_WieldableObject_Bone_LegR_C"));
		return Clss;
	}

};

}


