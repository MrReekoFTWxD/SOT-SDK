#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// ENUMS
//---------------------------------------------------------------------------------------------------------------------

enum class ECannonballIconType : uint8
{
	Normal                         = 0,
	Anchor                         = 1,
	Ballast                        = 2,
	Barrel                         = 3,
	Boogie                         = 4,
	Grog                           = 5,
	Limp                           = 6,
	Passive                        = 7,
	Rigging                        = 8,
	Rudder                         = 9,
	Silence                        = 10,
	Snake                          = 11,
	Snooze                         = 12,
	None                           = 13,
	Max                            = 14,
	ECannonballIconType_MAX        = 15,
};

enum class ESkellyFormIconType : uint8
{
	Normal                         = 0,
	Metal                          = 1,
	Plant                          = 2,
	Shadow                         = 3,
	None                           = 4,
	Max                            = 5,
	ESkellyFormIconType_MAX        = 6,
};

enum class EAIShipEncounterType : uint8
{
	Battle                         = 0,
	Passive                        = 1,
	Aggressive                     = 2,
	MAX                            = 3,
	EAIShipEncounterType_MAX       = 4,
};

enum class EAIShipType : uint8
{
	Normal                         = 0,
	Hard                           = 1,
	EAIShipType_MAX                = 2,
};

enum class EAIShipPlayerTrackerType : uint8
{
	DefaultRadiusTracker           = 0,
	CannonRadiusTracker            = 1,
	OnShipTracker                  = 2,
	BelowDeckOfShipTracker         = 3,
	EAIShipPlayerTrackerType_MAX   = 4,
};


//---------------------------------------------------------------------------------------------------------------------
// STRUCTS
//---------------------------------------------------------------------------------------------------------------------

// 0x50 (0x50 - 0x0)
// ScriptStruct AIShips.AIShipBattleParams
struct FAIShipBattleParams
{
public:
	class FText                                  Name;                                              // 0x0(0x38)
	TSubclassOf<class USeaId>                    SeaId;                                             // 0x38(0x8)
	struct FVector2D                             Location;                                          // 0x40(0x8)
	float                                        Radius;                                            // 0x48(0x4)
	uint8                                        Pad_33E5[0x4];                                     // Fixing Size Of Struct
};

// 0x38 (0x38 - 0x0)
// ScriptStruct AIShips.ShipMovementParams
struct FShipMovementParams
{
public:
	float                                        MinTargetDistanceForMovement;                      // 0x0(0x4)
	float                                        MaxTurnAngle;                                      // 0x4(0x4)
	float                                        MaxTurnAngleForObstacleAvoidance;                  // 0x8(0x4)
	float                                        MaxTurnAngleForPlayerShipObstacleAvoidance;        // 0xC(0x4)
	float                                        MinTurnSpeedScaler;                                // 0x10(0x4)
	float                                        MaxSpeed;                                          // 0x14(0x4)
	float                                        MinSpeed;                                          // 0x18(0x4)
	float                                        TimeToAccelerateFromZeroToMaxSpeed;                // 0x1C(0x4)
	float                                        TimeToAccelerateFromZeroToMaxTurnSpeed;            // 0x20(0x4)
	float                                        MoveBackwardsAngleThreshold;                       // 0x24(0x4)
	float                                        MoveBackwardsDistanceThreshold;                    // 0x28(0x4)
	float                                        MoveBackwardsShipSpeedThreshold;                   // 0x2C(0x4)
	float                                        MaxObstacleAvoidanceOverrideDistance;              // 0x30(0x4)
	float                                        ShipHalfLength;                                    // 0x34(0x4)
};

// 0x18 (0x18 - 0x0)
// ScriptStruct AIShips.TrackingNoiseGenerator
struct FTrackingNoiseGenerator
{
public:
	class UCurveFloat*                           ParallelOffsetCurve;                               // 0x0(0x8)
	float                                        OscillationTime;                                   // 0x8(0x4)
	uint8                                        Pad_33E6[0xC];                                     // Fixing Size Of Struct
};

// 0x18 (0x18 - 0x0)
// ScriptStruct AIShips.AIShipCrewAmmoType
struct FAIShipCrewAmmoType
{
public:
	enum class ECannonballIconType               IconType;                                          // 0x0(0x1)
	int8                                         IconIndex;                                         // 0x1(0x1)
	uint8                                        Pad_33E7[0x6];                                     // Fixing Size After Last Property
	struct FStringAssetReference                 AmmoType;                                          // 0x8(0x10)
};

// 0x30 (0x30 - 0x0)
// ScriptStruct AIShips.WeightedAIShipCrewAmmoType
struct FWeightedAIShipCrewAmmoType
{
public:
	int32                                        Weight;                                            // 0x0(0x4)
	uint8                                        Pad_33E8[0x4];                                     // Fixing Size After Last Property
	struct FAIShipCrewAmmoType                   Params;                                            // 0x8(0x18)
	struct FFeatureFlag                          FeatureFlag;                                       // 0x20(0xC)
	uint8                                        Pad_33E9[0x4];                                     // Fixing Size Of Struct
};

// 0x20 (0x20 - 0x0)
// ScriptStruct AIShips.AIShipCrewFormType
struct FAIShipCrewFormType
{
public:
	enum class ESkellyFormIconType               IconType;                                          // 0x0(0x1)
	uint8                                        Pad_33EA[0x3];                                     // Fixing Size After Last Property
	struct FColor                                IconColour;                                        // 0x4(0x4)
	int8                                         IconIndex;                                         // 0x8(0x1)
	int8                                         CaptainIconIndex;                                  // 0x9(0x1)
	uint8                                        Pad_33EB[0x6];                                     // Fixing Size After Last Property
	struct FStringAssetReference                 Form;                                              // 0x10(0x10)
};

// 0x28 (0x28 - 0x0)
// ScriptStruct AIShips.WeightedAIShipCrewFormType
struct FWeightedAIShipCrewFormType
{
public:
	int32                                        Weight;                                            // 0x0(0x4)
	uint8                                        Pad_33EC[0x4];                                     // Fixing Size After Last Property
	struct FAIShipCrewFormType                   Params;                                            // 0x8(0x20)
};

// 0x14 (0x14 - 0x0)
// ScriptStruct AIShips.AIShipContextDescDamageParams
struct FAIShipContextDescDamageParams
{
public:
	float                                        OverrideRainFillRate;                              // 0x0(0x4)
	bool                                         OverrideRepairTime;                                // 0x4(0x1)
	uint8                                        Pad_33ED[0x3];                                     // Fixing Size After Last Property
	float                                        RepairTimeMultiplier;                              // 0x8(0x4)
	bool                                         OverrideLeakAmounts;                               // 0xC(0x1)
	uint8                                        Pad_33EE[0x3];                                     // Fixing Size After Last Property
	float                                        LeakAmountMultiplier;                              // 0x10(0x4)
};

// 0x10 (0x10 - 0x0)
// ScriptStruct AIShips.AIShipSailData
struct FAIShipSailData
{
public:
	struct FColor                                SailRGB;                                           // 0x0(0x4)
	struct FColor                                IconRGB;                                           // 0x4(0x4)
	int32                                        CrewIndex;                                         // 0x8(0x4)
	int32                                        CursedCannonballIndex;                             // 0xC(0x4)
};

// 0x20 (0x20 - 0x0)
// ScriptStruct AIShips.AIShipEncounterParamsSpawnerData
struct FAIShipEncounterParamsSpawnerData
{
public:
	class UAISpawner*                            Spawner;                                           // 0x0(0x8)
	class FName                                  SpawnLocationType;                                 // 0x8(0x8)
	enum class EAIShipPlayerTrackerType          ShipPlayerTrackerType;                             // 0x10(0x1)
	uint8                                        Pad_33EF[0x3];                                     // Fixing Size After Last Property
	class FName                                  CaptainName;                                       // 0x14(0x8)
	bool                                         CanRepairDamage;                                   // 0x1C(0x1)
	bool                                         CanUseCannons;                                     // 0x1D(0x1)
	bool                                         IsCaptain;                                         // 0x1E(0x1)
	bool                                         BelowDeck;                                         // 0x1F(0x1)
};

// 0x10 (0x10 - 0x0)
// ScriptStruct AIShips.AIShipEncounterWave
struct FAIShipEncounterWave
{
public:
	TArray<class UAIShipContextDescDataAsset*>   AIShipsInWave;                                     // 0x0(0x10)
};

// 0x10 (0x10 - 0x0)
// ScriptStruct AIShips.AIShipCaptainParams
struct FAIShipCaptainParams
{
public:
	TSubclassOf<class UAIClassId>                AIClassId;                                         // 0x0(0x8)
	class FName                                  Name;                                              // 0x8(0x8)
};

// 0x60 (0x60 - 0x0)
// ScriptStruct AIShips.AIShipContextDescGenerationSharedParams
struct FAIShipContextDescGenerationSharedParams
{
public:
	TArray<enum class EAIShipEncounterType>      EncounterTypes;                                    // 0x0(0x10)
	TArray<struct FWeightedAIShipCrewFormType>   SkeletonForms;                                     // 0x10(0x10)
	TArray<struct FWeightedAIShipCrewAmmoType>   SkeletonAmmoTypes;                                 // 0x20(0x10)
	TArray<struct FColor>                        SailColours;                                       // 0x30(0x10)
	TArray<struct FAIShipCaptainParams>          Captains;                                          // 0x40(0x10)
	TArray<TSubclassOf<class UAIClassId>>        CaptainGenders;                                    // 0x50(0x10)
};

// 0x18 (0x18 - 0x0)
// ScriptStruct AIShips.AIShipSkeletonSkillsetOverride
struct FAIShipSkeletonSkillsetOverride
{
public:
	class FName                                  SpawnLocationType;                                 // 0x0(0x8)
	struct FStringAssetReference                 Skillset;                                          // 0x8(0x10)
};

// 0x48 (0x48 - 0x0)
// ScriptStruct AIShips.AIShipGenerationParams
struct FAIShipGenerationParams
{
public:
	enum class EAIShipEncounterType              EncounterType;                                     // 0x0(0x1)
	enum class EAIShipType                       ShipType;                                          // 0x1(0x1)
	uint8                                        Pad_33F0[0x6];                                     // Fixing Size After Last Property
	class UAthenaAIShipControllerParamsDataAsset* ShipControllerParams;                              // 0x8(0x8)
	TArray<struct FAIShipSkeletonSkillsetOverride> SkillsetOverrides;                                 // 0x10(0x10)
	TArray<struct FWeightedAIShipCrewAmmoType>   SkeletonAmmoTypeOverrides;                         // 0x20(0x10)
	struct FAIShipContextDescDamageParams        DamageParams;                                      // 0x30(0x14)
	uint8                                        Pad_33F1[0x4];                                     // Fixing Size Of Struct
};

// 0x30 (0x30 - 0x0)
// ScriptStruct AIShips.AIShipContextDescGenerationShipSpecificParams
struct FAIShipContextDescGenerationShipSpecificParams
{
public:
	TSubclassOf<class UShipSize>                 ShipSize;                                          // 0x0(0x8)
	class UShipDescAsset*                        ShipDesc;                                          // 0x8(0x8)
	TArray<struct FAIShipGenerationParams>       ShipGenerationParams;                              // 0x10(0x10)
	TArray<struct FAIShipEncounterParamsSpawnerData> SpawnerTemplates;                                  // 0x20(0x10)
};

// 0x80 (0x80 - 0x0)
// ScriptStruct AIShips.AIShipContextDescGenerationParams
struct FAIShipContextDescGenerationParams
{
public:
	struct FAIShipContextDescGenerationSharedParams SharedParams;                                      // 0x0(0x60)
	TArray<struct FAIShipContextDescGenerationSharedParams> EncounterSpecificParams;                           // 0x60(0x10)
	TArray<struct FAIShipContextDescGenerationShipSpecificParams> ShipSpecificParams;                                // 0x70(0x10)
};

// 0x18 (0x18 - 0x0)
// ScriptStruct AIShips.AIShipSizeDynamicContexts
struct FAIShipSizeDynamicContexts
{
public:
	TSubclassOf<class UShipSize>                 ShipSize;                                          // 0x0(0x8)
	TArray<class UAIShipContextDescDataAsset*>   AIShipsInPool;                                     // 0x8(0x10)
};

// 0x18 (0x18 - 0x0)
// ScriptStruct AIShips.AIShipWeightedSize
struct FAIShipWeightedSize
{
public:
	class FName                                  Feature;                                           // 0x0(0x8)
	int32                                        Weight;                                            // 0x8(0x4)
	uint8                                        Pad_33F2[0x4];                                     // Fixing Size After Last Property
	TSubclassOf<class UShipSize>                 ShipSize;                                          // 0x10(0x8)
};

// 0x18 (0x18 - 0x0)
// ScriptStruct AIShips.AIShipClassWeightedSizes
struct FAIShipClassWeightedSizes
{
public:
	TSubclassOf<class UShipSize>                 TargetShipSize;                                    // 0x0(0x8)
	TArray<struct FAIShipWeightedSize>           ShipSizes;                                         // 0x8(0x10)
};

// 0x10 (0x10 - 0x0)
// ScriptStruct AIShips.AIShipSingleWaveEncounterDescGenerationParams
struct FAIShipSingleWaveEncounterDescGenerationParams
{
public:
	TArray<struct FAIShipClassWeightedSizes>     ShipClassWeightedSizes;                            // 0x0(0x10)
};

// 0x10 (0x10 - 0x0)
// ScriptStruct AIShips.AIShipSizeLimit
struct FAIShipSizeLimit
{
public:
	TSubclassOf<class UShipSize>                 ShipSize;                                          // 0x0(0x8)
	int32                                        MaxInstances;                                      // 0x8(0x4)
	uint8                                        Pad_33F3[0x4];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// ScriptStruct AIShips.AIShipEncounterWaveDesc
struct FAIShipEncounterWaveDesc
{
public:
	TArray<TSubclassOf<class UShipSize>>         ShipSizes;                                         // 0x0(0x10)
};

// 0x60 (0x60 - 0x0)
// ScriptStruct AIShips.AIShipEncounterBattleGenerationParams
struct FAIShipEncounterBattleGenerationParams
{
public:
	TSubclassOf<class UShipSize>                 HardShipType;                                      // 0x0(0x8)
	struct FWeightedProbabilityRange             NumberOfWaves;                                     // 0x8(0x20)
	struct FInt32Range                           MinMaxNumberOfShips;                               // 0x28(0x10)
	int32                                        MinNumberOfShipsInFinalWave;                       // 0x38(0x4)
	uint8                                        Pad_33F4[0x4];                                     // Fixing Size After Last Property
	TArray<struct FAIShipSizeLimit>              ShipSizeLimits;                                    // 0x40(0x10)
	TArray<struct FAIShipEncounterWaveDesc>      WaveConfigurations;                                // 0x50(0x10)
};

// 0x78 (0x78 - 0x0)
// ScriptStruct AIShips.FeatureLockedAIShipEncounterBattleGenerationParams
struct FFeatureLockedAIShipEncounterBattleGenerationParams
{
public:
	class FName                                  Feature;                                           // 0x0(0x8)
	struct FAIShipEncounterBattleGenerationParams Params;                                            // 0x8(0x60)
	uint8                                        Pad_33F5[0x10];                                    // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// ScriptStruct AIShips.AIShipEncounterBattleDesc
struct FAIShipEncounterBattleDesc
{
public:
	TArray<struct FAIShipEncounterWaveDesc>      WaveDescs;                                         // 0x0(0x10)
};

// 0x10 (0x10 - 0x0)
// ScriptStruct AIShips.AIShipEncounterDynamicBalancingPlayerShipValueDesc
struct FAIShipEncounterDynamicBalancingPlayerShipValueDesc
{
public:
	TSubclassOf<class UShipSize>                 ShipSize;                                          // 0x0(0x8)
	int32                                        ShipValue;                                         // 0x8(0x4)
	uint8                                        Pad_33F6[0x4];                                     // Fixing Size Of Struct
};

// 0x18 (0x18 - 0x0)
// ScriptStruct AIShips.AIShipEncounterDynamicBalancingWaveConfigCostDesc
struct FAIShipEncounterDynamicBalancingWaveConfigCostDesc
{
public:
	TArray<TSubclassOf<class UShipSize>>         ShipSizes;                                         // 0x0(0x10)
	int32                                        WaveCost;                                          // 0x10(0x4)
	uint8                                        Pad_33F7[0x4];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// ScriptStruct AIShips.AIShipEncounterDynamicBalancingCrewStrengthToTargetWaveDesc
struct FAIShipEncounterDynamicBalancingCrewStrengthToTargetWaveDesc
{
public:
	int32                                        MinCrewStrength;                                   // 0x0(0x4)
	int32                                        MinWaveStrength;                                   // 0x4(0x4)
	int32                                        MaxWaveStrength;                                   // 0x8(0x4)
	int32                                        WaveCountIncrement;                                // 0xC(0x4)
};

// 0x10 (0x10 - 0x0)
// ScriptStruct AIShips.AIShipEncounterDynamicBalancingPoolSizeDesc
struct FAIShipEncounterDynamicBalancingPoolSizeDesc
{
public:
	TSubclassOf<class UShipSize>                 ShipSize;                                          // 0x0(0x8)
	int32                                        PoolSize;                                          // 0x8(0x4)
	uint8                                        Pad_33F8[0x4];                                     // Fixing Size Of Struct
};

// 0x58 (0x58 - 0x0)
// ScriptStruct AIShips.AIShipEncounterDynamicBalancingDesc
struct FAIShipEncounterDynamicBalancingDesc
{
public:
	bool                                         UseDynamicBalancing;                               // 0x0(0x1)
	uint8                                        Pad_33F9[0x3];                                     // Fixing Size After Last Property
	float                                        InitialWaveGenEncounterRadiusMultiplier;           // 0x4(0x4)
	TSubclassOf<class UShipSize>                 HardShipType;                                      // 0x8(0x8)
	TArray<struct FAIShipEncounterDynamicBalancingPlayerShipValueDesc> PlayerShipSizeValues;                              // 0x10(0x10)
	int32                                        PlayerValue;                                       // 0x20(0x4)
	uint8                                        Pad_33FA[0x4];                                     // Fixing Size After Last Property
	TArray<struct FAIShipEncounterDynamicBalancingWaveConfigCostDesc> DynamicWaveCostConfigurations;                     // 0x28(0x10)
	TArray<struct FAIShipEncounterDynamicBalancingCrewStrengthToTargetWaveDesc> PlayerCrewStrengthTargetWaveMapping;               // 0x38(0x10)
	TArray<struct FAIShipEncounterDynamicBalancingPoolSizeDesc> DynamicShipSizePools;                              // 0x48(0x10)
};

// 0x80 (0x80 - 0x0)
// ScriptStruct AIShips.AIShipBattleEncounterDescGenerationParams
struct FAIShipBattleEncounterDescGenerationParams
{
public:
	bool                                         EnableHardShip;                                    // 0x0(0x1)
	uint8                                        Pad_33FB[0x7];                                     // Fixing Size After Last Property
	TArray<struct FFeatureLockedAIShipEncounterBattleGenerationParams> BattleGenerationParams;                            // 0x8(0x10)
	TArray<struct FAIShipEncounterBattleDesc>    BattleDescs;                                       // 0x18(0x10)
	struct FAIShipEncounterDynamicBalancingDesc  DynamicBalancingDesc;                              // 0x28(0x58)
};

// 0x40 (0x40 - 0x0)
// ScriptStruct AIShips.WeightedSpawnOffset
struct FWeightedSpawnOffset
{
public:
	float                                        MinSpawnDistance;                                  // 0x0(0x4)
	float                                        MaxSpawnDistance;                                  // 0x4(0x4)
	float                                        Weight;                                            // 0x8(0x4)
	uint8                                        Pad_33FC[0x4];                                     // Fixing Size After Last Property
	struct FWeightedProbabilityRangeOfRanges     SpawnRotations;                                    // 0x10(0x30)
};

// 0xB0 (0xB0 - 0x0)
// ScriptStruct AIShips.WeightedSpawnDirection
struct FWeightedSpawnDirection
{
public:
	float                                        DirectionAngle;                                    // 0x0(0x4)
	float                                        DirectionWidth;                                    // 0x4(0x4)
	float                                        Weight;                                            // 0x8(0x4)
	uint8                                        Pad_33FD[0x4];                                     // Fixing Size After Last Property
	TArray<struct FWeightedSpawnOffset>          SpawnOffsets;                                      // 0x10(0x10)
	uint8                                        Pad_33FE[0x90];                                    // Fixing Size Of Struct
};

// 0xA0 (0xA0 - 0x0)
// ScriptStruct AIShips.RelativeSpawnLocationGeneratorParams
struct FRelativeSpawnLocationGeneratorParams
{
public:
	TArray<struct FWeightedSpawnDirection>       SpawnDirections;                                   // 0x0(0x10)
	uint8                                        Pad_33FF[0x90];                                    // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// ScriptStruct AIShips.ShipTypeAIShipEncounterParams
struct FShipTypeAIShipEncounterParams
{
public:
	TSubclassOf<class UShipSize>                 ShipSize;                                          // 0x0(0x8)
	class UAIShipEncounterParamsDataAsset*       Params;                                            // 0x8(0x8)
};

// 0x28 (0x28 - 0x0)
// ScriptStruct AIShips.AIShipEncounterParams
struct FAIShipEncounterParams
{
public:
	int32                                        SaferSeasRollChance;                               // 0x0(0x4)
	float                                        MinEngagedDistanceFromPlayers;                     // 0x4(0x4)
	class FString                                MinEngagedDistanceFromPlayersRemoteConfigKey;      // 0x8(0x10)
	TArray<struct FShipTypeAIShipEncounterParams> ShipTypeParams;                                    // 0x18(0x10)
};

// 0x10 (0x10 - 0x0)
// ScriptStruct AIShips.EventTypeAIShipEncounterParams
struct FEventTypeAIShipEncounterParams
{
public:
	TSubclassOf<class UGameEventType>            EventType;                                         // 0x0(0x8)
	class UAIShipEncounterParamsDataAsset*       Params;                                            // 0x8(0x8)
};

// 0x18 (0x18 - 0x0)
// ScriptStruct AIShips.ToggleableAIShipsServiceDataAssetFileLocation
struct FToggleableAIShipsServiceDataAssetFileLocation
{
public:
	class FName                                  ToggleName;                                        // 0x0(0x8)
	struct FStringAssetReference                 Location;                                          // 0x8(0x10)
};

// 0x80 (0x80 - 0x0)
// ScriptStruct AIShips.CursedSailsBattleParams
struct FCursedSailsBattleParams
{
public:
	class FText                                  Name;                                              // 0x0(0x38)
	class FText                                  SkellyCrewName;                                    // 0x38(0x38)
	enum class ECannonballIconType               CannonBallType;                                    // 0x70(0x1)
	enum class ESkellyFormIconType               SkellyType;                                        // 0x71(0x1)
	uint8                                        Pad_3400[0x6];                                     // Fixing Size After Last Property
	class UAIShipEncounterDesc*                  EncounterDescription;                              // 0x78(0x8)
};

// 0x18 (0x18 - 0x0)
// ScriptStruct AIShips.AIShipEncounterDynamicWaveShipSpawnedTelemetryEvent
struct FAIShipEncounterDynamicWaveShipSpawnedTelemetryEvent
{
public:
	struct FGuid                                 EncounterId;                                       // 0x0(0x10)
	int32                                        WaveIndex;                                         // 0x10(0x4)
	float                                        TimeToSpawn;                                       // 0x14(0x4)
};

// 0x1C (0x1C - 0x0)
// ScriptStruct AIShips.AIShipEncounterDynamicWaveTelemetryEvent
struct FAIShipEncounterDynamicWaveTelemetryEvent
{
public:
	struct FGuid                                 EncounterId;                                       // 0x0(0x10)
	int32                                        WaveIndex;                                         // 0x10(0x4)
	int32                                        CrewStrength;                                      // 0x14(0x4)
	int32                                        WaveCost;                                          // 0x18(0x4)
};

// 0x48 (0x48 - 0x0)
// ScriptStruct AIShips.AIShipDamagedTelemetryEvent
struct FAIShipDamagedTelemetryEvent
{
public:
	class FString                                DamageType;                                        // 0x0(0x10)
	struct FVector                               DamageLocation;                                    // 0x10(0xC)
	uint8                                        Pad_3401[0x4];                                     // Fixing Size After Last Property
	class FString                                DamagedShipPart;                                   // 0x20(0x10)
	int32                                        DamageLevel;                                       // 0x30(0x4)
	struct FGuid                                 AttackId;                                          // 0x34(0x10)
	uint8                                        Pad_3402[0x4];                                     // Fixing Size Of Struct
};

// 0x18 (0x18 - 0x0)
// ScriptStruct AIShips.AIShipDespawnTelemetryEvent
struct FAIShipDespawnTelemetryEvent
{
public:
	class FString                                AIShipId;                                          // 0x0(0x10)
	enum class EAIShipDestructionReason          AIShipDestructionReason;                           // 0x10(0x1)
	uint8                                        Pad_3403[0x7];                                     // Fixing Size Of Struct
};

// 0x70 (0x70 - 0x0)
// ScriptStruct AIShips.AIShipSpawnTelemetryEvent
struct FAIShipSpawnTelemetryEvent
{
public:
	class FString                                AIShipId;                                          // 0x0(0x10)
	class FString                                SpawningCrewId;                                    // 0x10(0x10)
	class FString                                AIShipBattleId;                                    // 0x20(0x10)
	class FString                                AIShipType;                                        // 0x30(0x10)
	struct FGuid                                 SpawnConfigId;                                     // 0x40(0x10)
	class FString                                AIShipSize;                                        // 0x50(0x10)
	struct FVector                               SpawnLocation;                                     // 0x60(0xC)
	int32                                        AIShipWaveIndex;                                   // 0x6C(0x4)
};

}


