#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// ENUMS
//---------------------------------------------------------------------------------------------------------------------

enum class EActorLayerOwnership : uint8
{
	Internal                       = 0,
	External                       = 1,
	EActorLayerOwnership_MAX       = 2,
};

enum class EActorLayerState : uint8
{
	Inactive                       = 0,
	Active                         = 1,
	Loading                        = 2,
	EActorLayerState_MAX           = 3,
};


//---------------------------------------------------------------------------------------------------------------------
// STRUCTS
//---------------------------------------------------------------------------------------------------------------------

// 0x48 (0x48 - 0x0)
// ScriptStruct ActorLayers.InstancedLayer
struct FInstancedLayer
{
public:
	class ULayerActorsDataAsset*                 LayerActors;                                       // 0x0(0x8)
	TArray<struct FTransform>                    ActorTransforms;                                   // 0x8(0x10)
	TArray<class AActor*>                        SpawnedActors;                                     // 0x18(0x10)
	uint8                                        Pad_30ED[0x20];                                    // Fixing Size Of Struct
};

}


