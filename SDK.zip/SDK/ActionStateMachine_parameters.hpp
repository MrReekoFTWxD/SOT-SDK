#pragma once


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x60 (0x60 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponent.Server_RequestActionWithMessageForCurrentState
struct UActionStateMachineComponent_Server_RequestActionWithMessageForCurrentState_Params
{
public:
	struct FActionStateChangeRequestId           InEpochId;                                         // 0x0(0x1)
	struct FActionStateChangeRequestId           InRequestId;                                       // 0x1(0x1)
	uint8                                        Pad_2903[0x6];                                     // Fixing Size After Last Property
	struct FSerialisedActionStateInfo            InSerialisedActionStateConstructionInfo;           // 0x8(0x40)
	struct FSerialisedActionStateMessage         InSerialisedPreviousStateMessage;                  // 0x48(0x18)
};

// 0x50 (0x50 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponent.Server_RequestAction
struct UActionStateMachineComponent_Server_RequestAction_Params
{
public:
	struct FActionStateChangeRequestId           InEpochId;                                         // 0x0(0x1)
	struct FActionStateChangeRequestId           InRequestId;                                       // 0x1(0x1)
	uint8                                        Pad_2904[0x6];                                     // Fixing Size After Last Property
	struct FSerialisedActionStateInfo            InSerialisedActionStateConstructionInfo;           // 0x8(0x40)
	enum class EActionPredictionType             ClientPredicted;                                   // 0x48(0x1)
	uint8                                        Pad_2905[0x7];                                     // Fixing Size Of Struct
};

// 0x0 (0x0 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponent.PostNetInit
struct UActionStateMachineComponent_PostNetInit_Params
{
public:
};

// 0x0 (0x0 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponent.OnNetOwnershipChanged
struct UActionStateMachineComponent_OnNetOwnershipChanged_Params
{
public:
};

// 0x48 (0x48 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponent.Multicast_PushSerialisableData
struct UActionStateMachineComponent_Multicast_PushSerialisableData_Params
{
public:
	struct FActionStateChangeRequestId           InEpochId;                                         // 0x0(0x1)
	uint8                                        Pad_2906[0x7];                                     // Fixing Size After Last Property
	struct FSerialisedActionStateInfo            InSerialisedActionStateSerialisationStateInfo;     // 0x8(0x40)
};

// 0x48 (0x48 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponent.Multicast_PushActionFromRequest
struct UActionStateMachineComponent_Multicast_PushActionFromRequest_Params
{
public:
	struct FActionStateChangeRequestId           InEpochId;                                         // 0x0(0x1)
	uint8                                        Pad_2907[0x7];                                     // Fixing Size After Last Property
	struct FSerialisedActionStateInfo            InSerialisedActionStateConstructionInfo;           // 0x8(0x40)
};

// 0x48 (0x48 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponent.Multicast_PushAction
struct UActionStateMachineComponent_Multicast_PushAction_Params
{
public:
	struct FActionStateChangeRequestId           InEpochId;                                         // 0x0(0x1)
	uint8                                        Pad_2908[0x7];                                     // Fixing Size After Last Property
	struct FSerialisedActionStateInfo            InSerialisedActionStateConstructionInfo;           // 0x8(0x40)
};

// 0x0 (0x0 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponent.End
struct UActionStateMachineComponent_End_Params
{
public:
};

// 0x150 (0x150 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponent.Client_ResetStateMachine
struct UActionStateMachineComponent_Client_ResetStateMachine_Params
{
public:
	struct FResetStateMachineRpc                 Rpc;                                               // 0x0(0x150)
};

// 0x48 (0x48 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponent.Client_CorrectAction
struct UActionStateMachineComponent_Client_CorrectAction_Params
{
public:
	struct FActionStateChangeRequestId           InEpochId;                                         // 0x0(0x1)
	struct FActionStateChangeRequestId           InRequestId;                                       // 0x1(0x1)
	uint8                                        Pad_2909[0x6];                                     // Fixing Size After Last Property
	struct FSerialisedActionStateInfo            InSerialisedActionStateConstructionInfo;           // 0x8(0x40)
};

// 0x18 (0x18 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.SetTestStateValidatorThatAlwaysPassesExceptForId
struct UActionStateMachineComponentTestFunctions_SetTestStateValidatorThatAlwaysPassesExceptForId_Params
{
public:
	class UActionStateMachineComponent*          InComponent;                                       // 0x0(0x8)
	TSubclassOf<class UActionStateId>            StateId;                                           // 0x8(0x8)
	bool                                         ReturnValue;                                       // 0x10(0x1)
	uint8                                        Pad_290F[0x7];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.SetTestStateValidatorThatAlwaysPasses
struct UActionStateMachineComponentTestFunctions_SetTestStateValidatorThatAlwaysPasses_Params
{
public:
	class UActionStateMachineComponent*          InComponent;                                       // 0x0(0x8)
	bool                                         ReturnValue;                                       // 0x8(0x1)
	uint8                                        Pad_2910[0x7];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.SetTestStateValidatorThatAlwaysFails
struct UActionStateMachineComponentTestFunctions_SetTestStateValidatorThatAlwaysFails_Params
{
public:
	class UActionStateMachineComponent*          InComponent;                                       // 0x0(0x8)
	bool                                         ReturnValue;                                       // 0x8(0x1)
	uint8                                        Pad_2911[0x7];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.SetTestStateFactoryChangeToNullOnUpdate
struct UActionStateMachineComponentTestFunctions_SetTestStateFactoryChangeToNullOnUpdate_Params
{
public:
	class UActionStateMachineComponent*          InComponent;                                       // 0x0(0x8)
	bool                                         ReturnValue;                                       // 0x8(0x1)
	uint8                                        Pad_2912[0x7];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.SetTestStateFactory
struct UActionStateMachineComponentTestFunctions_SetTestStateFactory_Params
{
public:
	class UActionStateMachineComponent*          InComponent;                                       // 0x0(0x8)
	bool                                         ReturnValue;                                       // 0x8(0x1)
	uint8                                        Pad_2913[0x7];                                     // Fixing Size Of Struct
};

// 0x18 (0x18 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.SetCustomClientValidationTestStateFactory
struct UActionStateMachineComponentTestFunctions_SetCustomClientValidationTestStateFactory_Params
{
public:
	class UActionStateMachineComponent*          InComponent;                                       // 0x0(0x8)
	class UCustomClientValidityCheckCallback*    InCallback;                                        // 0x8(0x8)
	bool                                         ReturnValue;                                       // 0x10(0x1)
	uint8                                        Pad_2914[0x7];                                     // Fixing Size Of Struct
};

// 0x28 (0x28 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.RequestUnpredictedTestActionStateWithIdOnTrack
struct UActionStateMachineComponentTestFunctions_RequestUnpredictedTestActionStateWithIdOnTrack_Params
{
public:
	class UActionStateMachineComponent*          InComponent;                                       // 0x0(0x8)
	enum class EActionStateMachineTrackId        TrackId;                                           // 0x8(0x1)
	uint8                                        Pad_2915[0x7];                                     // Fixing Size After Last Property
	TSubclassOf<class UActionStateId>            ClientStateId;                                     // 0x10(0x8)
	TSubclassOf<class UActionStateId>            ServerStateId;                                     // 0x18(0x8)
	bool                                         ReturnValue;                                       // 0x20(0x1)
	uint8                                        Pad_2916[0x7];                                     // Fixing Size Of Struct
};

// 0x20 (0x20 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.RequestTestActionStateWithIdOnTrack
struct UActionStateMachineComponentTestFunctions_RequestTestActionStateWithIdOnTrack_Params
{
public:
	class UActionStateMachineComponent*          InComponent;                                       // 0x0(0x8)
	enum class EActionStateMachineTrackId        TrackId;                                           // 0x8(0x1)
	uint8                                        Pad_2917[0x7];                                     // Fixing Size After Last Property
	TSubclassOf<class UActionStateId>            StateId;                                           // 0x10(0x8)
	bool                                         ReturnValue;                                       // 0x18(0x1)
	uint8                                        Pad_2918[0x7];                                     // Fixing Size Of Struct
};

// 0x10 (0x10 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.RequestNullActionStateOnTrack
struct UActionStateMachineComponentTestFunctions_RequestNullActionStateOnTrack_Params
{
public:
	class UActionStateMachineComponent*          InComponent;                                       // 0x0(0x8)
	enum class EActionStateMachineTrackId        TrackId;                                           // 0x8(0x1)
	bool                                         ReturnValue;                                       // 0x9(0x1)
	uint8                                        Pad_2919[0x6];                                     // Fixing Size Of Struct
};

// 0x20 (0x20 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.PushTestActionStateSerialisableDataOnTrack
struct UActionStateMachineComponentTestFunctions_PushTestActionStateSerialisableDataOnTrack_Params
{
public:
	class UActionStateMachineComponent*          InComponent;                                       // 0x0(0x8)
	enum class EActionStateMachineTrackId        TrackId;                                           // 0x8(0x1)
	uint8                                        Pad_291A[0x7];                                     // Fixing Size After Last Property
	TSubclassOf<class UActionStateId>            StateId;                                           // 0x10(0x8)
	int32                                        DataValue;                                         // 0x18(0x4)
	uint8                                        Pad_291B[0x4];                                     // Fixing Size Of Struct
};

// 0x20 (0x20 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.IsActionStateTypeActiveOnTrack
struct UActionStateMachineComponentTestFunctions_IsActionStateTypeActiveOnTrack_Params
{
public:
	class UActionStateMachineComponent*          InComponent;                                       // 0x0(0x8)
	enum class EActionStateMachineTrackId        TrackId;                                           // 0x8(0x1)
	uint8                                        Pad_291C[0x7];                                     // Fixing Size After Last Property
	TSubclassOf<class UActionStateId>            StateId;                                           // 0x10(0x8)
	bool                                         ReturnValue;                                       // 0x18(0x1)
	uint8                                        Pad_291D[0x7];                                     // Fixing Size Of Struct
};

// 0x18 (0x18 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.GetTypeOfActionStateActiveOnTrack
struct UActionStateMachineComponentTestFunctions_GetTypeOfActionStateActiveOnTrack_Params
{
public:
	class UActionStateMachineComponent*          InComponent;                                       // 0x0(0x8)
	enum class EActionStateMachineTrackId        TrackId;                                           // 0x8(0x1)
	uint8                                        Pad_291E[0x7];                                     // Fixing Size After Last Property
	TSubclassOf<class UActionStateId>            ReturnValue;                                       // 0x10(0x8)
};

// 0x50 (0x50 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.GetTestActionStateSerialisableDataOnTrack
struct UActionStateMachineComponentTestFunctions_GetTestActionStateSerialisableDataOnTrack_Params
{
public:
	class UActionStateMachineComponent*          InComponent;                                       // 0x0(0x8)
	enum class EActionStateMachineTrackId        TrackId;                                           // 0x8(0x1)
	uint8                                        Pad_291F[0x7];                                     // Fixing Size After Last Property
	struct FTestActionStateSerialisableData      Data;                                              // 0x10(0x38)
	bool                                         ReturnValue;                                       // 0x48(0x1)
	uint8                                        Pad_2920[0x7];                                     // Fixing Size Of Struct
};

// 0x8 (0x8 - 0x0)
// Function ActionStateMachine.ActionStateMachineComponentTestFunctions.CreateCustomClientValidityCheckCallback
struct UActionStateMachineComponentTestFunctions_CreateCustomClientValidityCheckCallback_Params
{
public:
	class UCustomClientValidityCheckCallback*    ReturnValue;                                       // 0x0(0x8)
};

// 0xB8 (0xB8 - 0x0)
// Function ActionStateMachine.ActionStatePriorityTableUtility.GetPriority
struct UActionStatePriorityTableUtility_GetPriority_Params
{
public:
	struct FActionStatePriorityTable             PriorityTable;                                     // 0x0(0xA0)
	TSubclassOf<class UActionStateId>            InStateA;                                          // 0xA0(0x8)
	TSubclassOf<class UActionStateId>            InStateB;                                          // 0xA8(0x8)
	enum class EActionStatePriority              ReturnValue;                                       // 0xB0(0x1)
	uint8                                        Pad_2921[0x7];                                     // Fixing Size Of Struct
};

// 0xA8 (0xA8 - 0x0)
// Function ActionStateMachine.ActionStatePriorityTableUtility.CreatePriorityTable
struct UActionStatePriorityTableUtility_CreatePriorityTable_Params
{
public:
	class UActionStatePriorityTableData*         Data;                                              // 0x0(0x8)
	struct FActionStatePriorityTable             ReturnValue;                                       // 0x8(0xA0)
};

// 0x48 (0x48 - 0x0)
// Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.IsValid
struct USerialisedActionStateConstructionInfoTestFunctions_IsValid_Params
{
public:
	struct FSerialisedActionStateInfo            TestStruct;                                        // 0x0(0x40)
	bool                                         ReturnValue;                                       // 0x40(0x1)
	uint8                                        Pad_2922[0x7];                                     // Fixing Size Of Struct
};

// 0x48 (0x48 - 0x0)
// Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.HasTestConstructionInfoWithInner
struct USerialisedActionStateConstructionInfoTestFunctions_HasTestConstructionInfoWithInner_Params
{
public:
	struct FSerialisedActionStateInfo            TestStruct;                                        // 0x0(0x40)
	bool                                         ReturnValue;                                       // 0x40(0x1)
	uint8                                        Pad_2923[0x7];                                     // Fixing Size Of Struct
};

// 0x48 (0x48 - 0x0)
// Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.HasTestConstructionInfo
struct USerialisedActionStateConstructionInfoTestFunctions_HasTestConstructionInfo_Params
{
public:
	struct FSerialisedActionStateInfo            TestStruct;                                        // 0x0(0x40)
	bool                                         ReturnValue;                                       // 0x40(0x1)
	uint8                                        Pad_2924[0x7];                                     // Fixing Size Of Struct
};

// 0x88 (0x88 - 0x0)
// Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.GetTestConstructionInfoWithInner
struct USerialisedActionStateConstructionInfoTestFunctions_GetTestConstructionInfoWithInner_Params
{
public:
	struct FSerialisedActionStateInfo            TestStruct;                                        // 0x0(0x40)
	struct FTestActionStateConstructionInfoWithInner ReturnValue;                                       // 0x40(0x48)
};

// 0x70 (0x70 - 0x0)
// Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.GetTestConstructionInfo
struct USerialisedActionStateConstructionInfoTestFunctions_GetTestConstructionInfo_Params
{
public:
	struct FSerialisedActionStateInfo            TestStruct;                                        // 0x0(0x40)
	struct FTestActionStateConstructionInfo      ReturnValue;                                       // 0x40(0x30)
};

// 0x50 (0x50 - 0x0)
// Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.CreateTestSerialisableData
struct USerialisedActionStateConstructionInfoTestFunctions_CreateTestSerialisableData_Params
{
public:
	TSubclassOf<class UActionStateId>            Id;                                                // 0x0(0x8)
	int32                                        IntProp;                                           // 0x8(0x4)
	uint8                                        Pad_2925[0x4];                                     // Fixing Size After Last Property
	struct FSerialisedActionStateInfo            ReturnValue;                                       // 0x10(0x40)
};

// 0x60 (0x60 - 0x0)
// Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.CreateTestConstructionInfoWithInner
struct USerialisedActionStateConstructionInfoTestFunctions_CreateTestConstructionInfoWithInner_Params
{
public:
	TSubclassOf<class UActionStateId>            Id;                                                // 0x0(0x8)
	float                                        FloatProp;                                         // 0x8(0x4)
	bool                                         BoolProp;                                          // 0xC(0x1)
	uint8                                        Pad_2926[0x3];                                     // Fixing Size After Last Property
	class FString                                StringProp;                                        // 0x10(0x10)
	struct FSerialisedActionStateInfo            ReturnValue;                                       // 0x20(0x40)
};

// 0x50 (0x50 - 0x0)
// Function ActionStateMachine.SerialisedActionStateConstructionInfoTestFunctions.CreateTestConstructionInfo
struct USerialisedActionStateConstructionInfoTestFunctions_CreateTestConstructionInfo_Params
{
public:
	TSubclassOf<class UActionStateId>            Id;                                                // 0x0(0x8)
	int32                                        IntProp;                                           // 0x8(0x4)
	uint8                                        Pad_2927[0x4];                                     // Fixing Size After Last Property
	struct FSerialisedActionStateInfo            ReturnValue;                                       // 0x10(0x40)
};

}
}


