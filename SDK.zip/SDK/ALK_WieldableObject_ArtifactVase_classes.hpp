#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x28 - 0x28)
// BlueprintGeneratedClass ALK_WieldableObject_ArtifactVase.ALK_WieldableObject_ArtifactVase_C
class UALK_WieldableObject_ArtifactVase_C : public UWieldableItemAnimationStoreId
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ALK_WieldableObject_ArtifactVase_C"));
		return Clss;
	}

};

}


