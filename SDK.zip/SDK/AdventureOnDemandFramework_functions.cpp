#include "pch.h"

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// FUNCTIONS
//---------------------------------------------------------------------------------------------------------------------


// Function AdventureOnDemandFramework.AdventureOnDemandTaleFunctionLibrary.CompareOnDemandQuestResumeConditionMetReason
// (Final, Native, Static, Public)
// Parameters:
// enum class EOnDemandQuestResumeConditionMetReasonLeft                                                             
// enum class EOnDemandQuestResumeConditionMetReasonRight                                                            
// bool                               ReturnValue                                                      

bool UAdventureOnDemandTaleFunctionLibrary::CompareOnDemandQuestResumeConditionMetReason(enum class EOnDemandQuestResumeConditionMetReason Left, enum class EOnDemandQuestResumeConditionMetReason Right)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = UObject::FindObject<UFunction>(Xors("Function AdventureOnDemandFramework.AdventureOnDemandTaleFunctionLibrary.CompareOnDemandQuestResumeConditionMetReason"));

	Params::UAdventureOnDemandTaleFunctionLibrary_CompareOnDemandQuestResumeConditionMetReason_Params Parms;
	Parms.Left = Left;
	Parms.Right = Right;

	auto Flags = Func->FunctionFlags;
	Func->FunctionFlags |= 0x400;


	UObject::ProcessEvent(Func, &Parms);

	Func->FunctionFlags = Flags;

	return Parms.ReturnValue;

}

}


