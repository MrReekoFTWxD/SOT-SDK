#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x58 (0x80 - 0x28)
// Class AIShips.AIShipBattlesDataAsset
class UAIShipBattlesDataAsset : public UDataAsset
{
public:
	TArray<struct FAIShipBattleParams>           Battles;                                           // 0x28(0x10)
	TArray<class FText>                          SkellyCrewNames;                                   // 0x38(0x10)
	class FText                                  EncounterCompleteText;                             // 0x48(0x38)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipBattlesDataAsset"));
		return Clss;
	}

};

// 0x358 (0x490 - 0x138)
// Class AIShips.AthenaAIShipControllerParamsDataAsset
class UAthenaAIShipControllerParamsDataAsset : public UAthenaAIControllerParamsDataAsset
{
public:
	struct FShipMovementParams                   TrackingMovementParams;                            // 0x138(0x38)
	struct FWeightedProbabilityRangeOfRanges     TimesToSailBesideTarget;                           // 0x170(0x30)
	struct FWeightedProbabilityRangeOfRanges     PerpendicularDistanceOffsets;                      // 0x1A0(0x30)
	struct FWeightedProbabilityRangeOfRanges     TimesBeforeDistanceChange;                         // 0x1D0(0x30)
	float                                        MaxParallelDistanceOffset;                         // 0x200(0x4)
	float                                        AlignDistanceThreshold;                            // 0x204(0x4)
	float                                        TimeToProjectIntoFutureForTracking;                // 0x208(0x4)
	float                                        TargetSpeedThresholdToTrackShip;                   // 0x20C(0x4)
	struct FTrackingNoiseGenerator               TrackingNoiseGenerator;                            // 0x210(0x18)
	float                                        WheelAngleMonitorDuration;                         // 0x228(0x4)
	float                                        WheelAngleChangeThresholdToBreakTracking;          // 0x22C(0x4)
	float                                        SpeedMonitorDuration;                              // 0x230(0x4)
	float                                        SpeedChangeThresholdToBreakTrackingInMPS;          // 0x234(0x4)
	float                                        TargetSpeedToConsiderAnchorLoweredInMPS;           // 0x238(0x4)
	uint8                                        Pad_33BC[0x4];                                     // Fixing Size After Last Property
	struct FWeightedProbabilityRangeOfRanges     TrackingLatencyTimes;                              // 0x240(0x30)
	struct FWeightedProbabilityRangeOfRanges     TrackingLatencyTimesWhenAnchorLowered;             // 0x270(0x30)
	class UCurveFloat*                           DistToTargetShipVSTrackingLatencyCurve;            // 0x2A0(0x8)
	struct FShipMovementParams                   CirclingMovementParams;                            // 0x2A8(0x38)
	float                                        TargetSpeedThresholdInKnots;                       // 0x2E0(0x4)
	float                                        SecondsInFutureToProjectTargetLocation;            // 0x2E4(0x4)
	struct FWeightedProbabilityRangeOfRanges     CircleRadiuses;                                    // 0x2E8(0x30)
	struct FWeightedProbabilityRangeOfRanges     CirclingSpeedsInDegreesPerSecond;                  // 0x318(0x30)
	struct FWeightedProbabilityRangeOfRanges     TimesToCircleBeforeChangingRadius;                 // 0x348(0x30)
	float                                        MinDistanceFromTargetToStartRam;                   // 0x378(0x4)
	float                                        MaxDistanceFromTargetToStartRam;                   // 0x37C(0x4)
	float                                        MaxSpeedToRamTarget;                               // 0x380(0x4)
	float                                        RammingMaxTurnSpeed;                               // 0x384(0x4)
	float                                        RammingTimeDampingScalar;                          // 0x388(0x4)
	float                                        MinAngleToTargetToAttemptRam;                      // 0x38C(0x4)
	struct FWeightedProbabilityRangeOfRanges     RammingLocationOffsets;                            // 0x390(0x30)
	struct FShipMovementParams                   SailingForwardMovementParams;                      // 0x3C0(0x38)
	float                                        MinAllowedDistanceToObstacle;                      // 0x3F8(0x4)
	float                                        MaxPathAvoidanceDistance;                          // 0x3FC(0x4)
	struct FShipMovementParams                   PassiveSailingMovementParams;                      // 0x400(0x38)
	float                                        ChanceToAnchor;                                    // 0x438(0x4)
	uint8                                        Pad_33BD[0x4];                                     // Fixing Size After Last Property
	struct FWeightedProbabilityRangeOfRanges     TimesToStayAnchored;                               // 0x440(0x30)
	int32                                        NumIslandsToVisitBeforeReturning;                  // 0x470(0x4)
	float                                        DistanceFromIslandsToSailTo;                       // 0x474(0x4)
	float                                        DistanceToTargetToDropAnchor;                      // 0x478(0x4)
	uint8                                        Pad_33BE[0x4];                                     // Fixing Size After Last Property
	TArray<TSubclassOf<class UImpactProjectileId>> AggressionOverrideImpactIDs;                       // 0x480(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AthenaAIShipControllerParamsDataAsset"));
		return Clss;
	}

};

// 0x98 (0xC0 - 0x28)
// Class AIShips.AIShipContextDescDataAsset
class UAIShipContextDescDataAsset : public UDataAsset
{
public:
	enum class EAIShipType                       ShipType;                                          // 0x28(0x1)
	enum class EAIShipEncounterType              EncounterType;                                     // 0x29(0x1)
	uint8                                        Pad_33BF[0x6];                                     // Fixing Size After Last Property
	TSubclassOf<class UGameEventType>            EventType;                                         // 0x30(0x8)
	class UShipDescAsset*                        ShipDesc;                                          // 0x38(0x8)
	class UAthenaAIShipControllerParamsDataAsset* ControllerParams;                                  // 0x40(0x8)
	TArray<struct FAIShipEncounterParamsSpawnerData> Spawners;                                          // 0x48(0x10)
	struct FAIShipContextDescDamageParams        DamageParams;                                      // 0x58(0x14)
	struct FAIShipSailData                       SailsCustomisation;                                // 0x6C(0x10)
	struct FColor                                SailColour;                                        // 0x7C(0x4)
	struct FAIShipCrewFormType                   FormType;                                          // 0x80(0x20)
	struct FAIShipCrewAmmoType                   AmmoType;                                          // 0xA0(0x18)
	class UShortRangeMarkerDataAsset*            RewardMarkerParams;                                // 0xB8(0x8)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipContextDescDataAsset"));
		return Clss;
	}

};

// 0x38 (0x60 - 0x28)
// Class AIShips.AIShipEncounterDesc
class UAIShipEncounterDesc : public UDataAsset
{
public:
	struct FVector2D                             Location;                                          // 0x28(0x8)
	float                                        Radius;                                            // 0x30(0x4)
	bool                                         Moveable;                                          // 0x34(0x1)
	bool                                         ShowRevealBanner;                                  // 0x35(0x1)
	bool                                         ShowCompleteBanner;                                // 0x36(0x1)
	bool                                         ShouldSpawnShipCloud;                              // 0x37(0x1)
	bool                                         RequirePlayerShipInZoneToSpawnShips;               // 0x38(0x1)
	bool                                         EnableSecondsUntilEncounterEndsAfterLastCrewLeft;  // 0x39(0x1)
	uint8                                        Pad_33C0[0x2];                                     // Fixing Size After Last Property
	int32                                        SecondsUntilEncounterEndsAfterLastCrewLeft;        // 0x3C(0x4)
	bool                                         EnableMaximumEncounterDuration;                    // 0x40(0x1)
	uint8                                        Pad_33C1[0x3];                                     // Fixing Size After Last Property
	int32                                        MaximumEncounterDuration;                          // 0x44(0x4)
	enum class EAIShipEncounterType              EncounterType;                                     // 0x48(0x1)
	uint8                                        Pad_33C2[0x7];                                     // Fixing Size After Last Property
	TArray<struct FAIShipEncounterWave>          Waves;                                             // 0x50(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipEncounterDesc"));
		return Clss;
	}

};

// 0x68 (0x90 - 0x28)
// Class AIShips.AIShipContextParamsDataAsset
class UAIShipContextParamsDataAsset : public UDataAsset
{
public:
	float                                        TopDeckPlayerTrackerRadius;                        // 0x28(0x4)
	float                                        TimeSpentEmotingOnInitialSpawn;                    // 0x2C(0x4)
	bool                                         ForceAIToAlwaysSpawn;                              // 0x30(0x1)
	uint8                                        Pad_33C3[0x3];                                     // Fixing Size After Last Property
	float                                        IntervalBetweenRepairDamageAssignments;            // 0x34(0x4)
	float                                        IntervalBetweenUseCannonAssignments;               // 0x38(0x4)
	float                                        DistForMinXYAIInteractableUtility;                 // 0x3C(0x4)
	float                                        DistForMaxXYAIInteractableUtility;                 // 0x40(0x4)
	float                                        MinXYAIInteractableUtility;                        // 0x44(0x4)
	float                                        MaxXYAIInteractableUtility;                        // 0x48(0x4)
	float                                        DistForMinZAIInteractableUtility;                  // 0x4C(0x4)
	float                                        DistForMaxZAIInteractableUtility;                  // 0x50(0x4)
	float                                        MinZAIInteractableUtility;                         // 0x54(0x4)
	float                                        MaxZAIInteractableUtility;                         // 0x58(0x4)
	float                                        MinInactiveRepairSpawnDelay;                       // 0x5C(0x4)
	float                                        MaxInactiveRepairSpawnDelay;                       // 0x60(0x4)
	float                                        SpawnSfxDistance;                                  // 0x64(0x4)
	float                                        SinkSfxDistance;                                   // 0x68(0x4)
	int32                                        MinCannonAttackersWhenBoarded;                     // 0x6C(0x4)
	float                                        StuckCheckInterval;                                // 0x70(0x4)
	float                                        StuckCheckDistance;                                // 0x74(0x4)
	float                                        MaxDistanceFromEncounter;                          // 0x78(0x4)
	float                                        ShipFlippedAngle;                                  // 0x7C(0x4)
	float                                        SecondsUntilKillAIAfterShipDefeated;               // 0x80(0x4)
	float                                        SecondsDelayForAIShipDefeatedNotification;         // 0x84(0x4)
	bool                                         EnableShipSurfacingMusic;                          // 0x88(0x1)
	uint8                                        Pad_33C4[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipContextParamsDataAsset"));
		return Clss;
	}

};

// 0x70 (0x98 - 0x28)
// Class AIShips.AIShipEncounterDynamicDesc
class UAIShipEncounterDynamicDesc : public UObject
{
public:
	TArray<struct FAIShipSizeDynamicContexts>    ShipPool;                                          // 0x28(0x10)
	class UAIShipContextDescDataAsset*           FinalShip;                                         // 0x38(0x8)
	struct FAIShipEncounterDynamicBalancingDesc  DynamicBalancingDesc;                              // 0x40(0x58)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipEncounterDynamicDesc"));
		return Clss;
	}

};

// 0x38 (0x478 - 0x440)
// Class AIShips.ShipProxyPawn
class AShipProxyPawn : public APawn
{
public:
	class AActor*                                Ship;                                              // 0x440(0x8)
	class AActor*                                SpawnTargetShip;                                   // 0x448(0x8)
	uint8                                        Pad_33C5[0x28];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ShipProxyPawn"));
		return Clss;
	}

};

// 0xB0 (0xD8 - 0x28)
// Class AIShips.AIShipEncounterSpawnParamsDataAsset
class UAIShipEncounterSpawnParamsDataAsset : public UDataAsset
{
public:
	float                                        SpawnDepth;                                        // 0x28(0x4)
	float                                        Radius;                                            // 0x2C(0x4)
	float                                        MinSafeSpawnDistanceFromOtherShips;                // 0x30(0x4)
	float                                        TimeDelayBetweenWaves;                             // 0x34(0x4)
	struct FRelativeSpawnLocationGeneratorParams RelativeSpawnLocationParams;                       // 0x38(0xA0)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipEncounterSpawnParamsDataAsset"));
		return Clss;
	}

};

// 0x68 (0x90 - 0x28)
// Class AIShips.AIShipEncounterParamsDataAsset
class UAIShipEncounterParamsDataAsset : public UDataAsset
{
public:
	class UAIShipEncounterSpawnParamsDataAsset*  SpawnParams;                                       // 0x28(0x8)
	class UAIShipContextParamsDataAsset*         ContextParams;                                     // 0x30(0x8)
	class UAIShipContextDescDataAsset*           DefaultContextDesc;                                // 0x38(0x8)
	TSubclassOf<class AShipProxyPawn>            ShipPawnClass;                                     // 0x40(0x8)
	class UBuoyantObjectSpawnProfileDataAsset*   BuoyantObjectSpawnProfileAsset;                    // 0x48(0x8)
	TSubclassOf<class AGameplayEventSignal>      EventSignalAssetClass;                             // 0x50(0x8)
	float                                        EventSignalHeight;                                 // 0x58(0x4)
	float                                        OuterRadiusMultiplier;                             // 0x5C(0x4)
	float                                        MigrationRadiusMultiplier;                         // 0x60(0x4)
	float                                        InitialEncounterEntryDelay;                        // 0x64(0x4)
	float                                        MinEngagedDistanceFromPlayers;                     // 0x68(0x4)
	uint8                                        Pad_33C6[0x4];                                     // Fixing Size After Last Property
	class FString                                MinEngagedDistanceFromPlayersRemoteConfigKey;      // 0x70(0x10)
	bool                                         EnableMusicWhenShipsHaveNoTarget;                  // 0x80(0x1)
	uint8                                        Pad_33C7[0x3];                                     // Fixing Size After Last Property
	int32                                        SecondsUntilEncounterEndsAfterLastCrewLeft;        // 0x84(0x4)
	int32                                        MaximumEncounterDuration;                          // 0x88(0x4)
	float                                        OnDemandAvailabilityRadius;                        // 0x8C(0x4)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipEncounterParamsDataAsset"));
		return Clss;
	}

};

// 0x250 (0x278 - 0x28)
// Class AIShips.AIShipServiceDataAsset
class UAIShipServiceDataAsset : public UDataAsset
{
public:
	TArray<struct FEventTypeAIShipEncounterParams> BattleEncounterParams;                             // 0x28(0x10)
	struct FAIShipEncounterParams                AggressiveEncounterParams;                         // 0x38(0x28)
	struct FAIShipEncounterParams                PassiveEncounterParams;                            // 0x60(0x28)
	struct FIntPoint                             ObstacleBucketDimensions;                          // 0x88(0x8)
	float                                        ShipwreckObstacleRadius;                           // 0x90(0x4)
	uint8                                        Pad_33C8[0x4];                                     // Fixing Size After Last Property
	struct FAIShipContextDescGenerationParams    ContextDescGenerationParams;                       // 0x98(0x80)
	struct FAIShipBattleEncounterDescGenerationParams EncounterGenerationParams;                         // 0x118(0x80)
	struct FAIShipSingleWaveEncounterDescGenerationParams AggressiveEncounterGenerationParams;               // 0x198(0x10)
	struct FAIShipSingleWaveEncounterDescGenerationParams PassiveEncounterGenerationParams;                  // 0x1A8(0x10)
	struct FWeightedProbabilityRangeOfRanges     TimerBattleFirstRegenInterval;                     // 0x1B8(0x30)
	struct FWeightedProbabilityRangeOfRanges     TimerBattleRegenInterval;                          // 0x1E8(0x30)
	float                                        TimerBattleFinderThrottle;                         // 0x218(0x4)
	uint8                                        Pad_33C9[0x4];                                     // Fixing Size After Last Property
	struct FWeightedProbabilityRangeOfRanges     TimerBattleRetryRegenInterval;                     // 0x220(0x30)
	float                                        TimerBattleMinActivationDistanceFromPlayers;       // 0x250(0x4)
	uint8                                        Pad_33CA[0x4];                                     // Fixing Size After Last Property
	class UShortRangeMarkerDataAsset*            RewardMarkerParams;                                // 0x258(0x8)
	TArray<class FName>                          IslandsToAvoid;                                    // 0x260(0x10)
	float                                        AvoidanceRange;                                    // 0x270(0x4)
	uint8                                        Pad_33CB[0x4];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipServiceDataAsset"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIShips.AIShipDebugFunctionLibrary
class UAIShipDebugFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipDebugFunctionLibrary"));
		return Clss;
	}

	void RequestAIShipForCrew(class UObject* WorldContextObject, const struct FGuid& CrewId);
	struct FAIShipEncounterBattleDesc GenerateAIShipBattleDesc(class UObject* WorldContextObject, class UAIShipServiceDataAsset* ServiceParams);
};

// 0x28 (0x60 - 0x38)
// Class AIShips.AIShipGameSettings
class UAIShipGameSettings : public UDeveloperSettings
{
public:
	struct FStringAssetReference                 AIShipServiceDataAssetFileLocation;                // 0x38(0x10)
	struct FToggleableAIShipsServiceDataAssetFileLocation AIShipServiceDataAssetFileLocationOverride;        // 0x48(0x18)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipGameSettings"));
		return Clss;
	}

};

// 0x28 (0xF0 - 0xC8)
// Class AIShips.AIShipObstacleComponent
class UAIShipObstacleComponent : public UActorComponent
{
public:
	enum class EObstacleType                     ObstacleType;                                      // 0xC8(0x1)
	uint8                                        Pad_33CC[0x3];                                     // Fixing Size After Last Property
	float                                        Radius;                                            // 0xCC(0x4)
	uint8                                        Pad_33CD[0x20];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipObstacleComponent"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIShips.AIShipObstacleServiceInterface
class UAIShipObstacleServiceInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipObstacleServiceInterface"));
		return Clss;
	}

};

// 0x88 (0x450 - 0x3C8)
// Class AIShips.AIShipObstacleService
class AAIShipObstacleService : public AActor
{
public:
	uint8                                        Pad_33CE[0x88];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipObstacleService"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIShips.AIShipsBlueprintFunctionLibrary
class UAIShipsBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipsBlueprintFunctionLibrary"));
		return Clss;
	}

	bool RequestPassiveAIShipForPlayerShip(class UObject* WorldContext, class AActor* PlayerShip, TSubclassOf<class UShipSize> ForcedAIShipSize);
	bool RequestPassiveAIShipAtLocation(class UObject* WorldContext, struct FVector& Location, class AActor* PlayerShip, TSubclassOf<class UShipSize> ForcedAIShipSize);
	bool RequestAggressiveAIShipForPlayerShip(class UObject* WorldContext, class AActor* PlayerShip, TSubclassOf<class UShipSize> ForcedAIShipSize);
	bool RequestAggressiveAIShipAtLocation(class UObject* WorldContext, struct FVector& Location, class AActor* PlayerShip, TSubclassOf<class UShipSize> ForcedAIShipSize);
};

// 0x430 (0x7F8 - 0x3C8)
// Class AIShips.AIShipService
class AAIShipService : public AActor
{
public:
	uint8                                        Pad_33D5[0x10];                                    // Fixing Size After Last Property
	class UGameEventOnDemandAvailabilityHandler* GameEventOnDemandAvailabilityHandler;              // 0x3D8(0x8)
	uint8                                        Pad_33D6[0x18];                                    // Fixing Size After Last Property
	class UAIShipServiceDataAsset*               Params;                                            // 0x3F8(0x8)
	uint8                                        Pad_33D7[0x3F8];                                   // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipService"));
		return Clss;
	}

};

// 0x40 (0x108 - 0xC8)
// Class AIShips.AIShipTelemetryComponent
class UAIShipTelemetryComponent : public UActorComponent
{
public:
	uint8                                        Pad_33D8[0x40];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AIShipTelemetryComponent"));
		return Clss;
	}

};

// 0x170 (0x780 - 0x610)
// Class AIShips.AthenaAIShipController
class AAthenaAIShipController : public AAthenaAIControllerBase
{
public:
	class UBehaviorTree*                         BTAsset;                                           // 0x610(0x8)
	uint8                                        Pad_33D9[0x18];                                    // Fixing Size After Last Property
	class UAthenaAIShipControllerParamsDataAsset* ShipParamsDataAsset;                               // 0x630(0x8)
	class UStatusEffectManagerComponent*         StatusEffectManagerComponent;                      // 0x638(0x8)
	struct FStandardAnchorDynamicsParameters     AnchorDynamicsParams;                              // 0x640(0x28)
	uint8                                        Pad_33DA[0x118];                                   // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AthenaAIShipController"));
		return Clss;
	}

	void ApplyControllerParams(class UAthenaAIControllerParamsDataAsset* ParamsAsset, class APawn* InPawn);
};

// 0xE0 (0x150 - 0x70)
// Class AIShips.BTService_UpdateIfShipShouldBreakTracking
class UBTService_UpdateIfShipShouldBreakTracking : public UBTService
{
public:
	struct FBlackboardKeySelector                TargetActorKey;                                    // 0x70(0x28)
	struct FBlackboardKeySelector                DisableTrackingKey;                                // 0x98(0x28)
	struct FBlackboardKeySelector                ShouldSailForwardKey;                              // 0xC0(0x28)
	struct FBlackboardKeySelector                TimeToSailForwardKey;                              // 0xE8(0x28)
	struct FBlackboardKeySelector                CaptainIsPresentKey;                               // 0x110(0x28)
	uint8                                        Pad_33DB[0x18];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTService_UpdateIfShipShouldBreakTracking"));
		return Clss;
	}

};

// 0x50 (0xC0 - 0x70)
// Class AIShips.BTService_UpdateLocationWithActorLocation
class UBTService_UpdateLocationWithActorLocation : public UBTService
{
public:
	struct FBlackboardKeySelector                LocationKey;                                       // 0x70(0x28)
	struct FBlackboardKeySelector                ActorKey;                                          // 0x98(0x28)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTService_UpdateLocationWithActorLocation"));
		return Clss;
	}

};

// 0x60 (0xD0 - 0x70)
// Class AIShips.BTService_UpdateTargetLocationForPassiveShip
class UBTService_UpdateTargetLocationForPassiveShip : public UBTService
{
public:
	struct FBlackboardKeySelector                TargetLocationKey;                                 // 0x70(0x28)
	float                                        AngleOffsetFromForwardDegreesWhenNoIslands;        // 0x98(0x4)
	float                                        TargetLocationDistanceWhenNoIslands;               // 0x9C(0x4)
	uint8                                        Pad_33DC[0x30];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTService_UpdateTargetLocationForPassiveShip"));
		return Clss;
	}

};

// 0x10 (0x98 - 0x88)
// Class AIShips.BTTask_AIShipSurface
class UBTTask_AIShipSurface : public UBTTask_BlackboardBase
{
public:
	float                                        MaxSpeed;                                          // 0x88(0x4)
	float                                        PreSurfaceDelay;                                   // 0x8C(0x4)
	uint8                                        Pad_33DD[0x8];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_AIShipSurface"));
		return Clss;
	}

};

// 0xE0 (0x168 - 0x88)
// Class AIShips.BTTask_RamTargetShip
class UBTTask_RamTargetShip : public UBTTask_BlackboardBase
{
public:
	uint8                                        Pad_33DE[0xE0];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_RamTargetShip"));
		return Clss;
	}

};

// 0x50 (0xD8 - 0x88)
// Class AIShips.BTTask_SailShipBesideTarget
class UBTTask_SailShipBesideTarget : public UBTTask_BlackboardBase
{
public:
	uint8                                        Pad_33DF[0x20];                                    // Fixing Size After Last Property
	struct FTrackingNoiseGenerator               TrackingNoiseGenerator;                            // 0xA8(0x18)
	uint8                                        Pad_33E0[0x18];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_SailShipBesideTarget"));
		return Clss;
	}

};

// 0x38 (0xC0 - 0x88)
// Class AIShips.BTTask_SailShipCircleTarget
class UBTTask_SailShipCircleTarget : public UBTTask_BlackboardBase
{
public:
	uint8                                        Pad_33E1[0x38];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_SailShipCircleTarget"));
		return Clss;
	}

};

// 0xA8 (0x130 - 0x88)
// Class AIShips.BTTask_SailShipForward
class UBTTask_SailShipForward : public UBTTask_BlackboardBase
{
public:
	struct FBlackboardKeySelector                ShouldSailForwardKey;                              // 0x88(0x28)
	struct FBlackboardKeySelector                TimeToSailForwardKey;                              // 0xB0(0x28)
	struct FBlackboardKeySelector                IsCaptainPresentKey;                               // 0xD8(0x28)
	uint8                                        Pad_33E2[0x30];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_SailShipForward"));
		return Clss;
	}

};

// 0x48 (0xD0 - 0x88)
// Class AIShips.BTTask_SailShipToLocation
class UBTTask_SailShipToLocation : public UBTTask_BlackboardBase
{
public:
	struct FBlackboardKeySelector                TargetLocationKey;                                 // 0x88(0x28)
	float                                        DistanceThresholdToConsiderTargetReached;          // 0xB0(0x4)
	uint8                                        Pad_33E3[0x1C];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("BTTask_SailShipToLocation"));
		return Clss;
	}

};

// 0x0 (0x28 - 0x28)
// Class AIShips.CursedCrewCustomisationInterface
class UCursedCrewCustomisationInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("CursedCrewCustomisationInterface"));
		return Clss;
	}

	void SetCursedCrewCustomisationProperties(struct FAIShipSailData& SailData);
};

// 0x10 (0x38 - 0x28)
// Class AIShips.CursedSailsCampaignDataAsset
class UCursedSailsCampaignDataAsset : public UDataAsset
{
public:
	TArray<struct FCursedSailsBattleParams>      Battles;                                           // 0x28(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("CursedSailsCampaignDataAsset"));
		return Clss;
	}

};

// 0x0 (0x30 - 0x30)
// Class AIShips.DefeatAIShipEncounterConditionalStatTrigger
class UDefeatAIShipEncounterConditionalStatTrigger : public UConditionalStatsTriggerType
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("DefeatAIShipEncounterConditionalStatTrigger"));
		return Clss;
	}

};

// 0x8 (0x30 - 0x28)
// Class AIShips.IsAIShipEncounterTypeStatCondition
class UIsAIShipEncounterTypeStatCondition : public UStatCondition
{
public:
	enum class EAIShipEncounterType              EncounterType;                                     // 0x28(0x1)
	uint8                                        Pad_33E4[0x7];                                     // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("IsAIShipEncounterTypeStatCondition"));
		return Clss;
	}

};

}


