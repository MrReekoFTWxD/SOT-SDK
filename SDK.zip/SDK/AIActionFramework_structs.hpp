#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// ENUMS
//---------------------------------------------------------------------------------------------------------------------


//---------------------------------------------------------------------------------------------------------------------
// STRUCTS
//---------------------------------------------------------------------------------------------------------------------

// 0x10 (0x10 - 0x0)
// ScriptStruct AIActionFramework.ActivityActionSpotContainer
struct FActivityActionSpotContainer
{
public:
	uint8                                        Pad_2BAA[0x10];                                    // Fixing Size Of Struct
};

// 0x50 (0x50 - 0x0)
// ScriptStruct AIActionFramework.RegionActionSpotContainer
struct FRegionActionSpotContainer
{
public:
	TMap<class UClass*, struct FActivityActionSpotContainer> RegisteredActionSpotsByActivity;                   // 0x0(0x50)
};

}


