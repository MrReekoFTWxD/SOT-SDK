#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x138 - 0x138)
// BlueprintGeneratedClass AggressiveGhostShipsEncounterGameEventOnDemand_Proposal.AggressiveGhostShipsEncounterGameEventOnDemand_Proposal_C
class UAggressiveGhostShipsEncounterGameEventOnDemand_Proposal_C : public UGameEventOnDemandVoyageProposalDesc
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("AggressiveGhostShipsEncounterGameEventOnDemand_Proposal_C"));
		return Clss;
	}

};

}


