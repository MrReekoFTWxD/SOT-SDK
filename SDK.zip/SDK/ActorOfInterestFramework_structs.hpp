#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// ENUMS
//---------------------------------------------------------------------------------------------------------------------


//---------------------------------------------------------------------------------------------------------------------
// STRUCTS
//---------------------------------------------------------------------------------------------------------------------

// 0x10 (0x10 - 0x0)
// ScriptStruct ActorOfInterestFramework.ActorsOfInterestList
struct FActorsOfInterestList
{
public:
	TArray<class AActor*>                        Actors;                                            // 0x0(0x10)
};

// 0x10 (0x10 - 0x0)
// ScriptStruct ActorOfInterestFramework.ActorOfInterestUnregisteredEvent
struct FActorOfInterestUnregisteredEvent
{
public:
	class AActor*                                ActorOfInterest;                                   // 0x0(0x8)
	TSubclassOf<class UActorOfInterestId>        ActorOfInterestId;                                 // 0x8(0x8)
};

// 0x10 (0x10 - 0x0)
// ScriptStruct ActorOfInterestFramework.ActorOfInterestRegisteredEvent
struct FActorOfInterestRegisteredEvent
{
public:
	class AActor*                                ActorOfInterest;                                   // 0x0(0x8)
	TSubclassOf<class UActorOfInterestId>        ActorOfInterestId;                                 // 0x8(0x8)
};

}


