#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x28 - 0x28)
// BlueprintGeneratedClass Adv12DD_Chp1_LarinnaDialogueTempState.Adv12DD_Chp1_LarinnaDialogueTempState_C
class UAdv12DD_Chp1_LarinnaDialogueTempState_C : public UTaleQuestQueryableStateDataID
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("Adv12DD_Chp1_LarinnaDialogueTempState_C"));
		return Clss;
	}

};

}


