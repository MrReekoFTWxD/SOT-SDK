#pragma once


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x28 - 0x28)
// Class ActorLayers.ActorLayerInterface
class UActorLayerInterface : public UInterface
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("ActorLayerInterface"));
		return Clss;
	}

};

// 0x30 (0x310 - 0x2E0)
// Class ActorLayers.InstancedLayerComponent
class UInstancedLayerComponent : public USceneComponent
{
public:
	uint8                                        Pad_30EB[0x8];                                     // Fixing Size After Last Property
	TArray<struct FInstancedLayer>               InstancedLayers;                                   // 0x2E8(0x10)
	uint8                                        Pad_30EC[0x18];                                    // Fixing Size Of Struct

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("InstancedLayerComponent"));
		return Clss;
	}

};

// 0x20 (0x48 - 0x28)
// Class ActorLayers.LayerActorsDataAsset
class ULayerActorsDataAsset : public UDataAsset
{
public:
	TArray<TSoftClassPtr<class AActor>>          Actors;                                            // 0x28(0x10)
	TArray<TSoftClassPtr<class UItemDesc>>       Items;                                             // 0x38(0x10)

	static class UClass* StaticClass()
	{
		static class UClass* Clss = nullptr;
		if(!Clss) Clss = UObject::FindObject<UClass>(Xors("LayerActorsDataAsset"));
		return Clss;
	}

};

}


