#pragma once


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x28 (0x28 - 0x0)
// Function ActorOfInterestFramework.ActorOfInterestBlueprintFunctionLibrary.GetActorsOfInterestFromIds
struct UActorOfInterestBlueprintFunctionLibrary_GetActorsOfInterestFromIds_Params
{
public:
	class UObject*                               WorldContextObject;                                // 0x0(0x8)
	TArray<TSubclassOf<class UActorOfInterestId>> ActorOfInterestIds;                                // 0x8(0x10)
	TArray<class AActor*>                        Actors;                                            // 0x18(0x10)
};

// 0x18 (0x18 - 0x0)
// Function ActorOfInterestFramework.ActorOfInterestBlueprintFunctionLibrary.GetActorOfInterestFromId
struct UActorOfInterestBlueprintFunctionLibrary_GetActorOfInterestFromId_Params
{
public:
	class UObject*                               WorldContextObject;                                // 0x0(0x8)
	TSubclassOf<class UActorOfInterestId>        ActorOfInterestId;                                 // 0x8(0x8)
	class AActor*                                ReturnValue;                                       // 0x10(0x8)
};

}
}


